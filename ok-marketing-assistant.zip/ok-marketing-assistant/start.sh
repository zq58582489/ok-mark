#!/bin/bash
# ============================================================
#  OK营销助手 —— 单体应用启动脚本（一个 jar 起全部功能）
#  用法: ./start.sh [端口]   默认 9000
#  访问: http://127.0.0.1:9000/
# ============================================================
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PORT="${1:-9000}"
JAR="$DIR/target/ok-marketing-assistant.jar"

if [ ! -f "$JAR" ]; then
  echo "[ERROR] 未找到 target/ok-marketing-assistant.jar，请先执行: mvn clean package"
  exit 1
fi

echo "Starting OK Marketing Assistant on port $PORT ..."
exec java -jar "$JAR" --server.port="$PORT"
