#!/bin/bash
# 单体应用端到端接口验证
B="http://127.0.0.1:9000"
C="Content-Type: application/json"

post() {
  echo "=== $1 ==="
  curl -s --noproxy "*" -X POST "$B/api/chat/messages" -H "$C" -d "$2"
  echo
}

post "帮我搜索国泰" '{"content":"帮我搜索国泰"}'
post "点击企业:江苏国泰国际集团" '{"content":"江苏国泰国际集团","intent":"company_click","company":"江苏国泰国际集团"}'
post "深化:商机线索" '{"content":"3. 商机线索","intent":"deep_opportunity","company":"江苏国泰国际集团","category":"存款"}'
post "深化:营销话术" '{"content":"4. 营销话术","intent":"deep_script","company":"江苏国泰国际集团","scene":"办公室场景"}'
post "今日任务" '{"content":"今日任务"}'
post "分配触达任务" '{"content":"请帮我分配对江苏韵瑞新能源汽车配件公司开展固定资产贷款的触达任务"}'
post "能做么" '{"content":"江苏韵瑞新能源汽车配件公司能做么？"}'
post "报表上传" '{"content":"[报表已上传]","intent":"report_upload","company":"江苏韵瑞新能源汽车配件公司","images":["assets/截屏2026-09-16 14.26.41@2x.png"]}'
post "业务知识问答" '{"content":"固定资产贷款怎么做？"}'
post "菜单查找网格" '{"content":"菜单查找网格"}'
