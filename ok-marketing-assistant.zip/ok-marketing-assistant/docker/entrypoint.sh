#!/bin/sh
# ============================================================================
#  OK 营销助手 —— 容器入口
#  · 启动前预热 LibreOffice 用户配置：首次转换要现建 profile，约 15~20 秒；
#    先按「运行时完全相同的路径」预跑一遍，之后每次转换都在 1~3 秒量级
#  · 用 exec 启动 java，让 JVM 成为 PID 1，docker stop 的 SIGTERM 能直达
#    （配合 application.yml 的 server.shutdown=graceful，可在退出前收尾进行中的请求）
#  · JAVA_OPTS 刻意不加引号：允许写多个 JVM 参数并以空格分隔
# ============================================================================
set -e

: "${OK_PORT:=9000}"
: "${JAVA_OPTS:=-XX:MaxRAMPercentage=75.0 -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -Duser.timezone=Asia/Shanghai}"

echo "Starting OK Marketing Assistant (port=${OK_PORT}, tz=${TZ:-unknown})"
echo "JAVA_OPTS=${JAVA_OPTS}"

# ---------------------------------------------------------------------------
#  文档预览预热（仅在 LibreOffice 可用且预览开启时执行）
#  路径必须与 DocumentPreviewService 一致：<java.io.tmpdir>/ok-preview/p<port>/profile-<n>
#  /tmp 是容器可写层（每次新建容器都是空的），所以这里重建一次；同一容器重启则直接跳过
# ---------------------------------------------------------------------------
warm_preview() {
    [ "${PREVIEW_ENABLED:-true}" = "false" ] && return 0
    command -v soffice >/dev/null 2>&1 || return 0

    n="${PREVIEW_CONCURRENCY:-2}"
    root="/tmp/ok-preview/p${OK_PORT}"
    tmp="$(mktemp -d)"
    printf '<html><body><h1>warmup</h1></body></html>' > "$tmp/w.html"

    started=0
    i=0
    while [ "$i" -lt "$n" ]; do
        profile="$root/profile-$i"
        if [ ! -f "$profile/user/registrymodifications.xcu" ]; then
            mkdir -p "$profile" "$tmp/out$i"
            soffice "-env:UserInstallation=file://$profile" \
                    --headless --norestore --nolockcheck --nodefault --nologo \
                    --convert-to pdf --outdir "$tmp/out$i" "$tmp/w.html" >/dev/null 2>&1 &
            started=$((started + 1))
        fi
        i=$((i + 1))
    done

    if [ "$started" -gt 0 ]; then
        echo "预热 LibreOffice 用户配置中（${started} 个槽位，约 15~20 秒）..."
        wait || true
        echo "预热完成，首个文档预览无需等待初始化"
    fi
    rm -rf "$tmp"
}

if command -v soffice >/dev/null 2>&1; then
    echo "LibreOffice: $(command -v soffice) —— Word/Excel/PPT 在线预览可用"
else
    echo "LibreOffice: 未找到 —— Word/Excel/PPT 只能下载、不能在线预览"
fi

warm_preview

exec java $JAVA_OPTS -jar /app/app.jar "$@"
