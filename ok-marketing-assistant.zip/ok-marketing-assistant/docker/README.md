# Docker 部署说明

一个镜像 = **Spring Boot 单体 jar（REST 接口 + Vue2 静态前端）+ LibreOffice（headless）+ 中文字体**。
起一个容器即可完整使用：对话、历史会话、附件上传/下载、Word/Excel/PPT/PDF 在线预览。

## 1. 文件说明

| 文件 | 作用 |
| --- | --- |
| `Dockerfile` | 两阶段构建：Maven 编译 → JRE + LibreOffice 运行 |
| `docker-compose.yml` | 单容器编排（端口、环境变量、自动重启） |
| `.env.example` | 环境变量模板，`cp .env.example .env` 后按需修改 |
| `docker/entrypoint.sh` | 容器入口，负责拼 JVM 参数并 `exec java`（让 JVM 成为 PID 1，可优雅停机） |
| `.dockerignore` | 构建上下文裁剪（排除 target、docs、IDE 文件等） |

## 2. 构建

```bash
# 方式一：compose（推荐，自动带上默认构建参数）
cp .env.example .env      # 需要改 Dify 地址/密钥时编辑 .env
docker compose up -d --build

# 方式二：直接 build
docker build -t ok-marketing-assistant:1.0.0 .
```

构建参数（`--build-arg`，compose 里从 `.env` 读）：

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `MAVEN_MIRROR` | `https://maven.aliyun.com/repository/public` | Maven 依赖源；置空走 Maven Central |
| `APT_MIRROR` | 空 | apt 源，如 `https://mirrors.aliyun.com/ubuntu` |
| `MAVEN_IMAGE` | `maven:3.9-eclipse-temurin-8` | 拉不到该 tag 时替换 |
| `RUNTIME_IMAGE` | `eclipse-temurin:8-jdk-jammy` | 同上（可换 `8-jre-jammy` 更小） |

镜像大小约 **1.26 GB**（LibreOffice ≈ 700 MB，`fonts-noto-cjk` ≈ 150 MB）。
首次构建约 **6～10 分钟**（要下 190 MB 的 LibreOffice 包 + 61 MB 中文字体）；依赖层有缓存，之后改代码重建只需 1 分钟左右。

构建期自带一道自检：把一段 HTML 转成 PDF，转不出来就让构建失败 —— 避免出现「镜像构建成功但预览全挂」的情况。

## 3. 运行

```bash
docker compose up -d            # 启动
docker compose logs -f          # 看日志（启动时会打印 LibreOffice 路径与端口）
docker compose ps               # 状态应显示 (healthy)
docker compose down             # 停止并删除容器
```

启动日志形如：

```
LibreOffice: /usr/bin/soffice —— Word/Excel/PPT 在线预览可用
预热 LibreOffice 用户配置中（2 个槽位，约 15~20 秒）...
预热完成，首个文档预览无需等待初始化
...
Tomcat started on port(s): 9000 (http)
```

> 那 15~20 秒是 LibreOffice 首次创建用户配置（profile）的一次性开销。
> 入口脚本在启动 JVM 之前按「运行时完全相同的路径」预跑一遍，
> 换来的是**每次文档预览都在 1~3 秒**（实测：不预热时首次预览要 18~30 秒）。

访问：<http://127.0.0.1:9000/>

不用 compose 时：

```bash
docker run -d --name ok-marketing-assistant \
  -p 9000:9000 \
  -e DIFY_BASE_URL=https://api.dify.ai \
  -e DIFY_API_KEY=app-xxxxxxxx \
  -e DIFY_USER=22340117 \
  --restart unless-stopped \
  ok-marketing-assistant:1.0.0
```

## 4. 环境变量

全部覆盖 `application.yml` 里的默认值（yml 里写的是 `${VAR:默认值}` 形式），改配置**不用重新打镜像**。

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `OK_PORT` | `9000` | 容器内监听端口（映射到宿主机用 `HOST_PORT`） |
| `TZ` | `Asia/Shanghai` | 时区 |
| `JAVA_OPTS` | `-XX:MaxRAMPercentage=75.0 -Dfile.encoding=UTF-8 -Duser.timezone=Asia/Shanghai` | JVM 参数 |
| `DIFY_ENABLED` | `true` | `false` = 回退内置 mock 演示数据（不连 Dify） |
| `DIFY_BASE_URL` | `https://api.dify.ai` | Dify 服务根地址，不带 `/v1` |
| `DIFY_API_KEY` | 原型自带 key | Chatflow 应用的 API Key |
| `DIFY_USER` | `22340117` | Dify 终端用户标识的**兜底值**：正常取 userToken 解密出的工号（会话按 user 隔离） |
| `DIFY_TIMEOUT_MS` | `180000` | blocking 模式等待 Chatflow 完成的超时（3 分钟）；有 nginx 时一并放大读超时 |
| `OK_AUTH_SM4_KEY` | 联调测试密钥 | **唯一必配项**：SM4 密钥（集群时各实例一致） |
| `OK_AUTH_ENABLED` | `true` | 一般不用动；`false` = 全部放行并把用户固定为「本地调试」（仅排查用） |
| `OK_AUTH_SM4_MODE` / `_PADDING` / `_CHARSET` | `ecb` / `pkcs7` / `UTF-8` | 有代码默认值，门户换约定时才需要覆盖 |
| `OK_AUTH_SM4_DEBUG` | `false` | 排查「解出来是乱码」：把密文/明文 hex 写到 `<tmpdir>/ok-auth-last-token.txt` |
| `OK_AUTH_SM4_SELFTEST_TOKEN` | 空 | 填一段真实 userToken，启动日志打印解密结果 |
| `OK_NATIVE_BASE_URL` | 空 | 菜单检索结果给相对地址时拼的前缀（对应门户 `VUE_APP_CUSTOMER_IP`） |
| `OK_NATIVE_ENABLED` | `true` | 是否走 JSBridge 打开原生子页面 |
| `OK_DEBUG_ENABLED` | `false` | 前端调试面板（悬浮「调试」按钮：环境 / 凭证 / 日志）；联调真机时设 `true` |
| `PREVIEW_ENABLED` | `true` | 文档在线预览总开关 |
| `PREVIEW_CONCURRENCY` | `2` | 同时转换数（每槽位一个独立 LibreOffice profile，建议 ≤ CPU 核数） |
| `PREVIEW_TIMEOUT_SECONDS` | `60` | 单次转换超时 |
| `PREVIEW_MAX_SIZE_MB` | `20` | 超过该大小的文件不转换，只给下载 |
| `SOFFICE_PATH` | 空 | 指定 soffice 路径；镜像内留空即自动找到 `/usr/bin/soffice` |

## 5. 验证清单

```bash
# 1) 健康检查
curl -s http://127.0.0.1:9000/actuator/health          # {"status":"UP"}

# 2) 前端与静态资源版本参数
curl -sI http://127.0.0.1:9000/ | head -1              # 200

# 3) 预览能力自检（前端也用这个接口）
curl -s http://127.0.0.1:9000/api/chat/profile -H "Authorization: Bearer $(curl -s -X POST http://127.0.0.1:9000/api/auth/token -H 'Content-Type: application/json' -d '{}' | python -c 'import sys,json;print(json.load(sys.stdin)["data"]["token"])')"
# 期望 preview.available = true（= 已找到 LibreOffice）
```

容器内直接验证转换：

```bash
docker compose exec ok-marketing-assistant soffice --version
docker compose exec ok-marketing-assistant fc-list :lang=zh | head   # 中文字体存在
```

## 6. 离线分发（内网/无外网环境）

```bash
# 有网机器
docker build -t ok-marketing-assistant:1.0.0 .
docker save ok-marketing-assistant:1.0.0 -o ok-marketing-assistant-1.0.0.tar

# 目标机器
docker load -i ok-marketing-assistant-1.0.0.tar
docker run -d -p 9000:9000 --env-file .env ok-marketing-assistant:1.0.0
```

> 目标机器只需能访问 Dify 平台（`DIFY_BASE_URL`）。若 Dify 也在内网，改 `DIFY_BASE_URL` 即可，无需改镜像。

## 7. 集群 / 扩容

应用本身**无状态**：附件字节只存在 Dify（每次下载实时向平台取签名地址），预览转换的临时文件用完即删，容器里没有任何持久化数据。

```bash
docker compose up -d --scale ok-marketing-assistant=3
```

注意（compose 场景建议前面挂 nginx 做负载均衡，并把 `ports` 改成不绑定宿主机固定端口）：

- 各实例的 `OK_AUTH_SM4_KEY` 等 SM4 参数必须一致（userToken 由门户下发、无状态，不依赖实例内存）；
- 各实例指向同一个 Dify 应用与同一个 `DIFY_USER`，历史会话才能互通；
- 不需要粘性会话，也不需要共享存储。

## 8. 常见问题

| 现象 | 原因与处理 |
| --- | --- |
| 预览报「服务端未安装 LibreOffice」 | `soffice` 探测失败。`docker compose exec ok-marketing-assistant which soffice` 确认；非官方镜像可用 `SOFFICE_PATH` 显式指定 |
| 转出的 PDF 中文变方框/乱码 | 缺中文字体。`fc-list :lang=zh` 应为空时报错；自行加装字体后重新构建 |
| Word 版式与本机略有差异 | 文档里用的字体镜像里没有（如微软雅黑、宋体），已用 `fonts-liberation` 做西文替代、`Noto CJK` 做中文替代。若要求 100% 一致，把公司有授权的对应字体放进镜像（`/usr/share/fonts/` 后 `fc-cache -f`） |
| 个别汉字字形偏「日式」 | Noto CJK 是合集（OTC），LibreOffice 对缺失字体做回退时可能选中 JP 字面，少数汉字（如「直/骨/具」）笔画略有差异，但文字内容与排版不受影响。镜像已把通用字族与「宋体/微软雅黑」优先指向简体（`/etc/fonts/conf.d/64-ok-cjk-sc.conf`）；追求完全一致请直接放入原字体 |
| 转换超时 | 大文件/复杂表格：调大 `PREVIEW_TIMEOUT_SECONDS`，或调大 `PREVIEW_CONCURRENCY`（注意 CPU） |
| 构建时拉不到基础镜像 | 换 `--build-arg RUNTIME_IMAGE=...`，或在 Docker Desktop 配镜像加速器 |
| 容器被 OOM Kill | `MaxRAMPercentage=75` 之外还要给 LibreOffice 留内存；建议 `mem_limit: 2g` 起步，预览并发数别超过 CPU 核数 |
| 上传大文件失败 | 上限在 `application.yml`（单文件 20MB / 单请求 120MB），另需注意反向代理的 `client_max_body_size` |
