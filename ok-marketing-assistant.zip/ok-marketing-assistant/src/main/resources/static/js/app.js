/* ============================================================
 * OK营销助手 — Vue 2 前端逻辑（静态引用 vue.min.js，无构建）
 * 单体应用：与 /api/** 同源，会话与消息统一走 /api/chat/**
 * ============================================================ */
(function () {
    'use strict';

    var API = ''; // 同源（由 ok-gateway 提供 static + /api 代理）

    /* 静态资源版本参数（避免浏览器 / 中间代理缓存旧的前端文件）：
       正常由服务端 AssetVersionFilter 注入 window.okAsset（js/css/图片按内容哈希逐个加 v，
       HTML 里的字面量引用由服务端直接改写）；这里仅作兜底，
       保证页面脱离服务端打开、或服务端关闭该功能时调用不报错。
       —— js 里「动态拼接」的资源地址（如 'assets/' + it.icon + '@2x.png'）请用它包一层。 */
    if (!window.okAsset) {
        window.okAsset = function (url) {
            var v = window.OK_ASSET_VERSION;
            if (!v || !url) { return url; }
            var s = String(url);
            if (/^(https?:)?\/\//.test(s) || s.indexOf('data:') === 0 || s.indexOf('blob:') === 0
                || s.indexOf('?') > -1 || s.indexOf('#') > -1) {
                return s;
            }
            return s + '?v=' + v;
        };
    }

    /* 拼接后的资源地址统一走 okAsset（Vue 模板里的动态 :src 同样可调用，见 index.html） */
    var okAsset = window.okAsset;

    /* 底部三个菜单 → Chatflow 输入参数 operatetype 的取值。
       选中哪个菜单（quickTab），后续发送的消息就携带对应取值。 */
    var OPERATE_TYPE = { menu: '菜单查找', task: '今日任务', market: '营销助手' };

    /* 反向映射：Chatflow 返回的 operatetype → 底部菜单。
       打开历史会话时，按该会话所属的 operatetype 默认选中对应菜单。 */
    var TAB_BY_OPERATE = { '菜单查找': 'menu', '今日任务': 'task', '营销助手': 'market' };

    /* 「+」按钮附件白名单：与 Dify 侧文件参数（预设变量 userinput.files）勾选的
       「文档 + 图片」类型一致（服务端会再校验一次并按扩展名判定 image/document） */
    var DOC_EXTS = ['txt', 'md', 'mdx', 'markdown', 'pdf', 'html', 'xlsx', 'xls', 'doc', 'docx',
        'csv', 'eml', 'msg', 'ppt', 'pptx', 'xml', 'epub'];
    var IMG_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    /* 相机拍的照片：真机（尤其 Android WebView）返回的文件可能没有扩展名，
       按 MIME 反推扩展名补上，否则服务端会把图片误判成文档（预览就走不了图片分支） */
    var IMG_MIME_EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };

    /* 可在弹层内联预览的文档类型：
       · pdf  → 直接用本地化的 pdf.js 渲染（不依赖浏览器自带 PDF 插件，移动端也能看）
       · office（word/excel/ppt/csv…）→ 服务端用 LibreOffice 转成 PDF 后再渲染
       必须与后端 DocumentPreviewService 的判定保持一致，改一处要同步另一处 */
    var PDF_EXTS = ['pdf'];
    var OFFICE_PREVIEW_EXTS = ['doc', 'docx', 'docm', 'dot', 'dotx', 'rtf', 'odt',
        'xls', 'xlsx', 'xlsm', 'xlt', 'xltx', 'ods', 'csv', 'tsv',
        'ppt', 'pptx', 'pptm', 'pot', 'potx', 'odp'];
    /* 单份文档最多渲染多少页（超长文档只渲染前 N 页，避免手机把内存吃满） */
    var PDF_MAX_PAGES = 50;

    /* ---- 对话等待与超时 ----
       Chatflow 里串了知识检索 / 多轮工具调用时，一次回复 1~2 分钟很常见，所以：
       · 后端 Dify 读超时 = 3 分钟（ok.assistant.dify.timeout-ms，默认 180000）
       · 前端对话请求超时 = 3.5 分钟，比后端多 30 秒
         这样正常情况下总是后端先超时、返回「AI 服务响应超时（已等待 3 分钟）…」，
         前端只在后端完全没响应（网络断了、进程挂了）时才兜底提示，
         避免两边同时超时、用户看到的是含糊的「网络异常」。 */
    var CHAT_TIMEOUT_MS = 210000;

    /* 等待期间的渐进提示（毫秒 → 文案）。只提示、不打断，
       让用户知道「不是卡死了，还在跑」。 */
    var WAIT_HINTS = [
        { after: 30000, text: '内容较多，正在生成中，请稍候…' },
        { after: 120000, text: '仍在处理，较长的问题可能需要 1~2 分钟…' },
        { after: 165000, text: '响应较慢，最多再等 1 分钟…' }
    ];

    function extOf(name) {
        var i = String(name || '').lastIndexOf('.');
        return i > -1 ? name.slice(i + 1).toLowerCase() : '';
    }

    /* 预览类型：'pdf'（原件）/ 'office'（需服务端转 PDF）/ ''（只能下载） */
    function previewKindOf(name) {
        var ext = extOf(name);
        if (PDF_EXTS.indexOf(ext) > -1) { return 'pdf'; }
        if (OFFICE_PREVIEW_EXTS.indexOf(ext) > -1) { return 'office'; }
        return '';
    }

    /* 拍照文件名用的时间戳：照片_20261015_154500.jpg */
    function photoStamp() {
        var d = new Date();
        var p = function (n) { return (n < 10 ? '0' : '') + n; };
        return '' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_'
            + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
    }

    /* ============ 卡片附加数据（extra_data）通用工具 ============
       Chatflow 可在任意卡片的应答 JSON 里带一个可选的 extra_data（任意 JSON，如企业统一社会
       信用代码）。它只给后台用，不参与展示：卡片被点击时，它随「用户可见的输入文本」一起发给
       后台，由后端合成 query 信封 {"userinput":"…","extra_data":…} 交给 Chatflow。

       取值规则（必须与后端 QueryPayload.normalize 对齐，否则两侧行为不一致）：
         · 空值（null / undefined / 空串 / 空对象 / 空数组）→ 忽略；
         · 字符串以 { 或 [ 开头 → 尝试按 JSON 解析（解析失败则按普通字符串原样传）；
         · 其余（对象 / 数组 / 数字 / 布尔 / 普通字符串）→ 原样透传。
       即「Chatflow 写什么就传什么」，应用侧不做「必须是对象」的假设 —— 否则像 list[].extra_data
       写成 "1" 这类标量会被静默丢掉，最终变成空对象 {}。

       多来源合并：对象之间按键合并（后者覆盖前者）；只要出现非对象来源，就以最后一个非对象
       来源原样为准。条目级（list[].extra_data）覆盖卡片级，函数入参显式传入优先级最高。 */
    function isPlainObject(v) {
        return v !== null && typeof v === 'object' && !Array.isArray(v);
    }

    /* 空附加数据判定（与后端 QueryPayload.isEmpty 对齐）：null / undefined / 空串 / 空对象 / 空数组 */
    function isEmptyExtra(v) {
        if (v === null || v === undefined) { return true; }
        if (typeof v === 'string') { return v.trim() === ''; }
        if (Array.isArray(v)) { return v.length === 0; }
        if (isPlainObject(v)) { return Object.keys(v).length === 0; }
        return false;
    }

    /* 归一化单个来源的附加数据 → 归一化后的值；空值返回 null */
    function parseExtra(v) {
        if (typeof v === 'string') {
            var s = v.trim();
            if (s === '') { return null; }
            if (s.charAt(0) === '{' || s.charAt(0) === '[') {
                try {
                    var parsed = JSON.parse(s);
                    return isEmptyExtra(parsed) ? null : parsed;
                } catch (e) {
                    // 不是合法 JSON 文本：按普通字符串原样传
                }
            }
            return v;
        }
        return isEmptyExtra(v) ? null : v;
    }

    /* 合并多份附加数据（规则见上）：按参数顺序「后者覆盖」——
       对象来源与已累积的对象按键合并；非对象来源则清掉之前的对象，整体以其为准。全空返回 null */
    function mergeExtra() {
        var obj = null;          // 对象来源的键合并结果
        var val = null;          // 非对象来源（出现时丢弃已累积的对象）
        for (var i = 0; i < arguments.length; i++) {
            var v = parseExtra(arguments[i]);
            if (v === null) { continue; }
            if (isPlainObject(v)) {
                obj = obj || {};
                for (var k in v) {
                    if (Object.prototype.hasOwnProperty.call(v, k)) { obj[k] = v[k]; }
                }
                val = null;
            } else {
                obj = null;
                val = v;
            }
        }
        return obj !== null ? obj : val;
    }

    /* 从卡片或条目对象上取附加数据（兼容 extra_data / extraData 两种写法） */
    function extraOf(o) {
        if (!o || typeof o !== 'object') { return null; }
        return mergeExtra(o.extra_data, o.extraData);
    }

    /* 统一请求入口：令牌的获取与携带、401 的统一处理都在 js/auth.js（OKAuth）里，
       业务只关心地址与参数，不直接碰 fetch / 令牌。
       opts.timeoutMs 只给「可能很久」的接口用（对话），普通接口保持不设超时。 */
    function http(method, url, body, opts) {
        var o = { body: body };
        if (opts && opts.timeoutMs) { o.timeoutMs = opts.timeoutMs; }
        return OKAuth.request(method, url, o);
    }

    /* 等待期间的渐进提示：到点换一句文案，让用户知道不是卡死了。
       文案挂在对应的 tab 上，切菜单不会串台；定时器存在 tab._waitTimers（不需要响应式）。 */
    function startWaitHints(tab) {
        stopWaitHints(tab);
        tab._waitTimers = WAIT_HINTS.map(function (h) {
            return setTimeout(function () {
                if (tab.waiting) { tab.waitHint = h.text; }
            }, h.after);
        });
    }

    function stopWaitHints(tab) {
        if (tab._waitTimers) {
            tab._waitTimers.forEach(function (t) { clearTimeout(t); });
            tab._waitTimers = [];
        }
        tab.waitHint = '';
    }

    /* ============ 原生容器「拍照 / 相册」上传 ============
       外层框架提供 selectPicture：H5 只负责唤起，选图与上传都由原生完成（传到门户文件服务器），
       结果通过全局函数 receiveSelectPicture(msg, data) 回传：
           msg  = 'success' | 其它（失败）
           data = JSON 串，形如 { uploadInfo: { errcode: '0000', errmsg: '' }, ...文件信息 }
       字段名各端不完全统一，这里按常见写法做宽容匹配；拿不到就只提示失败，不猜。 */

    /* 从两个对象里按候选键名取第一个非空值 */
    function pickField(a, b, keys) {
        for (var i = 0; i < keys.length; i++) {
            var k = keys[i];
            var v = a ? a[k] : undefined;
            if (v === undefined || v === null || v === '') { v = b ? b[k] : undefined; }
            if (v !== undefined && v !== null && v !== '') { return v; }
        }
        return '';
    }

    /* 解析回调。兼容两种调用形态：
         receiveSelectPicture('success', '{...}')   —— 门户示例的写法
         receiveSelectPicture('{...}')              —— 部分安卓实现只回一个 JSON 串
       成功条件与示例一致：uploadInfo.errcode === '0000'。 */
    function parseNativePicked(msg, data) {
        var raw = data;
        if (raw === undefined && typeof msg === 'string'
            && msg.replace(/^\s+/, '').charAt(0) === '{') {
            raw = msg;
            msg = 'success';
        }
        if (String(msg) !== 'success') {
            return { ok: false, message: '上传失败' };
        }
        var obj = raw;
        if (typeof obj === 'string') {
            try { obj = JSON.parse(obj); } catch (e) { return { ok: false, message: '上传失败：返回数据无法解析' }; }
        }
        if (!obj || typeof obj !== 'object') {
            return { ok: false, message: '上传失败：未返回文件信息' };
        }
        var info = obj.uploadInfo || obj.upload_info || {};
        var code = info.errcode !== undefined ? info.errcode
            : (obj.errcode !== undefined ? obj.errcode : '0000');
        if (String(code) !== '0000') {
            return { ok: false, message: '上传失败' + (info.errmsg ? '：' + info.errmsg : '') };
        }
        return {
            ok: true,
            url: pickField(obj, info, ['fileUrl', 'fileURL', 'filePath', 'file_path', 'downloadUrl',
                'httpUrl', 'url', 'path']),
            base64: pickField(obj, info, ['base64', 'fileBase64', 'content', 'fileContent', 'fileData']),
            name: pickField(obj, info, ['fileName', 'filename', 'originalName', 'orgName', 'name']),
            size: Number(pickField(obj, info, ['fileSize', 'filesize', 'size']) || 0),
            mime: pickField(obj, info, ['mimeType', 'contentType', 'fileType']),
            id: pickField(obj, info, ['fileId', 'file_id', 'attachId', 'attachmentId', 'id'])
        };
    }

    /* data:image/jpeg;base64,... 或纯 base64 → File（交给统一上传流程） */
    function base64ToFile(b64, name, mime) {
        try {
            var s = String(b64);
            var m = s.match(/^data:([^;]+);base64,(.*)$/);
            var type = m ? m[1] : (mime || 'image/jpeg');
            var bin = window.atob(m ? m[2] : s);
            var buf = new Uint8Array(bin.length);
            for (var i = 0; i < bin.length; i++) { buf[i] = bin.charCodeAt(i); }
            return new File([buf], name, { type: type });
        } catch (e) {
            return null;
        }
    }

    function uid() {
        return 'L' + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
    }

    /* 浏览器内存里的本地文件副本地址（blob:）：仅供「刚选中 / 刚发送」的即时预览。
       服务端不保存任何附件，历史附件一律实时向 Dify 取；本地副本刷新页面即失效。 */
    function blobOf(file) {
        try { return URL.createObjectURL(file); } catch (e) { return ''; }
    }

    /* ============ PDF 渲染（本地化 pdf.js，按需加载） ============
       为什么不用 <iframe> 交给浏览器自带的 PDF 阅读器：移动端不可靠 ——
       iOS Safari 只显示第一页、Android Chrome 干脆不渲染 iframe 里的 PDF。
       自己用 pdf.js 画 canvas 才能做到手机与桌面表现一致，也不依赖浏览器插件。

       pdf.min.js / pdf.worker.min.js 都在 js/vendor/ 下（随项目分发，不连外网），
       只在第一次打开文档预览时加载，不影响首屏。 */
    var pdfJsLoading = null;

    function ensurePdfJs() {
        if (window.pdfjsLib) { return Promise.resolve(window.pdfjsLib); }
        if (pdfJsLoading) { return pdfJsLoading; }
        pdfJsLoading = new Promise(function (resolve, reject) {
            // 动态地址必须包 okAsset 才会有版本号，否则库更新后浏览器可能还用旧缓存
            var asset = function (p) {
                return typeof window.okAsset === 'function' ? window.okAsset(p) : p;
            };
            var s = document.createElement('script');
            s.src = asset('js/vendor/pdf.min.js');
            s.onload = function () {
                if (!window.pdfjsLib) { reject(new Error('PDF 组件加载异常')); return; }
                window.pdfjsLib.GlobalWorkerOptions.workerSrc = asset('js/vendor/pdf.worker.min.js');
                resolve(window.pdfjsLib);
            };
            s.onerror = function () {
                pdfJsLoading = null;
                reject(new Error('PDF 组件加载失败，请下载后查看'));
            };
            document.head.appendChild(s);
        });
        return pdfJsLoading;
    }

    /* 把 PDF 逐页画进容器（顺序渲染，避免长文档一次性吃满内存）。
       alive() 返回 false（弹层已关闭或换了别的附件）时立即停止并释放文档。 */
    function renderPdfInto(box, data, alive) {
        return ensurePdfJs().then(function (lib) {
            return lib.getDocument({ data: data }).promise;
        }).then(function (pdf) {
            var total = Math.min(pdf.numPages, PDF_MAX_PAGES);
            var chain = Promise.resolve();
            for (var n = 1; n <= total; n++) {
                chain = chain.then(function (pageNo) {
                    return function () {
                        if (!alive()) { pdf.destroy(); return null; }
                        return pdf.getPage(pageNo).then(function (page) {
                            if (!alive()) { return null; }
                            var base = page.getViewport({ scale: 1 });
                            var width = box.clientWidth || 300;
                            // 最多放大到 2 倍：小屏铺满宽度，大屏不至于糊
                            var scale = Math.min(width / base.width, 2);
                            var vp = page.getViewport({ scale: scale });
                            var dpr = window.devicePixelRatio || 1;
                            var canvas = document.createElement('canvas');
                            canvas.className = 'pdf-page';
                            canvas.width = Math.floor(vp.width * dpr);
                            canvas.height = Math.floor(vp.height * dpr);
                            canvas.style.width = vp.width + 'px';
                            canvas.style.height = vp.height + 'px';
                            box.appendChild(canvas);
                            return page.render({
                                canvasContext: canvas.getContext('2d'),
                                viewport: vp,
                                transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null
                            }).promise;
                        });
                    };
                }(n));
            }
            return chain.then(function () {
                if (!alive()) { pdf.destroy(); return; }
                var more = document.createElement('div');
                more.className = 'pdf-more';
                more.textContent = pdf.numPages > PDF_MAX_PAGES
                    ? ('共 ' + pdf.numPages + ' 页，已显示前 ' + PDF_MAX_PAGES + ' 页，可下载查看全文')
                    : ('共 ' + pdf.numPages + ' 页');
                box.appendChild(more);
            });
        });
    }

    /* 原生容器通信（js/jsBridge.js 挂的全局对象）：模板里可用 this.$JSBridge */
    Vue.prototype.$JSBridge = window.$JSBridge;

    new Vue({
        el: '#app',
        data: function () {
            return {
                isMobile: window.innerWidth <= 500,
                /* 当前用户：全部来自 /api/chat/profile（后端由 userToken 经 SM4 解密得到），
                   前端不内置任何用户信息 */
                profile: { name: '', userId: '', dept: '' },
                /* 「+」按钮的待发送附件与上传限制（后者由 /api/chat/profile 的 upload 下发） */
                attachments: [],
                uploadCfg: { maxFiles: 10, docMaxMb: 15, imageMaxMb: 10 },
                /* 文档在线预览能力（由 /api/chat/profile 下发）：available=false 时
                   Word/Excel/PPT 无法在服务端转 PDF，弹层直接给「下载查看」的提示 */
                previewCfg: { enabled: true, available: true, maxSizeMb: 20 },
                /* 原生容器跳转约定（由 /api/chat/profile 的 native 下发）：
                   enabled = 是否走 JSBridge；baseUrl = 子页面地址前缀（对应门户的 VUE_APP_CUSTOMER_IP） */
                nativeCfg: { enabled: true, baseUrl: '' },
                /* 附件预览层（点击消息里的附件 chips 打开） */
                fileView: null,
                /* 本标签页内附件字节的浏览器副本（id → blob: 地址），仅用于「刚选中/刚发送」的即时预览：
                   服务端不保存任何附件（无状态、可集群部署），历史附件一律实时向 Dify 取。
                   页面刷新即失效，之后自动回落到服务端地址。 */
                fileBlobs: {},
                quickTab: 'market',         // 当前底部菜单：menu | task | market
                /* 三个底部菜单各自独立维护会话状态，切换菜单互不影响：
                   有 conversationId = 该菜单下已有打开的会话 → 切回时展示该会话
                   没有 conversationId = 展示初始化窗口（欢迎页），且不自动发消息 */
                tabs: {
                    menu: { conversationId: '', messages: [], view: 'home', waiting: false, waitHint: '' },
                    task: { conversationId: '', messages: [], view: 'home', waiting: false, waitHint: '' },
                    market: { conversationId: '', messages: [], view: 'home', waiting: false, waitHint: '' }
                },
                draft: '',
                sending: false,
                drawerOpen: false,
                drawerKeyword: '',
                /* 最近会话列表：服务端分页 + 服务端检索
                   conversations = 已加载的条目（追加式）；offset 由长度推导，不单独维护
                   convHasMore   = 后端是否还有下一页 → 控制「更多」
                   convLoading   = 加载中（首屏与「更多」共用）
                   convPageSize  = 每页条数，来自后端 profile（默认 15，后端 ok.assistant.conversation-page-size）
                   convSeq       = 请求序号，用于丢弃过期响应（快速改关键词时会并发） */
                conversations: [],
                convPageSize: 15,
                convHasMore: false,
                convLoading: false,
                convSeq: 0,
                convTimer: null,
                currentCompany: '',
                toastText: '',
                toastTimer: null,
                detailOpen: false,   // 段落详情「跳转」占位层（本地效果）
                detailTitle: ''
            };
        },
        computed: {
            /* 以下三项是「当前菜单」对应 tab 状态的读写代理，
               原有代码（this.view / this.messages / this.conversationId）无需改动 */
            view: {
                get: function () { return this.tabs[this.quickTab].view; },
                set: function (v) { this.tabs[this.quickTab].view = v; }
            },
            conversationId: {
                get: function () { return this.tabs[this.quickTab].conversationId; },
                set: function (v) { this.tabs[this.quickTab].conversationId = v; }
            },
            messages: {
                get: function () { return this.tabs[this.quickTab].messages; },
                set: function (v) { this.tabs[this.quickTab].messages = v; }
            },
            /* 等待回复动效：按菜单隔离（发送后亮起、响应/异常后熄灭，中途切菜单不串台） */
            waiting: {
                get: function () { return this.tabs[this.quickTab].waiting; },
                set: function (v) { this.tabs[this.quickTab].waiting = v; }
            },
            /* 等待中的渐进提示（30s / 2min / 2min45s 各变一次文案），同样按菜单隔离 */
            waitHint: {
                get: function () { return this.tabs[this.quickTab].waitHint || ''; },
                set: function (v) { this.tabs[this.quickTab].waitHint = v || ''; }
            },
            filteredConversations: function () {
                // 检索已改为服务端完成（/api/chat/conversations?keyword=），此处仅作兼容别名
                return this.conversations;
            },
            /* 初始化窗口文案：按当前底部菜单取（后端 ok.assistant.welcome.* 可配置），
               后端未配置或接口未返回时回落到默认文案 */
            welcomeTitle: function () {
                var w = (this.profile.welcomes || {})[this.quickTab];
                return (w && w.title) || '您好，我是OK营销助手';
            },
            welcomeSub: function () {
                var w = (this.profile.welcomes || {})[this.quickTab];
                return (w && w.sub) || '您可以输入客户关键词开始我们的会话！';
            }
        },
        watch: {
            /* 进入「可返回」的状态时压入一条历史记录，
               使 Android 物理返回键 / 浏览器返回键能逐级回退，而不是直接退出页面 */
            drawerOpen: function (v) {
                if (v && !this._backNav) { this.pushHistory(); }
                // 打开侧滑时重新取第一页，保证列表是新的（含会话语义上的「最近」）
                if (v) { this.loadConversations(); }
            },
            /* 检索关键词变化 → 防抖 300ms 后走服务端检索（重新取第一页）。
               注：检索不再对已加载列表做本地过滤，否则会漏掉尚未加载的更早会话。 */
            drawerKeyword: function () {
                var self = this;
                if (this.convTimer) { clearTimeout(this.convTimer); }
                this.convTimer = setTimeout(function () { self.loadConversations(); }, 300);
            },
            view: function (v) {
                if (v === 'chat' && !this._backNav) { this.pushHistory(); }
            }
        },
        created: function () {
            var self = this;
            this._backNav = false;
            /* 原生容器「拍照 / 相册」的回调入口。
               外层框架不通过 JSBridge 的 callbackId 回传，而是固定调用这个全局函数名：
                   window.receiveSelectPicture(msg, data)
               放在 created 里注册（而不是 mounted），避免页面还没渲染完就点相机导致回调丢失。 */
            window.receiveSelectPicture = function (msg, data) {
                self.onNativePicked(msg, data);
            };
            /* 统一校验失败处理入口（js/auth.js）：
               userToken 缺失 / 解密失败 / 已过期时走到这里。
               容器内可在此调用原生方法回到门户登录页（重新拿到 userToken 后再进入）。 */
            OKAuth.onAuthFail(function (info) {
                self.toast((info && info.message) ? info.message : '登录状态已失效，请重新登录');
            });
            http('GET', '/api/chat/profile').then(function (p) {
                self.profile = p;
                if (p && p.upload) { self.uploadCfg = p.upload; }
                if (p && p.preview) { self.previewCfg = p.preview; }
                if (p && p.native) { self.nativeCfg = p.native; }
                // 每页条数由后端配置下发（默认 15）
                if (p && p.conversationPageSize) { self.convPageSize = p.conversationPageSize; }
                /* 调试面板开关：debug.js 与 app.js 各自加载，用「全局变量 + 事件」两路发布，
                   保证 debug.js 无论先加载还是后加载都能拿到（后端关闭时不渲染任何入口） */
                window.OK_DEBUG_CFG = (p && p.debug) ? p.debug : { enabled: false };
                try {
                    document.dispatchEvent(new CustomEvent('ok:profile', { detail: p }));
                } catch (e) {
                    /* 老 WebView 不支持 CustomEvent 构造：只靠上面的全局变量 */
                }
            }).catch(function () {}).then(function () {
                // 首屏会话列表放在 profile 之后取：先用后端下发的每页条数，避免第一页用了默认值
                self.loadConversations();
            });
            this.setupMobile();
            // 演示模式：?scene=search/analysis/industry/biz/opp/script/task/flow/report/menu/drawer
            var scene = new URLSearchParams(window.location.search).get('scene');
            if (scene) {
                setTimeout(function () { self.runScene(scene); }, 500);
            }
        },
        methods: {
            /* 静态资源版本参数：模板里动态拼接的 :src 统一用它包一层，
               实现见文件顶部的 window.okAsset（版本号由服务端按内容哈希注入） */
            okAsset: function (url) {
                return okAsset(url);
            },

            /* ---------------- 真机适配 ---------------- */
            /* 1) 旋屏 / 窗口变化时同步 isMobile（决定是否套 375px 手机壳）
               2) 软键盘：iOS 上 100dvh 不随键盘收缩，用 visualViewport 算出键盘高度写入 CSS 变量 --kb
               3) Android 物理返回键 / 浏览器返回：关抽屉 -> 退回首页 -> 再退出 */
            setupMobile: function () {
                var self = this;

                var syncMobile = function () {
                    self.isMobile = window.innerWidth <= 500;
                };
                window.addEventListener('resize', syncMobile);
                window.addEventListener('orientationchange', function () {
                    setTimeout(syncMobile, 200);
                });

                var vv = window.visualViewport;
                if (vv) {
                    var applyKeyboard = function () {
                        var kb = window.innerHeight - vv.height - vv.offsetTop;
                        kb = kb > 60 ? Math.round(kb) : 0;   // 小于 60px 视为地址栏伸缩，不算键盘
                        document.documentElement.style.setProperty('--kb', kb + 'px');
                        if (kb > 0) { self.scrollToBottom(); }
                    };
                    vv.addEventListener('resize', applyKeyboard);
                    vv.addEventListener('scroll', applyKeyboard);
                }

                window.addEventListener('popstate', function () {
                    self._backNav = true;
                    if (self.drawerOpen) {
                        self.drawerOpen = false;
                    } else if (self.view === 'chat') {
                        self.backHome();
                    }
                    setTimeout(function () { self._backNav = false; }, 0);
                });
            },
            pushHistory: function () {
                try { history.pushState({ okView: Date.now() }, ''); } catch (e) { /* file:// 等环境不支持则忽略 */ }
            },

            /* ---------------- toast ---------------- */
            /* 轻提示。错误信息通常更长、更需要时间读完，所以支持指定停留时长（默认 1.8s，错误给 5s） */
            toast: function (text, durationMs) {
                var self = this;
                this.toastText = text;
                if (this.toastTimer) { clearTimeout(this.toastTimer); }
                this.toastTimer = setTimeout(function () { self.toastText = ''; }, durationMs || 1800);
            },

            /* ---------------- 会话 ---------------- */
            /* 最近会话 = 服务端分页列表：
               首屏 / 换关键词 / 打开侧滑 / 新会话 / 发送成功 → 重取第一页（默认 reset）
               点「更多」→ 以「已加载条数」为 offset 取下一页（append=true）
               opts.limit 用于删除后按已加载深度重取，保持用户的浏览位置
               检索一律走后端（keyword 参数），前端不再本地过滤 */
            loadConversations: function (opts) {
                var self = this;
                var append = !!(opts && opts.append);
                var kw = (this.drawerKeyword || '').trim();
                var offset = append ? this.conversations.length : 0;
                var limit = (opts && opts.limit) || this.convPageSize || 15;
                var seq = ++this.convSeq;
                this.convLoading = true;
                return this.fetchConversations(kw, offset, limit).then(function (page) {
                    if (seq !== self.convSeq) { return; }   // 过期响应（关键词已变）直接丢弃
                    self.convLoading = false;
                    self.conversations = append ? self.conversations.concat(page.list) : page.list;
                    self.convHasMore = page.hasMore;
                }).catch(function () {
                    if (seq === self.convSeq) { self.convLoading = false; }
                });
            },
            /* 兼容两种响应：分页对象 {list,total,offset,limit,hasMore}；纯数组（老后端/本地桩）按「单页、无更多」处理 */
            fetchConversations: function (kw, offset, limit) {
                var url = '/api/chat/conversations?offset=' + offset + '&limit=' + limit
                    + (kw ? '&keyword=' + encodeURIComponent(kw) : '');
                return http('GET', url).then(function (data) {
                    if (Object.prototype.toString.call(data) === '[object Array]') {
                        return { list: data, hasMore: false };
                    }
                    return {
                        list: (data && data.list) || [],
                        hasMore: !!(data && data.hasMore)
                    };
                });
            },
            /* 「更多」：继续加载接下来的数据（每次 convPageSize 条，条数由后端配置） */
            loadMoreConversations: function () {
                if (this.convLoading || !this.convHasMore) { return; }
                this.loadConversations({ append: true });
            },
            /* 顶部「新会话」：只重置当前菜单的状态，回到初始化窗口，不调接口、不发消息。
               后端在首次「发送消息」时看到 conversationId 为空，才真正创建会话。 */
            newConversation: function () {
                this.conversationId = '';
                this.messages = [];
                this.waiting = false;
                stopWaitHints(this.tabs[this.quickTab]);
                this.currentCompany = '';
                this.draft = '';
                this.attachments = [];
                this.view = 'home';
                this.loadConversations();
            },
            /* 底部菜单切换：只切换菜单，不发消息（可任意来回切换）。
               目标菜单下已有打开的会话 → 展示该会话；没有 → 展示初始化窗口。 */
            switchTab: function (type) {
                if (!this.tabs[type] || this.quickTab === type) { return; }
                var self = this;
                this._backNav = true;       // 菜单切换不产生返回栈记录
                this.quickTab = type;
                var tab = this.tabs[type];
                if (!tab.conversationId) {
                    if (tab.waiting || tab.messages.length > 0) {
                        // 有进行中的发送或已有消息：保留现场（响应回来会继续回填到该 tab）
                        tab.view = 'chat';
                    } else {
                        tab.messages = [];
                        tab.view = 'home';
                    }
                } else {
                    tab.view = 'chat';
                }
                this.drawerOpen = false;
                // 切换菜单不清空输入框：草稿内容跨菜单保留（只有「发送成功」「新会话」才清空）
                this.$nextTick(function () { self.scrollToBottom(); });
                setTimeout(function () { self._backNav = false; }, 0);
            },
            /* 从侧滑打开某个历史会话：
               1) 按会话的 operatetype 自动选中对应的底部菜单（列表未返回时用消息里的兜底）
               2) 会话绑定到该菜单，并展示消息 */
            openConversation: function (c) {
                var self = this;
                this.drawerOpen = false;
                this.draft = '';
                http('GET', '/api/chat/conversations/' + c.id + '/messages').then(function (list) {
                    var msgs = self.hydrate(list || []);
                    var tabKey = TAB_BY_OPERATE[c.operateType] || self.tabOfMessages(msgs) || self.quickTab;
                    self.quickTab = tabKey;
                    var tab = self.tabs[tabKey];
                    tab.conversationId = c.id;
                    tab.messages = msgs;
                    tab.view = 'chat';
                    self.scrollToBottom();
                }).catch(function (e) {
                    self.toast(e.message || '会话加载失败');
                });
            },
            /* 消息里的 operatetype 兜底：取第一条带菜单归属的消息所对应的菜单 */
            tabOfMessages: function (list) {
                for (var i = 0; i < list.length; i++) {
                    var op = list[i] && list[i].operateType;
                    if (op && TAB_BY_OPERATE[op]) { return TAB_BY_OPERATE[op]; }
                }
                return '';
            },
            /* 删除会话：若该会话正被某个菜单打开，则把对应菜单重置为初始化窗口 */
            deleteConversation: function (c) {
                var self = this;
                http('DELETE', '/api/chat/conversations/' + c.id).then(function () {
                    // 按已加载深度重取，避免删一条就被打回第一页
                    self.loadConversations({ limit: self.conversations.length || self.convPageSize });
                    self.resetTabHolding(c.id);
                });
            },
            clearConversations: function () {
                var self = this;
                http('DELETE', '/api/chat/conversations').then(function () {
                    self.conversations = [];
                    self.convHasMore = false;
                    self.convLoading = false;
                    Object.keys(self.tabs).forEach(function (k) {
                        self.tabs[k].conversationId = '';
                        self.tabs[k].messages = [];
                        self.tabs[k].view = 'home';
                    });
                    self.draft = '';
                    self.currentCompany = '';
                });
            },
            /* 把持有指定会话的菜单重置为初始化窗口 */
            resetTabHolding: function (conversationId) {
                var self = this;
                Object.keys(this.tabs).forEach(function (k) {
                    if (self.tabs[k].conversationId === conversationId) {
                        self.tabs[k].conversationId = '';
                        self.tabs[k].messages = [];
                        self.tabs[k].view = 'home';
                        self.tabs[k].waiting = false;
                        stopWaitHints(self.tabs[k]);
                    }
                });
            },
            backHome: function () {
                this.drawerOpen = false;
                this.view = 'home';
                this.loadConversations();
            },

            /* ---------------- 消息发送 ---------------- */
            send: function () {
                var text = (this.draft || '').trim();
                if (this.sending) { return; }
                if (!text && !this.attachments.length) { return; }
                var uploading = this.attachments.filter(function (a) { return a.status === 'uploading'; }).length;
                if (uploading > 0) { this.toast('附件上传中，请稍候'); return; }
                var failed = this.attachments.filter(function (a) { return a.status === 'error'; }).length;
                if (failed > 0) { this.toast('有附件上传失败，请移除后再发送'); return; }
                // 快照当前附件（发送后附件条清空，气泡里的引用不受影响）
                // url 只在「原生已上传但取不回字节」时才有：这种附件没有 Dify 的 file id，
                // 由后端改用 transfer_method=remote_url 把地址交给 Dify。
                var files = this.attachments.length
                    ? this.attachments.map(function (a) {
                        return { id: a.id, name: a.name, size: a.size, kind: a.kind, url: a.url || '' };
                    }) : null;
                var content = text || '请查看我上传的文件';
                this.attachments = [];
                this.dispatch({ content: content, files: files });
            },
            /* 卡片点击的统一发送入口（通用）
               —— opts.content：用户可见的输入文本（用户气泡展示的就是它，如企业名称）
               —— opts.item   ：被点击的条目对象，自动取其 extra_data
               —— opts.extra  ：调用点显式提供的附加数据（优先级最高）
               其余字段（intent/company/scene/category/companyCard）原样透传给 dispatch。
               附加数据合并顺序：卡片 extra_data → 条目 extra_data → 显式 extra。 */
            cardSend: function (msg, opts) {
                opts = opts || {};
                var payload = {
                    content: opts.content,
                    intent: opts.intent,
                    company: opts.company,
                    scene: opts.scene,
                    category: opts.category,
                    companyCard: opts.companyCard,
                    localImages: opts.localImages
                };
                var extra = mergeExtra(extraOf(msg), extraOf(opts.item), opts.extra);
                // 注意用 null 判定：extra_data 允许是 0 / false / "xxx" 这类标量（Chatflow 写什么传什么）
                if (extra !== null) { payload.extraData = extra; }
                this.dispatch(payload);
            },

            dispatch: function (opts) {
                var self = this;
                if (this.sending) { return; }
                this.sending = true;

                // 记录发送时所在的菜单：异步响应按该菜单回填，中途切换菜单不会串台
                var tabKey = this.quickTab;
                var tab = this.tabs[tabKey];

                // 有 conversationId 则续写，没有则由后端创建新会话并在响应里回传 id
                var isNew = !tab.conversationId;
                var cid = tab.conversationId || '';

                tab.view = 'chat';
                var userMsg = {
                    id: uid(),
                    conversationId: cid,
                    from: 'user',
                    msgType: 'TEXT',
                    content: opts.content,
                    createTime: Date.now()
                };
                // 随消息发送的附件（气泡下方展示文件 chips）
                if (opts.files && opts.files.length) {
                    userMsg.files = opts.files;
                }
                // 卡片附加数据留在本地消息上：历史回看或再次点击该气泡时能原样再传一次
                // （null 判定：extra_data 可为 0 / false / 普通字符串等标量）
                if (opts.extraData !== null && opts.extraData !== undefined) {
                    userMsg.extraData = opts.extraData;
                }
                if (opts.companyCard) {
                    userMsg._isCompanyCard = true;
                    userMsg.company = opts.companyCard.name;
                    userMsg.index = opts.companyCard.index;
                    userMsg.city = opts.companyCard.city;
                    userMsg.status = opts.companyCard.status;
                    userMsg.legalRep = opts.companyCard.legalRep;
                }
                tab.messages.push(userMsg);
                self.draft = '';
                // 等待回复动效：点亮当前菜单的等待态并滚到底部，同时启动渐进提示
                tab.waiting = true;
                startWaitHints(tab);
                self.scrollToBottom();

                var body = {
                    conversationId: cid,
                    content: opts.content,
                    operatetype: OPERATE_TYPE[tabKey] || '营销助手',
                    intent: opts.intent,
                    company: opts.company,
                    scene: opts.scene,
                    category: opts.category,
                    images: opts.localImages
                };
                if (opts.files && opts.files.length) { body.files = opts.files; }
                // 卡片附加数据（通用）：只给后台用，不参与展示；无则不传（null 判定，标量同样透传）
                if (opts.extraData !== null && opts.extraData !== undefined) { body.extraData = opts.extraData; }
                // 本地立即插入报表图片消息（上传演示）
                if (opts.intent === 'report_upload' && opts.localImages) {
                    tab.messages.push({
                        id: uid(), from: 'user', msgType: 'REPORT_IMAGES',
                        payload: { images: opts.localImages }, createTime: Date.now()
                    });
                }

                // 对话是最慢的接口（Chatflow blocking 执行），单独给 3.5 分钟超时
                http('POST', '/api/chat/messages', body, { timeoutMs: CHAT_TIMEOUT_MS }).then(function (res) {
                    tab.waiting = false;
                    stopWaitHints(tab);
                    // 后端首次发送时已建好会话，这里记住它
                    tab.conversationId = res.conversationId;
                    if (isNew) {
                        // 回填本地已插入消息的会话归属（新会话时本地拿不到 id）
                        tab.messages.forEach(function (m) {
                            if (!m.conversationId) { m.conversationId = res.conversationId; }
                        });
                    }
                    (res.messages || []).forEach(function (m) { tab.messages.push(self.hydrateOne(m)); });
                    self.loadConversations();
                    if (tabKey === self.quickTab) { self.scrollToBottom(); }
                }).catch(function (e) {
                    tab.waiting = false;
                    stopWaitHints(tab);
                    // 三类失败分开提示：超时 / 网络中断 / 服务端返回的错误
                    var msg;
                    if (e && e.timeout) {
                        msg = 'AI 服务响应超时（已等待 ' + Math.round(CHAT_TIMEOUT_MS / 60000 * 10) / 10
                            + ' 分钟），请稍后重试或把问题拆成几步提问';
                    } else if (!e || e instanceof TypeError || !e.message) {
                        msg = '网络连接中断，请检查网络后重试';
                    } else {
                        msg = e.message;
                    }
                    self.toast(msg, 5000);
                }).finally(function () {
                    self.sending = false;
                });
            },

            /* ---------------- 交互动作 ---------------- */
            /* 企业搜索结果卡：点击某条 → 用户消息显示「企业名称」，
               后台检索用的统一社会信用代码等放在该条的 extra_data 里随输入一起传
               （条目 extra_data 优先于卡片 extra_data，见 cardSend） */
            clickCompanyFromList: function (msg, c) {
                this.currentCompany = c.name;
                this.cardSend(msg, {
                    content: c.name,
                    item: c,
                    intent: 'company_click',
                    company: c.name,
                    companyCard: c
                });
            },
            /* 已发送的企业气泡（历史回看时点它可再次进入该企业）：
               支持传整个消息（能带上 extraData），也兼容历史调用点的纯字符串 */
            clickCompany: function (msg) {
                var isMsg = msg && typeof msg === 'object';
                var name = isMsg ? (msg.company || msg.content) : msg;
                this.cardSend(isMsg ? msg : null, { content: name, intent: 'company_click', company: name });
            },
            /* analysis 段落标题后的详情链接（如「全部 ›」）：
               点击为本地「跳转」占位效果（右侧滑入），不发送消息、无真实地址；
               linkQuery 字段保留，待接入真实页面后由跳转目标使用 */
            sectionLink: function (msg, sec) {
                this.detailTitle = sec.title || sec.linkText || '详情';
                this.detailOpen = true;
            },
            closeDetail: function () {
                this.detailOpen = false;
            },
            /* 深入查询统一入口：段落标题链接与 chips 选项共用同一套动作解析。
               opts.extraData = 来源卡片/消息的附加数据（extra_data），原样随输入回传后台 */
            deepAction: function (text, opts) {
                opts = opts || {};
                var t = String(text || '');
                var extra = opts.extraData;
                if (t === '拍摄报表上传' || t === '从相册选择报表') {
                    // 容器内走原生（拍/选 + 原生上传），拿回图片后按「报表上传」语义发送；否则退回浏览器选择
                    if (this.nativePick(t === '拍摄报表上传' ? 'Camera' : 'Photo', 'report')) { return; }
                    this.$refs.fileInput.click();
                    return;
                }
                if (t.indexOf('行业类型') > -1 || t.indexOf('定义') > -1) {
                    this.dispatch({ content: t, intent: 'deep_industry', company: opts.company, extraData: extra });
                } else if (t.indexOf('业务信息') > -1 || t.indexOf('准入条件') > -1) {
                    this.dispatch({ content: t, intent: 'deep_business', company: opts.company, extraData: extra });
                } else if (t.indexOf('商机线索') > -1 || t.indexOf('适用范围') > -1) {
                    this.dispatch({ content: t, intent: 'deep_opportunity', company: opts.company, category: '存款', extraData: extra });
                } else if (t.indexOf('营销话术') > -1) {
                    this.dispatch({ content: t, intent: 'deep_script', company: opts.company, scene: '办公室场景', extraData: extra });
                } else if (t === '2、规划出行路线') {
                    this.toast('已为您规划出行路线（演示）');
                } else {
                    this.dispatch({ content: t, extraData: extra });
                }
            },
            /* 消息下方的 chips：附带数据取自该条消息（Chatflow 在卡片里下发的 extra_data） */
            onChip: function (msg, chip) {
                this.deepAction(chip, { company: this.currentCompany, extraData: extraOf(msg) });
            },
            quickSearch: function (keyword) {
                this.dispatch({ content: keyword });
            },
            /* 底部三个菜单：只做菜单切换，不发消息（可任意来回切换） */
            quickMenu: function () {
                this.switchTab('menu');
            },
            quickTask: function () {
                this.switchTab('task');
            },
            quickMarket: function () {
                this.switchTab('market');
            },
            /* ---------------- 原生容器跳转（JSBridge） ----------------
               门户 App 内打开子页面必须交给原生容器（openNativePage）：
               直接用 window.open / location.href 会被 WebView 拦截或在容器外打开。
               参数与门户给的示例保持一致：
                 url / containerId / param / title / isVertical / showTitleBar / is_screens_watermark_type
               （param 在 jsBridge.js 里会被 JSON.stringify 一次 —— Android 原生侧按字符串解析） */
            openNativePage: function (opts) {
                opts = opts || {};
                var url = this.resolveNativeUrl(opts.url);
                if (!url) { this.toast('未配置跳转地址'); return false; }
                // 目标页同样靠 userToken 鉴权：带上当前凭证（已带则不重复拼）
                var tk = (window.OKAuth && OKAuth.token) ? OKAuth.token() : '';
                if (tk && url.indexOf('userToken=') < 0) {
                    url += (url.indexOf('?') > -1 ? '&' : '?') + 'userToken=' + encodeURIComponent(tk);
                }
                var bridge = window.$JSBridge;
                var enabled = !this.nativeCfg || this.nativeCfg.enabled !== false;
                if (enabled && bridge && typeof bridge.invoke === 'function') {
                    var handled = bridge.invoke('openNativePage', {
                        url: url,
                        containerId: new Date().getTime(),
                        param: opts.param || {},
                        title: opts.title || '',
                        isVertical: opts.isVertical === true,
                        showTitleBar: opts.showTitleBar === undefined ? 'true' : opts.showTitleBar,
                        is_screens_watermark_type: opts.watermark === undefined ? '-1' : opts.watermark
                    });
                    if (handled) { return true; }
                }
                // 降级（桌面浏览器 / 不在容器里调试）：新开标签页，行为可观察、便于联调
                if (window.open) { window.open(url, '_blank'); }
                return false;
            },
            /* 相对地址补前缀：菜单结果给 "/mobs4.0-TMF-SIT/..." 时拼 nativeCfg.baseUrl
               （对应门户 H5 里的 VUE_APP_CUSTOMER_IP） */
            resolveNativeUrl: function (url) {
                var u = url == null ? '' : String(url).trim();
                if (!u) { return ''; }
                if (/^(https?:)?\/\//i.test(u) || u.indexOf('data:') === 0) { return u; }
                var base = (this.nativeCfg && this.nativeCfg.baseUrl) ? String(this.nativeCfg.baseUrl).trim() : '';
                if (!base) { return u; }
                return base.replace(/\/+$/, '') + (u.charAt(0) === '/' ? u : '/' + u);
            },
            /* 菜单检索结果 → 打开原生页面
               条目字段：url（或 path / link）、param、title、bids（业务路由标识） */
            openMenu: function (it) {
                if (!it) { return; }
                var url = it.url || it.path || it.link || it.menuUrl || '';
                if (!url) {
                    this.toast('跳转功能：' + (it.label || ''));
                    return;
                }
                var bids = it.bids || it._bids || '';
                var u = String(url);
                if (bids && u.indexOf('_bids=') < 0) {
                    u += (u.indexOf('?') > -1 ? '&' : '?') + '_bids=' + encodeURIComponent(bids);
                }
                this.openNativePage({
                    url: u,
                    param: it.param || it.params || {},
                    title: it.title || it.label || ''
                });
            },
            /* 「触达任务」跳转：payload.link 有地址就走原生页面，否则保留演示提示 */
            openTaskLink: function (msg) {
                var p = (msg && msg.payload) || {};
                var url = p.link || p.url || '';
                if (!url) { this.toast('跳转触达任务页面'); return; }
                this.openNativePage({ url: url, param: p.param || {}, title: p.linkTitle || '触达任务' });
            },
            isHighlight: function (node) {
                return ['创建临时客户', '资前准备', '对公客户开户预约', '授信', '对公客户开户预约'].indexOf(node) > -1;
            },
            switchOppTab: function (msg, tab) {
                var self = this;
                msg.payload.current = tab;
                http('GET', '/api/customer/' + encodeURIComponent(this.currentCompany || '江苏国泰国际集团')
                    + '/opportunities?category=' + encodeURIComponent(tab))
                    .then(function (d) { msg.payload.list = d.list; })
                    .catch(function () { self.toast('切换失败'); });
            },
            switchScriptTab: function (msg, tab) {
                var self = this;
                msg.payload.current = tab;
                http('GET', '/api/customer/' + encodeURIComponent(this.currentCompany || '江苏国泰国际集团')
                    + '/scripts?scene=' + encodeURIComponent(tab))
                    .then(function (d) { msg.payload.list = d.list; })
                    .catch(function () { self.toast('切换失败'); });
            },
            /* 左下角相机：唤起系统相机拍照。
               优先走外层框架的 selectPicture（原生拍照 + 原生上传，图片不经过 H5）；
               不在容器内（桌面浏览器 / 普通微信）时退回 input capture=environment。 */
            onCamera: function () {
                if (this.nativePick('Camera')) { return; }
                var el = this.$refs.cameraInput;
                if (!el) { return; }
                el.click();
            },
            /* 拍照完成（浏览器降级路径）：照片作为附件上传，之后随下一条消息发出 */
            onPhotoShot: function (e) {
                var files = Array.prototype.slice.call(e.target.files || []);
                e.target.value = '';
                this.uploadFiles(files, { imageOnly: true });
            },

            /* ---------- 原生容器图片上传（外层框架 selectPicture） ---------- */

            /* 容器是否注册了 selectPicture（Android: androidNative.selectPicture；iOS: messageHandlers.selectPicture） */
            nativePickable: function () {
                var b = window.$JSBridge;
                return !!(b && typeof b.canInvoke === 'function' && b.canInvoke('selectPicture'));
            },

            /**
             * 唤起原生选图。
             * @param {string} type 'Camera' 拍照 / 'Photo' 从相册选择
             * @param {string} [mode] attach（默认，作为附件随下条消息发出）/ report（报表上传，立即发送）
             * @returns {boolean} true = 已交给原生（结果异步走 onNativePicked）
             */
            nativePick: function (type, mode) {
                if (!this.nativePickable()) { return false; }
                try {
                    // 参数结构与门户示例一致：{ type, photosNum }
                    this._nativePickMode = mode || 'attach';
                    window.$JSBridge.invoke('selectPicture', { type: type, photosNum: 1 });
                    return true;
                } catch (e) {
                    this._nativePickMode = 'attach';
                    return false;
                }
            },

            /* 原生回调：msg/data 的判定见 parseNativePicked */
            onNativePicked: function (msg, data) {
                var r = parseNativePicked(msg, data);
                var mode = this._nativePickMode || 'attach';
                this._nativePickMode = 'attach';
                if (window.console && window.console.log) {
                    // 首次联调时看这一行即可确认端上真实字段名
                    window.console.log('[native-pick] mode =', mode, 'raw =', msg, data, '→ parsed =', r);
                }
                if (!r.ok) {
                    this.toast(r.message || '上传失败');
                    return;
                }
                var name = r.name || ('照片_' + photoStamp() + '.jpg');

                // 来源是「拍摄报表上传」：不挂附件条，直接把图片当作报表消息发出去
                if (mode === 'report') {
                    var src = r.url || '';
                    if (!src && r.base64) {
                        src = String(r.base64).indexOf('data:') === 0
                            ? r.base64 : ('data:image/jpeg;base64,' + r.base64);
                    }
                    if (!src) { this.toast('上传失败：未返回图片'); return; }
                    this.dispatch({
                        content: '[报表已上传]',
                        intent: 'report_upload',
                        localImages: [src]
                    });
                    return;
                }

                // ① 原生给了 base64：转成 File 走现有 /api/chat/files，Dify 侧拿到的是真实 file id
                if (r.base64) {
                    var file = base64ToFile(r.base64, name, r.mime);
                    if (file) {
                        this.uploadFiles([file], { imageOnly: true });
                        return;
                    }
                }
                // ② 只给了地址：先试着下载成 Blob 再上传；跨域被拒则退化为「远程附件」
                if (r.url) {
                    this.attachNativeUrl({ url: r.url, name: name, size: Math.max(0, r.size) });
                    return;
                }
                this.toast('上传失败：未返回文件地址');
            },

            /**
             * 原生只回了文件地址时的处理。
             *
             * <p>优先「下载 → 重新上传到 Dify」：这样后续预览、历史回显、附件下载都走统一链路，
             * 不依赖 Dify 能否访问门户文件服务器。但门户文件服务器通常不带 CORS，
             * 跨域读不到字节时会退化为远程附件 —— 发送时由后端用
             * {@code transfer_method=remote_url} 把地址直接交给 Dify。
             */
            attachNativeUrl: function (info) {
                var self = this;
                var name = info.name || ('照片_' + photoStamp() + '.jpg');
                var item = {
                    id: '', name: name, size: info.size || 0, kind: 'image',
                    status: 'uploading', localUrl: info.url, url: info.url
                };
                this.attachments.push(item);

                var done = function () { item.status = 'done'; };
                var toRemote = function () {
                    // 没拿到 Dify 的 file id：保留 url，发送时走 remote_url
                    done();
                    if (window.console && window.console.log) {
                        window.console.log('[native-pick] 未能取回文件字节，改为 remote_url 直传', info.url);
                    }
                };

                if (typeof window.fetch !== 'function') { toRemote(); return; }
                window.fetch(info.url).then(function (r) {
                    if (!r.ok) { throw new Error('HTTP ' + r.status); }
                    return r.blob();
                }).then(function (blob) {
                    var file;
                    try { file = new File([blob], name, { type: blob.type || 'image/jpeg' }); }
                    catch (e) { file = blob; }
                    var fd = new FormData();
                    fd.append('file', file, name);
                    return OKAuth.request('POST', '/api/chat/files', { body: fd });
                }).then(function (data) {
                    if (data && data.id) {
                        item.id = data.id;
                        if (data.kind) { item.kind = data.kind; }
                        if (data.size) { item.size = data.size; }
                        done();
                        self.rememberBlob(data.id, info.url);
                    } else {
                        toRemote();
                    }
                }).catch(toRemote);
            },

            removeAttachment: function (i) {
                this.attachments.splice(i, 1);
            },
            onFileSelected: function (e) {
                var file = e.target.files[0];
                if (!file) { return; }
                var self = this;
                var reader = new FileReader();
                reader.onload = function () {
                    self.dispatch({
                        content: '[报表已上传]',
                        intent: 'report_upload',
                        localImages: [reader.result]
                    });
                };
                reader.readAsDataURL(file);
                e.target.value = '';
            },
            /* ---------- 「+」按钮附件上传（对接 Dify files 变量） ---------- */
            pickFiles: function () {
                this.$refs.docInput.click();
            },
            /* 「+」选择文件 → 交给统一的上传流程 */
            onFilesPicked: function (e) {
                var files = Array.prototype.slice.call(e.target.files || []);
                e.target.value = '';
                this.uploadFiles(files, { imageOnly: false });
            },
            /* 附件上传统一流程：本地校验（数量/类型/大小）→ 逐个上传拿 id → 随下一条消息发送。
               opts.imageOnly=true 表示来自相机拍照：只收图片，且以 MIME 为主判定
               （相机返回的文件常缺扩展名，若沿用扩展名白名单会被误判为文档）。 */
            uploadFiles: function (files, opts) {
                opts = opts || {};
                var self = this;
                if (!files || !files.length) { return; }
                var room = this.uploadCfg.maxFiles - this.attachments.length;
                if (room <= 0) { this.toast('最多上传 ' + this.uploadCfg.maxFiles + ' 个文件'); return; }
                if (files.length > room) {
                    this.toast('最多上传 ' + this.uploadCfg.maxFiles + ' 个文件，已保留前 ' + room + ' 个');
                    files = files.slice(0, room);
                }
                files.forEach(function (file) {
                    var name = file.name || '';
                    var ext = extOf(name);
                    var byMime = String(file.type || '').indexOf('image/') === 0;
                    var isImg = byMime || IMG_EXTS.indexOf(ext) > -1;
                    if (opts.imageOnly && !isImg) {
                        self.toast('仅支持拍照上传图片：' + (name || '未知文件'));
                        return;
                    }
                    if (!isImg && DOC_EXTS.indexOf(ext) < 0) {
                        self.toast('不支持的文件类型：' + (ext ? '.' + ext : name));
                        return;
                    }
                    // 图片但扩展名缺失/不在白名单（相机常见）：按 MIME 补扩展名后重命名，
                    // 保证服务端按扩展名判定为 image，图片预览与 Dify 的 files 类型都正确
                    if (isImg && IMG_EXTS.indexOf(ext) < 0) {
                        ext = IMG_MIME_EXT[String(file.type || '').toLowerCase()] || 'jpg';
                        name = '照片_' + photoStamp() + '.' + ext;
                        try {
                            file = new File([file], name, { type: file.type || 'image/jpeg' });
                        } catch (err) { /* 个别老内核不支持 File 构造：沿用原对象，仅文件名保留 */ }
                    } else if (!name) {
                        name = '照片_' + photoStamp() + '.jpg';
                    }
                    var maxMb = isImg ? self.uploadCfg.imageMaxMb : self.uploadCfg.docMaxMb;
                    if (file.size > maxMb * 1024 * 1024) {
                        self.toast((isImg ? '图片' : '文档') + '不能超过 ' + maxMb + 'MB：' + name);
                        return;
                    }
                    // 先占位显示「上传中」，成功后回填 id；同时留一份浏览器本地副本用于即时预览
                    var localUrl = blobOf(file);
                    var item = { id: '', name: name, size: file.size,
                        kind: isImg ? 'image' : 'document', status: 'uploading', localUrl: localUrl };
                    self.attachments.push(item);
                    var fd = new FormData();
                    fd.append('file', file, name);
                    OKAuth.request('POST', '/api/chat/files', { body: fd })
                        .then(function (data) {
                            if (data && data.id) {
                                item.id = data.id;
                                item.status = 'done';
                                if (data.kind) { item.kind = data.kind; }
                                self.rememberBlob(data.id, localUrl);
                            } else {
                                item.status = 'error';
                                self.toast('文件上传失败');
                            }
                        })
                        .catch(function (e) {
                            item.status = 'error';
                            // 令牌类失败已由统一处理入口提示，这里不再重复弹
                            if (e && e.auth) { return; }
                            self.toast((e && e.message) || ('文件上传失败：' + name));
                        });
                });
            },
            removeAttachment: function (i) {
                this.attachments.splice(i, 1);
            },
            /* 附件条上的项：上传完成后点击可先预览内容（相机拍完可确认照片拍对没有） */
            previewAttachment: function (a) {
                if (!a) { return; }
                if (a.status === 'uploading') { this.toast('附件上传中，请稍候'); return; }
                if (a.status === 'error') { this.toast('附件上传失败，请移除后重试'); return; }
                this.openFile(a);
            },
            /* 附件读取地址：本标签页已有的本地副本优先（刚选中 / 刚发送，省一次往返）；
               其余一律走服务端实时取 —— 服务端按「会话 + 文件 id」读一次平台历史，
               拿刚签发的地址拉字节后转发（应用侧不落盘、不缓存，任意实例都能服务）。
               浏览器直链同样要带凭证：由 OKAuth.withToken 在 URL 上拼 userToken */
            fileUrl: function (f, download) {
                if (!f) { return ''; }
                if (f.localUrl) { return f.localUrl; }
                // 原生上传的附件：没有 Dify id 但有门户文件服务器地址，直接用（图片可直接 <img src>）
                if (!f.id && f.url) { return f.url; }
                if (f.id && this.fileBlobs[f.id]) { return this.fileBlobs[f.id]; }
                var q = [];
                if (this.conversationId) { q.push('cid=' + encodeURIComponent(this.conversationId)); }
                if (download) { q.push('download=1'); }
                return OKAuth.withToken(API + '/api/chat/files/' + encodeURIComponent(f.id)
                    + (q.length ? '?' + q.join('&') : ''));
            },
            /* 记住某个附件 id 的浏览器本地副本（上传成功后调用）：发送后立刻预览无需往返服务端 */
            rememberBlob: function (id, url) {
                if (!id || !url) { return; }
                if (Object.keys(this.fileBlobs).length >= 50) {
                    // 简单容量上限：超出即整体丢弃（历史附件仍可实时向服务端取，只是少一层本地加速）
                    this.fileBlobs = {};
                }
                this.$set(this.fileBlobs, id, url);
            },
            /* 打开附件弹层。三种形态：
               · 图片 → 直接显示（本地副本优先）
               · PDF / Word / Excel / PPT → 先向服务端要内联预览字节（Office 由服务端转 PDF），
                 再用本地 pdf.js 画出来
               · 其他类型 → 只显示文件信息 + 下载入口 */
            openFile: function (f) {
                if (!f || !f.id) { return; }
                this.closeFileView();
                var view = {
                    id: f.id, name: f.name, size: f.size, kind: f.kind,
                    localUrl: f.localUrl,
                    preview: f.kind === 'image' ? 'image' : (previewKindOf(f.name) || 'file'),
                    docLoading: false, docReady: false, docError: ''
                };
                this.fileView = view;
                if (view.preview === 'office' && this.previewCfg && this.previewCfg.available === false) {
                    // 服务端没装 LibreOffice：不必白跑一次请求
                    view.docError = '服务端未启用文档在线预览，请下载后查看';
                } else if (view.preview === 'pdf' || view.preview === 'office') {
                    this.loadDocPreview(view);
                }
            },
            closeFileView: function () {
                // canvas 与 pdf.js 文档对象都随视图引用消失被回收，这里只需清引用
                this.fileView = null;
            },
            /* 取内联预览字节：服务端按「会话 + 文件 id」实时取回原件（Office 顺带转成 PDF），
               响应固定为 PDF，这里用 pdf.js 渲染 —— 不走浏览器自带的 PDF 阅读器，
               因为移动端（iOS 只显示第一页 / Android Chrome 不渲染 iframe 内 PDF）都不可靠 */
            loadDocPreview: function (view) {
                var self = this;
                view.docLoading = true;
                var url = API + '/api/chat/files/' + encodeURIComponent(view.id) + '?inline=1'
                    + (self.conversationId ? '&cid=' + encodeURIComponent(self.conversationId) : '');
                fetch(OKAuth.withToken(url)).then(function (r) {
                    if (!r.ok) {
                        return r.text().then(function (t) {
                            var msg = '';
                            try { msg = (JSON.parse(t) || {}).message || ''; } catch (e) { /* 非 JSON 响应体 */ }
                            if (!msg && r.status === 404) { msg = '附件尚未随消息发送，或所属会话已删除'; }
                            throw new Error(msg || ('预览失败（HTTP ' + r.status + '）'));
                        });
                    }
                    return r.arrayBuffer();
                }).then(function (buf) {
                    if (self.fileView !== view) { return; }
                    view.docLoading = false;
                    view.docReady = true;
                    var alive = function () { return self.fileView === view; };
                    self.$nextTick(function () {
                        var box = self.$el.querySelector('.file-doc');
                        if (!box) { return; }
                        renderPdfInto(box, new Uint8Array(buf), alive).catch(function (e) {
                            if (self.fileView === view) {
                                view.docReady = false;
                                view.docError = (e && e.message) || '预览渲染失败，请下载后查看';
                            }
                        });
                    });
                }).catch(function (e) {
                    if (self.fileView !== view) { return; }
                    view.docLoading = false;
                    view.docError = (e && e.message) || '预览失败，请下载后查看';
                });
            },
            fmtSize: function (n) {
                if (n == null) { return ''; }
                if (n < 1024) { return n + 'B'; }
                if (n < 1024 * 1024) { return Math.round(n / 1024) + 'KB'; }
                return (n / 1024 / 1024).toFixed(1) + 'MB';
            },
            feedback: function (msg, type) {
                if (type === 'like') { msg._liked = !msg._liked; if (msg._liked) { msg._disliked = false; } }
                if (type === 'dislike') { msg._disliked = !msg._disliked; if (msg._disliked) { msg._liked = false; } }
                http('POST', '/api/chat/messages/' + msg.id + '/feedback?type=' + type, {}).catch(function () {});
            },
            copyScript: function (s) {
                this.copyText(s.content);
                this.toast('话术已复制');
            },
            copyMessage: function (msg) {
                this.copyText(this.plainText(msg));
                this.toast('内容已复制');
            },
            copyText: function (text) {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).catch(function () {});
                } else {
                    var ta = document.createElement('textarea');
                    ta.value = text;
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                }
            },

            /* ---------------- 渲染辅助 ---------------- */
            hydrate: function (list) {
                var self = this;
                return list.map(function (m) { return self.hydrateOne(m); });
            },
            hydrateOne: function (m) {
                if (m.from === 'user' && m.msgType === 'TEXT' && m.content &&
                    /\.(公司|集团|厂|企业)$/.test(m.content) && m.content.length < 30) {
                    m._isCompanyCard = true;
                    m.company = m.content.replace(/^\d+[\.、]\s*/, '');
                    m.index = (m.content.match(/^(\d+)/) || [null, ''])[1];
                    m.city = '江苏张家港';
                    m.status = '存续';
                    m.legalRep = '王*云';
                }
                return m;
            },
            hasGuide: function (msg) {
                // 四段分析/问答/画像/商机/话术/报表分析 消息带竖向引导线
                return ['ANALYSIS', 'INDUSTRY_PROFILE', 'BIZ_PROFILE', 'OPPORTUNITY',
                    'SCRIPT', 'REPORT_ANALYSIS', 'TASK_FLOW', 'COMPANY_LIST'].indexOf(msg.msgType) > -1;
            },
            showFeedback: function (msg) {
                return ['ANALYSIS', 'INDUSTRY_PROFILE', 'BIZ_PROFILE', 'OPPORTUNITY',
                    'SCRIPT', 'COMPANY_LIST', 'REPORT_ANALYSIS'].indexOf(msg.msgType) > -1;
            },
            renderText: function (text) {
                if (!text) { return ''; }
                var esc = String(text)
                    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                esc = esc.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
                esc = esc.replace(/\n/g, '<br>');
                return esc;
            },
            plainText: function (msg) {
                if (msg.msgType === 'ANALYSIS' && msg.payload && msg.payload.sections) {
                    return msg.payload.sections.map(function (s) {
                        return s.title + (s.body ? '\n' + s.body : '');
                    }).join('\n');
                }
                return msg.content || '';
            },
            holdingBg: function (type) {
                if (type.indexOf('存款') > -1) { return 'deposit'; }
                if (type.indexOf('贷款') > -1) { return 'loan'; }
                return 'wealth';
            },
            oppIconColor: function (category) {
                return category === '存款' ? 'orange' : 'blue';
            },
            onChatScroll: function () { /* 预留 */ },

            /* ---------------- 演示场景 ---------------- */
            runScene: function (scene) {
                var self = this;
                // 演示场景与底部菜单的对应关系：先切到对应菜单，再走场景
                var SCENE_TAB = { task: 'task', flow: 'task', menu: 'menu' };
                var SEQ = {
                    search: [{ content: '帮我搜索国泰' }],
                    analysis: [
                        { content: '帮我搜索国泰' },
                        { content: '2. 江苏国泰国际集团', intent: 'company_click', company: '江苏国泰国际集团',
                          companyCard: { index: '2', name: '江苏国泰国际集团', city: '江苏张家港', status: '存续', legalRep: '王*云' } }
                    ],
                    industry: [
                        { content: '2. 江苏国泰国际集团', intent: 'company_click', company: '江苏国泰国际集团',
                          companyCard: { index: '2', name: '江苏国泰国际集团', city: '江苏张家港', status: '存续', legalRep: '王*云' } },
                        { content: '1. 行业类型', intent: 'deep_industry', company: '江苏国泰国际集团' }
                    ],
                    biz: [
                        { content: '2. 江苏国泰国际集团', intent: 'company_click', company: '江苏国泰国际集团',
                          companyCard: { index: '2', name: '江苏国泰国际集团', city: '江苏张家港', status: '存续', legalRep: '王*云' } },
                        { content: '2. 业务信息', intent: 'deep_business', company: '江苏国泰国际集团' }
                    ],
                    opp: [
                        { content: '3. 商机线索', intent: 'deep_opportunity', company: '江苏国泰国际集团', category: '存款' }
                    ],
                    script: [
                        { content: '4. 营销话术', intent: 'deep_script', company: '江苏国泰国际集团', scene: '办公室场景' }
                    ],
                    task: [{ content: '今日任务' }],
                    flow: [{ content: '请帮我分配触达任务' }],
                    report: [
                        { content: '江苏韵瑞新能源汽车配件公司能做么？' },
                        { content: '[报表已上传]', intent: 'report_upload',
                          localImages: [okAsset('assets/截屏2026-09-16 14.26.41@2x.png'), okAsset('assets/截屏2026-09-16 14.27.37@2x.png')] }
                    ],
                    menu: [{ content: '网格' }]
                };
                var steps = SEQ[scene];
                if (!steps) { return; }
                if (SCENE_TAB[scene]) { this.switchTab(SCENE_TAB[scene]); }
                var i = 0;
                var next = function () {
                    if (i < steps.length) {
                        self.dispatch(steps[i]);
                        i++;
                        setTimeout(next, 2200);
                    } else if (scene === 'drawer') {
                        self.drawerOpen = true;
                    }
                };
                next();
            },
            scrollToBottom: function () {
                var self = this;
                this.$nextTick(function () {
                    var el = self.$refs.chatList;
                    if (el) { el.scrollTop = el.scrollHeight; }
                });
            }
        }
    });
})();
