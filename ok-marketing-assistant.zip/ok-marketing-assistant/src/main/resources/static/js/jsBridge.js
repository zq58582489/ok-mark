/* ============================================================
 * JSBridge — H5 与门户原生容器（Android / iOS）通信
 *
 * 来源：门户提供的 jsBridge.js（原文件是 ES Module，export default JSBridge）。
 * 本文件是「无构建」版本：去掉 import/export，直接挂到 window.$JSBridge，
 * 其余行为与原实现保持一致（原生侧无需任何改动）：
 *
 *   · Android：window.androidNative[method](JSON.stringify(data))
 *             其中 data.param 会先被 JSON.stringify 一次（原生侧按字符串解析）
 *   · iOS    ：window.webkit.messageHandlers[method].postMessage(JSON.stringify(data))
 *
 * 相对原实现只改了两处：
 *   1. 回调 id 递增（原实现 `const thisId = id` 没有 ++，连续调用会互相覆盖回调）
 *   2. 增加 available() —— 判断当前是否在原生容器里，供 H5 做降级
 * ============================================================ */
(function (global) {
    'use strict';

    // 是否是 IOS
    function isIos() {
        return /ios|iphone|ipad|ipod/.test(global.navigator.userAgent.toLowerCase());
    }

    // 是否是安卓
    function isAndroid() {
        return /android/.test(global.navigator.userAgent.toLowerCase());
    }

    // 判断客户端是否注册方法
    function canInvoke(method) {
        try {
            if (isAndroid()) {
                return !!(global.androidNative && global.androidNative[method]);
            }
            if (isIos()) {
                return !!(global.webkit && global.webkit.messageHandlers
                    && global.webkit.messageHandlers[method]);
            }
            return false;
        } catch (error) {
            if (global.console && global.console.warn) {
                global.console.warn('canInvoke-未初始化jsBridge', error);
            }
            return false;
        }
    }

    // H5 给 APP 发送信息
    function postMessageToApp(options) {
        try {
            var method = options.method;
            var data = options.data || {};
            if (isIos()) {
                var params = JSON.stringify(data);
                if (typeof data === 'string') {
                    params = data;
                }
                global.webkit.messageHandlers[method].postMessage(params);
            } else if (isAndroid()) {
                if (data.param) {
                    data.param = JSON.stringify(data.param);
                }
                global.androidNative[method](JSON.stringify(options.data));
            }
        } catch (error) {
            if (global.console && global.console.warn) {
                global.console.warn('postMessageToApp', error, options.method);
            }
        }
    }

    // H5 调用 App 方法
    function invokeNative(options) {
        if (canInvoke(options.method)) {
            postMessageToApp(options);
            return true;
        }
        return false;
    }

    var id = 0;
    var callbacks = {};

    var JSBridge = {
        /**
         * 调用原生方法
         * @param {string} method 原生方法名（如 openNativePage）
         * @param {object} [data] 参数
         * @param {function} [callback] 原生回调（原生侧通过 receiveMessage 回传）
         * @returns {boolean} 是否成功交给容器（false = 当前不在容器内 / 原生未注册该方法）
         */
        invoke: function (method, data, callback) {
            var thisId = id++;
            callbacks[thisId] = callback;
            return invokeNative({
                method: method,
                data: data || {},
                callbackId: thisId
            });
        },
        receiveMessage: function (msg) {
            msg = msg || {};
            var callbackId = msg.callbackId;
            if (callbackId !== undefined && callbackId !== null && callbacks[callbackId]) {
                try {
                    callbacks[callbackId](msg.data || {});
                } finally {
                    delete callbacks[callbackId];
                }
            }
        },
        /** 当前是否运行在原生容器里（且该容器注册了至少要用的方法） */
        available: function (method) {
            return canInvoke(method || 'openNativePage');
        },
        canInvoke: canInvoke,
        isIos: isIos,
        isAndroid: isAndroid
    };

    global.$JSBridge = JSBridge;
})(window);
