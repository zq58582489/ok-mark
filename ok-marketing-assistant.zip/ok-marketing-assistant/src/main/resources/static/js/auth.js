/* ============================================================
 * OK营销助手 — 鉴权模块（静态引用，无构建；必须在 app.js 之前引入）
 *
 * 约定（与后端 com.ok.auth.* 对应）：
 *   门户打开本页面时把加密后的用户信息拼在地址上 →  ?userToken=<SM4 密文>
 *   · 进入页面时抓取一次，存到 sessionStorage（刷新 / 站内跳转都不丢）
 *   · 之后所有后台请求都自动在 URL 上带同一个 userToken（查询参数，不是请求头）
 *   · 服务端用 SM4 解密该密文得到工号 / 姓名 / 部门
 *
 * 对外只暴露一个全局对象 OKAuth：
 *   OKAuth.request(m, url, opt)  —— 统一请求封装（自动带 userToken，401 统一处理）
 *   OKAuth.withToken(url)        —— 给图片预览 / 附件下载等直链拼上 userToken
 *   OKAuth.token()               —— 当前 userToken（没有返回空串）
 *   OKAuth.hasToken()            —— 是否有可用凭证
 *   OKAuth.onAuthFail(fn)        —— 401 的统一处理入口（业务侧弹提示 / 跳转）
 *
 * 注意：不再有「向服务端换取令牌」这一步 —— 凭证完全由门户下发。
 * ============================================================ */
(function (global) {
    'use strict';

    var CFG = {
        base: '',                    // 接口前缀（同源部署，保持空串）
        param: 'userToken',          // 凭证参数名（与后端 ok.auth.param 一致）
        storeKey: 'ok_user_token',   // sessionStorage 键名
        headerFallback: ''           // 预留：如需同时支持请求头，填头名（默认关闭）
    };

    var memory = { token: '' };
    var handlers = [];
    var styleInjected = false;

    /* ---------------- 从 URL 抓取凭证 ---------------- */

    /**
     * 读取原始查询串里的某个参数。
     *
     * <p>不用 URLSearchParams：它会把 '+' 解释成空格，而 Base64 密文里 '+' 是合法字符
     * （门户若没做 URL 编码，直接用它解析会把密文弄坏）。这里先按原文取，再手工解码。
     */
    function readRaw(name) {
        var query = String(global.location.search || '').replace(/^\?/, '');
        var hash = String(global.location.hash || '');
        var qi = hash.indexOf('?');
        if (qi > -1) {
            query = query ? (query + '&' + hash.slice(qi + 1)) : hash.slice(qi + 1);
        }
        if (!query) { return ''; }
        var parts = query.split('&');
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i];
            if (!part) { continue; }
            var eq = part.indexOf('=');
            var k = eq < 0 ? part : part.slice(0, eq);
            var v = eq < 0 ? '' : part.slice(eq + 1);
            try { k = decodeURIComponent(k); } catch (e) { /* 保留原文 */ }
            if (k !== name) { continue; }
            // '+' 还原成 %2B 再解码：Base64 里不会有空格，安全
            v = v.replace(/\+/g, '%2B');
            try { v = decodeURIComponent(v); } catch (e2) { /* 保留原文 */ }
            return v.trim();
        }
        return '';
    }

    function storage() {
        try {
            var s = global.sessionStorage;
            s.setItem('__ok_probe', '1');
            s.removeItem('__ok_probe');
            return s;
        } catch (e) {
            return null;   // 隐私模式 / 无痕 WebView
        }
    }

    function loadStored() {
        var store = storage();
        if (store) {
            try { return store.getItem(CFG.storeKey) || ''; } catch (e) { /* 忽略 */ }
        }
        return memory.token;
    }

    function save(token) {
        memory.token = token || '';
        var store = storage();
        if (store) {
            try {
                if (token) { store.setItem(CFG.storeKey, token); } else { store.removeItem(CFG.storeKey); }
            } catch (e) { /* 忽略 */ }
        }
    }

    /** 启动时抓取：URL 上有就用 URL 的（门户每次进入都是新凭证），否则用本次会话缓存的 */
    function capture() {
        var fromUrl = readRaw(CFG.param);
        if (fromUrl) {
            save(fromUrl);
            return fromUrl;
        }
        return loadStored();
    }

    capture();

    /* ---------------- 对外能力 ---------------- */

    /** 当前 userToken（没有则空串） */
    function token() {
        return memory.token || '';
    }

    function hasToken() {
        return !!token();
    }

    /** 运行时替换凭证（例如容器内切换到另一个用户 / 重新登录后） */
    function setToken(t) {
        save(t ? String(t).trim() : '');
    }

    function clearToken() {
        save('');
    }

    /** 给地址拼上 userToken（已有则不重复拼） */
    function withToken(url) {
        if (!url) { return url; }
        var s = String(url);
        // 绝对地址：只处理同源请求，外站链接不泄露凭证
        if (/^https?:\/\//i.test(s)) {
            var origin = String(global.location.origin || '');
            if (origin && s.indexOf(origin) !== 0) { return s; }
        }
        var t = token();
        if (!t) { return s; }
        if (new RegExp('[?&]' + CFG.param + '=').test(s)) { return s; }
        return s + (s.indexOf('?') > -1 ? '&' : '?') + CFG.param + '=' + encodeURIComponent(t);
    }

    function mergeHeaders(target, extra) {
        if (!extra) { return target; }
        for (var k in extra) {
            if (Object.prototype.hasOwnProperty.call(extra, k)) { target[k] = extra[k]; }
        }
        return target;
    }

    function isUnauthorized(out) {
        if (!out) { return false; }
        if (out.status === 401) { return true; }
        return !!(out.res && out.res.code === 401);
    }

    function makeAuthError(out, url) {
        var message = (out.res && out.res.message) || '用户凭证已失效，请从门户重新进入';
        var err = new Error(message);
        err.code = 401;
        err.auth = true;
        err.status = out.status;
        err.url = url;
        return err;
    }

    /**
     * 统一请求封装：自动在 URL 上带 userToken，业务只管传地址与参数。
     *
     * <p>默认<b>不设超时</b>：会话列表、档案、反馈这些接口都是秒级返回，设了反而在弱网下误伤。
     * 只有对话接口由调用方显式传 {@code timeoutMs}（见 app.js 的 CHAT_TIMEOUT_MS），
     * 且略大于后端的 Dify 读超时 —— 这样正常情况下总是后端先超时、返回一句明确的中文原因。
     *
     * @param {string} method GET / POST / ...
     * @param {string} url    /api/... 相对地址
     * @param {object} [options] { body, headers, credentials, timeoutMs }
     * @returns {Promise<*>} 解包后的 data（code === 0）
     */
    function request(method, url, options) {
        var opt = options || {};
        var target = withToken(url);
        var headers = {};
        var body = opt.body;
        var isForm = typeof global.FormData !== 'undefined' && body instanceof global.FormData;
        var isText = typeof body === 'string';
        if (!isForm && !isText && body !== undefined && body !== null) {
            headers['Content-Type'] = 'application/json';
        }
        if (CFG.headerFallback && token()) {
            headers[CFG.headerFallback] = token();
        }
        mergeHeaders(headers, opt.headers);
        var init = { method: method, headers: headers };
        if (body !== undefined && body !== null) {
            init.body = (isForm || isText) ? body : JSON.stringify(body);
        }
        if (opt.credentials) { init.credentials = opt.credentials; }

        // 超时用 AbortController；老 WebView 不支持时退化为不设超时（后端读超时仍会兜底）
        var timer = null;
        var ctrl = null;
        if (opt.timeoutMs > 0 && typeof global.AbortController === 'function') {
            ctrl = new global.AbortController();
            init.signal = ctrl.signal;
            timer = global.setTimeout(function () { ctrl.abort(); }, opt.timeoutMs);
        }
        function clearTimer() {
            if (timer) { global.clearTimeout(timer); timer = null; }
        }

        return global.fetch(CFG.base + target, init).then(function (r) {
            return r.text().then(function (text) {
                var res = null;
                if (text) {
                    try { res = JSON.parse(text); } catch (e) { res = null; }
                }
                var out = { status: r.status, res: res, url: url };
                if (isUnauthorized(out)) {
                    throw notifyAuthFail(makeAuthError(out, url));
                }
                if (res && res.code === 0) { return res.data; }
                var err = new Error((res && res.message) || ('请求失败（HTTP ' + r.status + '）'));
                err.status = r.status;
                err.code = res ? res.code : r.status;
                err.response = res;
                err.url = url;
                throw err;
            });
        }).catch(function (e) {
            // 只拦自己触发的超时；401 / 业务错误原样抛出，交给上层处理
            if (e && (e.name === 'AbortError' || (ctrl && ctrl.signal && ctrl.signal.aborted))) {
                var err = new Error('AI 服务响应超时（已等待 ' + humanDuration(opt.timeoutMs) + '），请稍后重试');
                err.code = 'TIMEOUT';
                err.timeout = true;
                err.url = url;
                throw err;
            }
            throw e;
        }).finally(clearTimer);
    }

    /** 毫秒 → 人话（180000 → "3 分钟"，95000 → "95 秒"） */
    function humanDuration(ms) {
        var sec = Math.max(1, Math.round((ms || 0) / 1000));
        return sec % 60 === 0 ? (sec / 60) + ' 分钟' : sec + ' 秒';
    }

    /* ---------------- 统一校验失败处理入口 ---------------- */

    /**
     * 注册「凭证校验失败」的统一处理入口（可注册多个，按注册顺序调用）。
     * @param {function} fn 入参 info = { code, message, url, handled }
     * @returns {function} 取消注册
     */
    function onAuthFail(fn) {
        if (typeof fn !== 'function') {
            var old = handlers;
            handlers = [];
            return function () { handlers = old; };
        }
        handlers.push(fn);
        return function off() {
            for (var i = 0; i < handlers.length; i++) {
                if (handlers[i] === fn) { handlers.splice(i, 1); break; }
            }
        };
    }

    function notifyAuthFail(err) {
        var info = {
            code: (err && err.code) || 401,
            message: (err && err.message) || '用户凭证已失效，请从门户重新进入',
            url: err && err.url,
            handled: false
        };
        for (var i = 0; i < handlers.length; i++) {
            try {
                handlers[i](info);
                info.handled = true;
            } catch (e) {
                warn('onAuthFail 处理器异常：' + (e && e.message));
            }
        }
        if (!info.handled) { defaultAuthFail(info); }
        return err;
    }

    /** 内置兜底：没有业务处理器时也要让用户看到反馈 */
    function defaultAuthFail(info) {
        warn('接口鉴权失败：' + info.message + (info.url ? '（' + info.url + '）' : ''));
        if (!global.document || !global.document.body) { return; }
        injectStyle();
        var el = global.document.getElementById('ok-auth-toast');
        if (!el) {
            el = global.document.createElement('div');
            el.id = 'ok-auth-toast';
            el.className = 'ok-auth-toast';
            global.document.body.appendChild(el);
        }
        el.textContent = info.message;
        el.style.display = 'block';
        global.clearTimeout(el._okTimer);
        el._okTimer = global.setTimeout(function () { el.style.display = 'none'; }, 2600);
    }

    function injectStyle() {
        if (styleInjected || !global.document) { return; }
        styleInjected = true;
        var css = '.ok-auth-toast{position:fixed;left:50%;bottom:150px;transform:translateX(-50%);'
            + 'max-width:280px;padding:9px 14px;border-radius:8px;background:rgba(0,0,0,.78);color:#fff;'
            + 'font-size:12px;line-height:1.5;text-align:center;z-index:9999;display:none;'
            + 'font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;}';
        var style = global.document.createElement('style');
        style.id = 'ok-auth-style';
        style.type = 'text/css';
        if (style.styleSheet) { style.styleSheet.cssText = css; } else { style.appendChild(global.document.createTextNode(css)); }
        (global.document.head || global.document.documentElement).appendChild(style);
    }

    function warn(msg) {
        if (global.console && global.console.warn) { global.console.warn('[OKAuth] ' + msg); }
    }

    global.OKAuth = {
        config: CFG,
        token: token,
        hasToken: hasToken,
        setToken: setToken,
        clearToken: clearToken,
        withToken: withToken,
        request: request,
        onAuthFail: onAuthFail
    };
})(window);
