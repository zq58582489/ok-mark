/* ============================================================
 * 调试面板（纯前端，不依赖额外接口）
 *
 * 真机 / 门户容器里没有控制台，联调时看不到 console 和网络错误。
 * 这里给页面挂一个悬浮按钮，点开可以看：
 *   · 环境：UA、视口、$JSBridge 能力（selectPicture / openNativePage 是否可用）
 *   · 凭证：当前 userToken（脱敏 + 复制）
 *   · 日志：拦截 console.log/info/warn/error + 未捕获异常，最多保留 200 条
 *   · 操作：复制日志、清空、刷新、复制凭证、隐藏入口（在标题栏）
 *
 * 开 / 关（两级，缺一不可见）：
 *   1) 后端总开关 ok.assistant.debug-enabled（环境变量 OK_DEBUG_ENABLED，默认 false）——
 *      关闭时本脚本直接返回：不建 DOM、不拦截控制台，页面与生产环境完全一致；
 *      配置经 /api/chat/profile 的 debug.enabled 下发，由 app.js 发布为 window.OK_DEBUG_CFG。
 *   2) 打开后，当前设备默认显示；点「隐藏入口」记进 localStorage（ok_debug_hidden）后不再显示，
 *      需要时用 ?debug=1 强制呼出（会清掉隐藏标记）。
 * ============================================================ */
(function (global) {
    'use strict';

    var doc = global.document;
    var HIDE_KEY = 'ok_debug_hidden';
    var MAX_LOGS = 200;

    var logs = [];
    var fab = null;
    var mask = null;
    var listEl = null;
    var countEl = null;
    var open = false;

    /* ---------------- 日志缓冲 ---------------- */

    function toText(v) {
        if (typeof v === 'string') { return v; }
        if (v instanceof Error) { return v.message || String(v); }
        try {
            return JSON.stringify(v);
        } catch (e) {
            return String(v);
        }
    }

    function push(level, args) {
        var parts = [];
        for (var i = 0; i < args.length; i++) { parts.push(toText(args[i])); }
        var d = new Date();
        var hh = ('0' + d.getHours()).slice(-2);
        var mm = ('0' + d.getMinutes()).slice(-2);
        var ss = ('0' + d.getSeconds()).slice(-2);
        logs.push({ time: hh + ':' + mm + ':' + ss, level: level, text: parts.join(' ') });
        if (logs.length > MAX_LOGS) { logs.shift(); }
        if (open) { renderLogs(); }
    }

    function wrapConsole() {
        if (global.__okDbgWrapped) { return; }
        global.__okDbgWrapped = true;
        ['log', 'info', 'warn', 'error'].forEach(function (lv) {
            var orig = global.console && global.console[lv];
            if (typeof orig !== 'function') { return; }
            global.console[lv] = function () {
                try { push(lv, arguments); } catch (e) { /* 调试模块自身不能影响业务 */ }
                return orig.apply(global.console, arguments);
            };
        });
        global.addEventListener('error', function (e) {
            push('error', ['未捕获异常：' + (e.message || '') + ' @' + (e.filename || '') + ':' + (e.lineno || '')]);
        });
        global.addEventListener('unhandledrejection', function (e) {
            push('error', ['Promise 未处理：' + toText(e.reason)]);
        });
    }

    /* ---------------- 内容生成 ---------------- */

    function envRows() {
        var b = global.$JSBridge;
        var can = function (m) {
            try { return b && b.canInvoke && b.canInvoke(m) ? '可用' : '不可用'; } catch (e) { return '异常'; }
        };
        return [
            ['地址', location.origin + location.pathname],
            ['视口', global.innerWidth + '×' + global.innerHeight + ' @' + (global.devicePixelRatio || 1) + 'x'],
            ['容器', b ? ('iOS=' + b.isIos() + '  Android=' + b.isAndroid()) : '无 $JSBridge'],
            ['selectPicture', can('selectPicture')],
            ['openNativePage', can('openNativePage')],
            ['UA', navigator.userAgent]
        ];
    }

    function currentToken() {
        try {
            return (global.OKAuth && global.OKAuth.token()) || '';
        } catch (e) {
            return '';
        }
    }

    function maskToken(t) {
        if (!t) { return ''; }
        if (t.length <= 16) { return t; }
        return t.slice(0, 12) + '…' + t.slice(-6) + '（' + t.length + ' 字符）';
    }

    /* ---------------- 渲染 ---------------- */

    function el(tag, cls, text) {
        var e = doc.createElement(tag);
        if (cls) { e.className = cls; }
        if (text !== undefined) { e.textContent = text; }
        return e;
    }

    function renderEnv(box) {
        box.innerHTML = '';
        envRows().forEach(function (row) {
            var line = el('div', 'okdbg-kv');
            line.appendChild(el('span', 'okdbg-k', row[0]));
            line.appendChild(el('span', 'okdbg-v', row[1]));
            box.appendChild(line);
        });
    }

    function renderToken(box) {
        box.innerHTML = '';
        var t = currentToken();
        box.appendChild(el('div', 'okdbg-token', t ? maskToken(t) : '（无凭证）'));
    }

    function renderLogs() {
        if (!listEl) { return; }
        listEl.innerHTML = '';
        if (!logs.length) {
            listEl.appendChild(el('div', 'okdbg-empty', '暂无日志'));
        } else {
            logs.forEach(function (l) {
                var row = el('div', 'okdbg-line okdbg-' + l.level);
                row.appendChild(el('span', 'okdbg-time', l.time));
                row.appendChild(el('span', 'okdbg-lv', l.level.toUpperCase()));
                row.appendChild(el('span', 'okdbg-msg', l.text));
                listEl.appendChild(row);
            });
            listEl.scrollTop = listEl.scrollHeight;
        }
        if (countEl) { countEl.textContent = logs.length ? '（' + logs.length + '）' : ''; }
    }

    function renderAll() {
        if (!mask) { return; }
        renderEnv(mask.querySelector('#okdbg-env'));
        renderToken(mask.querySelector('#okdbg-token'));
        renderLogs();
    }

    /* ---------------- 构建界面 ---------------- */

    function buildFab() {
        fab = el('div', 'okdbg-fab', '调试');
        fab.setAttribute('role', 'button');
        fab.addEventListener('click', openPanel);
        doc.body.appendChild(fab);
    }

    function buildPanel() {
        mask = el('div', 'okdbg-mask');
        mask.addEventListener('click', function (e) {
            if (e.target === mask) { closePanel(); }
        });

        var panel = el('div', 'okdbg-panel');

        var head = el('div', 'okdbg-head');
        head.appendChild(el('span', 'okdbg-title', '调试面板'));
        var headRight = el('div', 'okdbg-head-r');
        // 「隐藏入口」放在标题栏：属于低频且一次性的操作，不占底部按钮位
        var hide = el('span', 'okdbg-hide', '隐藏入口');
        hide.addEventListener('click', hideFab);
        headRight.appendChild(hide);
        var close = el('span', 'okdbg-x', '×');
        close.addEventListener('click', closePanel);
        headRight.appendChild(close);
        head.appendChild(headRight);
        panel.appendChild(head);

        var scroll = el('div', 'okdbg-scroll');

        var sec1 = el('div', 'okdbg-sec');
        sec1.appendChild(el('div', 'okdbg-t', '环境'));
        var envBox = el('div', 'okdbg-box');
        envBox.id = 'okdbg-env';
        sec1.appendChild(envBox);
        scroll.appendChild(sec1);

        var sec2 = el('div', 'okdbg-sec');
        sec2.appendChild(el('div', 'okdbg-t', '凭证'));
        var tokenBox = el('div', 'okdbg-box');
        tokenBox.id = 'okdbg-token';
        sec2.appendChild(tokenBox);
        scroll.appendChild(sec2);

        var sec3 = el('div', 'okdbg-sec');
        var t3 = el('div', 'okdbg-t', '日志');
        countEl = el('span', 'okdbg-count', '');
        t3.appendChild(countEl);
        sec3.appendChild(t3);
        listEl = el('div', 'okdbg-logs');
        sec3.appendChild(listEl);
        scroll.appendChild(sec3);

        panel.appendChild(scroll);

        var actions = el('div', 'okdbg-actions');
        [
            ['copy', '复制日志'],
            ['clear', '清空'],
            ['reload', '刷新'],
            ['token', '复制凭证']
        ].forEach(function (a) {
            var b = el('button', 'okdbg-btn', a[1]);
            b.setAttribute('data-act', a[0]);
            actions.appendChild(b);
        });
        panel.appendChild(actions);

        actions.addEventListener('click', function (e) {
            var act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
            if (!act) { return; }
            if (act === 'copy') { copyText(logs.map(function (l) {
                return l.time + ' [' + l.level + '] ' + l.text;
            }).join('\n'), '日志已复制'); }
            if (act === 'clear') { logs = []; renderLogs(); }
            if (act === 'reload') { location.reload(); }
            if (act === 'token') { copyText(currentToken(), '凭证已复制'); }
        });

        mask.appendChild(panel);
        doc.body.appendChild(mask);
    }

    /* ---------------- 操作 ---------------- */

    function copyText(text, okMsg) {
        if (!text) { push('warn', ['没有可复制的内容']); return; }
        var done = function () { push('info', [okMsg || '已复制']); };
        if (global.navigator.clipboard && global.navigator.clipboard.writeText) {
            global.navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text, done); });
        } else {
            fallbackCopy(text, done);
        }
    }

    /* 非 https / 老 WebView 没有 navigator.clipboard，用临时 textarea 兜底 */
    function fallbackCopy(text, done) {
        try {
            var ta = doc.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            doc.body.appendChild(ta);
            ta.select();
            doc.execCommand('copy');
            doc.body.removeChild(ta);
            done();
        } catch (e) {
            push('error', ['复制失败：' + e.message]);
        }
    }

    function hideFab() {
        try { global.localStorage.setItem(HIDE_KEY, '1'); } catch (e) { /* 隐私模式忽略 */ }
        closePanel();
        if (fab && fab.parentNode) { fab.parentNode.removeChild(fab); }
        fab = null;
    }

    function openPanel() {
        if (!mask) { return; }
        mask.style.display = 'block';
        open = true;
        // 打开时刷新环境（可能刚切换了容器能力）并把日志滚到底
        renderAll();
    }

    function closePanel() {
        if (!mask) { return; }
        mask.style.display = 'none';
        open = false;
    }

    /* ---------------- 启动 ---------------- */

    var started = false;

    /* 后端总开关：只认 /api/chat/profile 下发的 debug.enabled === true，
       配置拿不到（接口 401 / 加载失败）一律当关闭 —— 宁可看不到入口，也不在生产外泄 */
    function enabledByServer() {
        var cfg = global.OK_DEBUG_CFG;
        return !!(cfg && cfg.enabled === true);
    }

    function start() {
        if (started) { return; }
        started = true;
        wrapConsole();
        var forced = /[?&]debug=1/.test(location.search);
        var hidden = false;
        try { hidden = global.localStorage.getItem(HIDE_KEY) === '1'; } catch (e) { /* 隐私模式忽略 */ }
        if (hidden && !forced) { return; }
        // ?debug=1 = 这台设备明确要看，顺手清掉隐藏标记，下次打开不必再加参数
        if (forced) {
            try { global.localStorage.removeItem(HIDE_KEY); } catch (e) { /* 隐私模式忽略 */ }
        }
        buildFab();
        buildPanel();
        push('info', ['调试面板已就绪，点击右侧「调试」查看']);
    }

    function boot() {
        if (global.OK_DEBUG_CFG) {
            // app.js 已经拿到 profile：直接按配置决定
            if (enabledByServer()) { start(); }
            return;
        }
        // 常规情况：profile 在本脚本之后才返回，等 app.js 发布事件
        doc.addEventListener('ok:profile', function () {
            if (enabledByServer()) { start(); }
        });
    }

    if (doc.readyState === 'loading') {
        doc.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);
