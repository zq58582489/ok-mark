package com.ok.chat.service;

import com.ok.common.ChatMessage;
import com.ok.customer.service.CustomerService;
import com.ok.customer.store.MockStore;
import com.ok.task.service.TaskService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 意图识别与应答编排（还原原型全部场景）
 *
 * <p>单体模式：原 customer-service / task-service 的 Feign 远程调用，
 * 改为直接注入本地 {@link CustomerService} / {@link TaskService} Bean。</p>
 */
@Service
public class IntentService {

    /*
     * 分段图文（analysis：企业四段分析 / 业务问答）的段落详情入口，已从「底部 chips 选项」
     * 改为「小节标题右侧链接」：由数据源的 sections[].linkText / linkQuery 提供，
     * 例如 {"title":"1. 行业类型","body":"…","linkText":"全部","linkQuery":"1. 行业类型"}。
     * chips 保留给互斥/单选类选项（如触达任务的后续准备动作）。
     */

    /** 触达任务生成后的准备选项 */
    private static final List<String> PREPARE_CHIPS =
            Arrays.asList("1、营销话术", "2、规划出行路线");

    private static final String DEFAULT_COMPANY = "江苏韵瑞新能源汽车配件公司";

    private final CustomerService customerService;
    private final TaskService taskService;

    public IntentService(CustomerService customerService, TaskService taskService) {
        this.customerService = customerService;
        this.taskService = taskService;
    }

    // ==================== 主入口：根据用户输入生成应答 ====================

    /** 根据用户输入生成应答消息（可能为多条） */
    public List<ChatMessage> reply(String conversationId, String content, String contextCompany) {
        String text = content == null ? "" : content.trim();

        // 1. 报表上传确认（用户上传图片后触发）
        if (text.contains("[报表已上传]")) {
            return list(reportAnalysisReply(conversationId, extractCompany(text, DEFAULT_COMPANY)));
        }

        // 2. 精确命中企业名（点击企业列表 / 直接输入企业全称）
        String company = matchCompany(text);
        if (company != null) {
            return list(analysisReply(conversationId, company, company));
        }

        // 3. 企业四段分析的深入选项
        if (text.contains("行业类型")) {
            return list(industryReply(conversationId, contextCompany));
        }
        if (text.contains("业务信息") && text.length() < 12) {
            return list(businessReply(conversationId, contextCompany));
        }
        if (text.contains("商机线索") && text.length() < 12) {
            return list(opportunityReply(conversationId, contextCompany, "存款"));
        }
        if (text.contains("营销话术") && text.length() < 12) {
            return list(scriptReply(conversationId, contextCompany, "办公室场景"));
        }

        // 4. 业务知识问答的深入选项（需排在通用“贷款/介绍”匹配之前）
        if (text.contains("定义")) {
            return list(textReply(conversationId,
                    "固定资产贷款是向企（事）业法人发放的，用于新建、扩建、改造、购置固定资产投资项目 的本外币贷款"));
        }
        if (text.contains("准入条件")) {
            return list(textReply(conversationId,
                    "固定资产贷款的准入条件固定资产贷款的准入条件固定资产贷款的准入条件"));
        }
        if (text.contains("适用范围")) {
            return list(textReply(conversationId,
                    "适用范围：用于固定资产投资项目的新建、扩建、改造、购置等本外币资金需求。"));
        }

        // 5. 今日任务 / 待办检索
        if (text.contains("今日任务") || text.contains("今日代办") || text.contains("今日待办")
                || text.contains("待办") || text.contains("代办")) {
            return list(todayTaskReply(conversationId));
        }

        // 6. 菜单查找 / 菜单检索（网格等）
        if (text.contains("菜单") || text.contains("网格") || text.contains("功能在哪")) {
            String keyword = text.replace("菜单查找", "").replace("菜单检索", "").replace("菜单", "")
                    .replace("功能在哪", "").replace("网格", "").trim();
            if (keyword.isEmpty() && text.contains("网格")) {
                keyword = "网格";
            }
            return list(menuReply(conversationId, keyword));
        }

        // 7. 分配触达任务
        if (text.contains("触达任务") && (text.contains("分配") || text.contains("请帮") || text.contains("准备"))) {
            String comp = extractCompany(text, DEFAULT_COMPANY);
            return list(reachTaskReply(conversationId, comp, "固定资产贷款"));
        }

        // 8. XX公司能做么 -> 请求补充报表
        if (text.contains("能做么") || text.contains("能做吗") || text.contains("可以做么") || text.contains("可以做吗")) {
            return reportRequestReplies(conversationId, extractCompany(text, DEFAULT_COMPANY));
        }

        // 9. 搜索企业（帮我搜索XX / 帮我找XX / 检索XX）
        String keyword = extractSearchKeyword(text);
        if (keyword != null) {
            return list(searchReply(conversationId, keyword));
        }

        // 10. 业务知识问答（固定资产贷款怎么做 / 什么是XX）
        if (text.contains("怎么做") || text.contains("什么是") || text.contains("介绍") || text.contains("贷款")) {
            return list(businessQAReply(conversationId, text.replace("?", "").replace("？", "")));
        }

        // 11. 兜底：按关键词再搜一次企业
        if (text.length() >= 2) {
            Map<String, Object> search = customerService.search(text, 5);
            if (search != null && ((Number) search.getOrDefault("total", 0)).longValue() > 0) {
                return list(searchReply(conversationId, text));
            }
        }

        ChatMessage fallback = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TEXT,
                "您好，我是OK营销助手。您可以输入客户关键词开始我们的会话，也可以点击下方“菜单查找 / 今日任务 / 营销助手”体验更多功能！");
        fallback.setConversationId(conversationId);
        return list(finish(fallback));
    }

    // ==================== 各场景应答 ====================

    /** 搜索企业（原型：帮您匹配到 10 条包含国泰的数据…） */
    public ChatMessage searchReply(String conversationId, String keyword) {
        Map<String, Object> result = customerService.search(keyword, 5);
        if (result == null) {
            return textReply(conversationId, "抱歉，企业检索服务暂时不可用，请稍后再试。");
        }
        long total = ((Number) result.getOrDefault("total", 0)).longValue();
        if (total == 0) {
            return textReply(conversationId, "未匹配到包含“" + keyword + "”的企业，建议您补充公司名称！");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_COMPANY_LIST,
                "帮您匹配到 " + total + " 条包含" + keyword + "的数据，您可以点击企业名称继续操作");
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("total", total);
        payload.put("list", result.get("list"));
        payload.put("more", result.get("more"));
        payload.put("keyword", keyword);
        m.setPayload(payload);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 企业四段分析（点击企业名称） */
    public ChatMessage analysisReply(String conversationId, String company, String contextCompany) {
        Map<String, Object> data = customerService.analysis(company);
        if (data == null) {
            return textReply(conversationId, "抱歉，企业分析服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_ANALYSIS,
                "我对" + company + "进行搜索得到信息如下：");
        m.setPayload(data);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 行业画像卡（1. 行业类型） */
    public ChatMessage industryReply(String conversationId, String company) {
        String comp = company != null && !company.isEmpty() ? company : "江苏国泰国际集团";
        Map<String, Object> data = customerService.industryProfile(comp);
        if (data == null) {
            return textReply(conversationId, "抱歉，行业画像服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_INDUSTRY_PROFILE,
                "根据查询内容我为您生成了" + comp + "行业画像卡");
        m.setPayload(data);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 业务画像卡（2. 业务信息） */
    public ChatMessage businessReply(String conversationId, String company) {
        String comp = company != null && !company.isEmpty() ? company : "江苏国泰国际集团";
        Map<String, Object> data = customerService.businessProfile(comp);
        if (data == null) {
            return textReply(conversationId, "抱歉，业务画像服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_BIZ_PROFILE,
                "根据查询内容我为您生成了" + comp + "业务画像图");
        m.setPayload(data);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 商机线索卡（3. 商机线索） */
    public ChatMessage opportunityReply(String conversationId, String company, String category) {
        String comp = company != null && !company.isEmpty() ? company : "江苏国泰国际集团";
        Map<String, Object> data = customerService.opportunities(comp, category);
        if (data == null) {
            return textReply(conversationId, "抱歉，商机线索服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_OPPORTUNITY,
                "针对" + comp + "存在 " + data.get("total") + " 条商机线索。");
        m.setPayload(data);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 营销话术卡（4. 营销话术） */
    public ChatMessage scriptReply(String conversationId, String company, String scene) {
        String comp = company != null && !company.isEmpty() ? company : "江苏国泰国际集团";
        Map<String, Object> data = customerService.scripts(comp, scene);
        if (data == null) {
            return textReply(conversationId, "抱歉，营销话术服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_SCRIPT,
                "针对" + comp + "为您推荐下列话术。");
        m.setPayload(data);
        m.setDeepQuestion("您也可以描述您需要运用的场景，我将为您匹配合适的话术");
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 今日任务 */
    public ChatMessage todayTaskReply(String conversationId) {
        Map<String, Object> data = taskService.todayTasks();
        if (data == null) {
            return textReply(conversationId, "抱歉，任务服务暂时不可用，请稍后再试。");
        }
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TASK_GROUPS,
                "我查询到您今日有 " + data.get("total") + " 条任务");
        m.setPayload(data);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 菜单查找（原型：网格 -> 功能宫格，前端一行 3 个，超过 3 个自动换行） */
    public ChatMessage menuReply(String conversationId, String keyword) {
        String shown = (keyword == null || keyword.isEmpty()) ? "相关" : keyword;
        List<Map<String, Object>> items = new ArrayList<>();
        items.add(menuItem("我的网格", "我的网格"));
        items.add(menuItem("网格名单落点", "网格名单落点"));
        items.add(menuItem("网格名单", "网格名单"));
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_MENU_GRID,
                "我共为您找到 " + items.size() + " 个" + shown + "相关的功能，您可以点击图标直接跳转到对应功能！");
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("keyword", keyword);
        payload.put("total", items.size());
        payload.put("items", items);
        m.setPayload(payload);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 触达任务（业务流程图 + 已生成任务） */
    public ChatMessage reachTaskReply(String conversationId, String company, String business) {
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TASK_FLOW,
                "我将为您分配对" + company + "开展" + business + "的触达任务");
        Map<String, Object> flow = taskService.flow();
        Map<String, Object> task = taskService.assignReachTask(company, business);
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("company", company);
        payload.put("business", business);
        payload.put("main", flow.get("main"));
        payload.put("sideGroups", flow.get("sideGroups"));
        payload.put("task", task);
        payload.put("sections", Arrays.asList("1. " + business + "业务流程", "2. 已经为您生成触达任务"));
        payload.put("linkText", "您可以点击此处跳转触达任务页面");
        m.setPayload(payload);
        m.setChips(PREPARE_CHIPS);
        m.setDeepQuestion("针对您即将开展的针对" + company + "的触达任务，您是否需要我为您做一下准备？");
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 报表补充请求（XX能做么）：先要资料，再提示相机上传 */
    public List<ChatMessage> reportRequestReplies(String conversationId, String company) {
        ChatMessage ask = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TEXT,
                "经过分析" + company + "是景气行业，目前是我行的存量客户，为了更好的回答您的问题需要您提供更多的公司经营信息、财物信息");
        ask.setConversationId(conversationId);
        ask.setChips(Arrays.asList("拍摄报表上传", "从相册选择报表"));

        ChatMessage tip = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TEXT,
                "您可以点击左下角相机上传经营日报表与财务报表示例图片，我将为您进行交叉分析");
        tip.setConversationId(conversationId);
        return list(finish(ask), finish(tip));
    }

    /** 报表交叉分析 */
    public ChatMessage reportAnalysisReply(String conversationId, String company) {
        Map<String, Object> data = customerService.reportAnalysis(company);
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_REPORT_ANALYSIS,
                "我将对" + company + "从公司信息、业务信息、商机等方面进行分析");
        m.setPayload(data);
        m.setChips(PREPARE_CHIPS);
        m.setConversationId(conversationId);
        return finish(m);
    }

    /** 业务知识问答（固定资产贷款怎么做） */
    public ChatMessage businessQAReply(String conversationId, String question) {
        com.ok.chat.store.KnowledgeQA qa = com.ok.chat.store.KnowledgeQA.fixAssetLoan();
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_ANALYSIS, qa.getIntro());
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("question", question);
        payload.put("sections", qa.getSections());
        payload.put("scopeItems", qa.getScopeItems());
        payload.put("scriptItems", qa.getScriptItems());
        m.setPayload(payload);
        m.setConversationId(conversationId);
        return finish(m);
    }

    // ==================== 工具方法 ====================

    private ChatMessage textReply(String conversationId, String text) {
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, ChatMessage.TYPE_TEXT, text);
        m.setConversationId(conversationId);
        return finish(m);
    }

    private ChatMessage finish(ChatMessage m) {
        if (m.getId() == null) {
            m.setId("M" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 4).toUpperCase());
        }
        if (m.getCreateTime() == null) {
            m.setCreateTime(System.currentTimeMillis());
        }
        return m;
    }

    private List<ChatMessage> list(ChatMessage... msgs) {
        return new ArrayList<>(Arrays.asList(msgs));
    }

    private Map<String, Object> menuItem(String label, String icon) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("label", label);
        m.put("icon", icon);
        return m;
    }

    /** 从输入中提取搜索关键词 */
    private String extractSearchKeyword(String text) {
        String[] prefixes = {"帮我搜索", "帮我搜", "搜索一下", "搜索", "检索一下", "检索", "帮我找", "找一下", "查找", "查一下", "找"};
        for (String p : prefixes) {
            if (text.startsWith(p) && text.length() > p.length()) {
                return text.substring(p.length()).trim();
            }
        }
        return null;
    }

    /** 句首引导词，提取公司名前先剥离，避免 “请帮我分配对XX公司…” 把前缀一起吃进公司名 */
    private static final String[] LEAD_IN_WORDS = {
            "请帮我", "帮我", "麻烦您", "麻烦", "我想", "我要", "想", "需要", "可以",
            "请", "对", "给", "为", "关于", "查询", "查一下", "搜索",
            "分配", "开展", "安排", "生成", "创建"
    };

    private static final java.util.regex.Pattern COMPANY_PATTERN = java.util.regex.Pattern
            .compile("([\\u4e00-\\u9fa5A-Za-z0-9]{2,20}?(?:公司|集团|厂|企业))");

    /**
     * 提取句中的公司名（“XX公司能做么” / “对XX开展YY”）。
     * 优先命中企业库中的已知企业名，其次剥离句首引导词后按“以公司/集团/厂/企业结尾”提取。
     */
    private String extractCompany(String text, String defaultCompany) {
        String t = text;

        // 1) 已知企业名优先（取最长命中，避免“国泰航空”抢先于“江苏国泰国际集团”）
        String best = null;
        for (Map<String, Object> c : MockStore.companies()) {
            String name = String.valueOf(c.get("name"));
            if (t.contains(name) && (best == null || name.length() > best.length())) {
                best = name;
            }
        }
        if (best != null) {
            return best;
        }

        // 2) 剥离句首引导词后按后缀提取
        String stripped = stripLeadIn(t);
        java.util.regex.Matcher m = COMPANY_PATTERN.matcher(stripped);
        if (m.find()) {
            return m.group(1);
        }
        return defaultCompany;
    }

    /** 反复剥离句首引导词，最多 5 轮 */
    private String stripLeadIn(String text) {
        String t = text.trim();
        for (int round = 0; round < 5; round++) {
            boolean changed = false;
            for (String w : LEAD_IN_WORDS) {
                if (t.startsWith(w) && t.length() > w.length()) {
                    t = t.substring(w.length()).trim();
                    changed = true;
                }
            }
            if (!changed) {
                break;
            }
        }
        return t;
    }

    /**
     * 判断用户是否点击/输入了某个企业名。
     * 精确匹配企业库，允许 “2. 江苏国泰国际集团” 这类带序号前缀的写法。
     */
    private String matchCompany(String text) {
        String t = text.trim().replaceFirst("^\\d+\\s*[.、)）]\\s*", "").trim();
        if (t.isEmpty()) {
            return null;
        }
        for (Map<String, Object> c : MockStore.companies()) {
            String name = String.valueOf(c.get("name"));
            if (name.equals(t)) {
                return name;
            }
        }
        return null;
    }
}
