package com.ok.chat.web;

import com.ok.auth.LoginUser;
import com.ok.auth.UserContext;
import com.ok.chat.service.AssistantProperties;
import com.ok.chat.service.ConversationStore;
import com.ok.chat.service.DifyAnswerResolver;
import com.ok.chat.service.DifyChatService;
import com.ok.chat.service.DocumentPreviewService;
import com.ok.chat.service.FileTransferService;
import com.ok.chat.service.IntentService;
import com.ok.chat.service.QueryPayload;
import com.ok.common.ApiResponse;
import com.ok.common.ChatMessage;
import com.ok.common.Conversation;
import com.ok.common.PageResult;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 对话接口。
 * <ul>
 *   <li>ok.assistant.dify.enabled=true（默认）→ 对话与历史会话全部走 Dify 平台 Chatflow，
 *       会话 id 直接使用 Dify conversation_id，历史消息/会话列表/删除/反馈均代理 Dify Service API；</li>
 *   <li>enabled=false → 回退内置 mock 意图服务（离线演示）。</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/chat")
public class ChatController {

    /** 单页最大条数（与 Dify /v1/conversations 的 limit 上限一致） */
    private static final int MAX_PAGE_SIZE = 100;

    private final ConversationStore store;
    private final IntentService intentService;
    private final DifyChatService dify;
    private final AssistantProperties assistant;
    private final FileTransferService files;
    private final DocumentPreviewService preview;

    public ChatController(ConversationStore store, IntentService intentService, DifyChatService dify,
                          AssistantProperties assistant, FileTransferService files,
                          DocumentPreviewService preview) {
        this.store = store;
        this.intentService = intentService;
        this.dify = dify;
        this.assistant = assistant;
        this.files = files;
        this.preview = preview;
    }

    /**
     * 用户上下文与初始化窗口文案。
     *
     * <p>用户信息（工号 / 姓名 / 部门）<b>完全来自 userToken 的 SM4 解密结果</b>
     * （{@link AuthInterceptor} 写入 {@link UserContext}），配置里不再有用户字段；
     * 拿不到用户时（鉴权被关闭且未走 mock）对应字段为 null，由 spring.jackson 的
     * non_null 策略直接省略，前端显示为空。
     *
     * <p>welcomes 按底部菜单区分（menu / task / market），前端欢迎页按当前菜单取用。
     */
    @GetMapping("/profile")
    public ApiResponse<Map<String, Object>> profile() {
        Map<String, Object> m = new LinkedHashMap<>();
        LoginUser me = UserContext.get();
        m.put("name", me == null ? null : me.getUserName());
        m.put("userId", me == null ? null : me.getUserId());
        m.put("dept", me == null ? null : me.getDept());
        m.put("welcomes", assistant.getWelcome());
        // 文件上传限制（与 Dify 侧文件参数 userinput.files 的类型/大小配置保持一致，前端据此做本地校验）
        Map<String, Object> upload = new LinkedHashMap<>();
        upload.put("maxFiles", assistant.getUploadMaxFiles());
        upload.put("docMaxMb", assistant.getUploadDocMaxMb());
        upload.put("imageMaxMb", assistant.getUploadImageMaxMb());
        m.put("upload", upload);
        // 文档在线预览能力（Word/Excel/PPT 需服务端 LibreOffice 转换；前端据此决定是否发起预览请求）
        Map<String, Object> previewInfo = new LinkedHashMap<>();
        previewInfo.put("enabled", preview.enabled());
        previewInfo.put("available", preview.available());
        previewInfo.put("maxSizeMb", assistant.getPreview().getMaxSizeMb());
        m.put("preview", previewInfo);
        // 原生容器（门户 App）打开子页面的约定：JSBridge 开关 + 地址前缀（菜单检索结果用于跳转）
        Map<String, Object> nativeCfg = new LinkedHashMap<>();
        nativeCfg.put("enabled", assistant.isNativeEnabled());
        nativeCfg.put("baseUrl", assistant.getNativeBaseUrl());
        m.put("native", nativeCfg);
        // 前端调试面板开关（ok.assistant.debug-enabled，默认 false）：
        // 前端 js/debug.js 只在 enabled=true 时才渲染悬浮入口，关闭时不拦截控制台、不占屏幕
        Map<String, Object> debugCfg = new LinkedHashMap<>();
        debugCfg.put("enabled", assistant.isDebugEnabled());
        m.put("debug", debugCfg);
        // 侧滑「最近会话」每页条数（前端首屏与「更多」都按此值请求）
        m.put("conversationPageSize", assistant.getConversationPageSize());
        // 兼容：无菜单上下文时回落营销助手文案
        AssistantProperties.Welcome fallback = assistant.getWelcome().get("market");
        m.put("welcome", fallback == null ? null : fallback.getTitle());
        m.put("welcomeSub", fallback == null ? null : fallback.getSub());
        return ApiResponse.ok(m);
    }

    /**
     * 侧滑-最近会话列表（分页 + 服务端检索）。
     *
     * <p>首屏只取第一页（默认 {@code ok.assistant.conversation-page-size} 条，默认 15），
     * 前端点「更多」时带上 {@code offset=已加载条数} 再取下一页；
     * {@code keyword} 非空时由服务端检索（前端不再对已加载列表做本地过滤）。
     *
     * @param keyword 标题检索关键词（可选）
     * @param offset  起始偏移，默认 0
     * @param limit   每页条数，缺省用配置值；上限 100（Dify 单页上限）
     */
    @GetMapping("/conversations")
    public ApiResponse<PageResult<Conversation>> conversations(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(required = false) Integer limit) {
        int size = (limit == null || limit <= 0) ? assistant.getConversationPageSize() : limit;
        size = Math.max(1, Math.min(size, MAX_PAGE_SIZE));
        int from = Math.max(0, offset);

        if (dify.enabled()) {
            return ApiResponse.ok(dify.conversations(keyword, from, size));
        }
        List<Conversation> all = store.list(keyword);
        int start = Math.min(from, all.size());
        int end = Math.min(from + size, all.size());
        return ApiResponse.ok(new PageResult<>(new ArrayList<>(all.subList(start, end)),
                all.size(), from, size, end < all.size()));
    }

    /** 删除会话（最近-右侧删除图标；Dify 模式同时删除平台侧会话） */
    @DeleteMapping("/conversations/{id}")
    public ApiResponse<Void> delete(@PathVariable String id) {
        if (dify.enabled()) {
            dify.delete(id);
            return ApiResponse.ok();
        }
        store.delete(id);
        return ApiResponse.ok();
    }

    /** 清空最近（最近-右上角删除图标；Dify 模式逐个删除平台侧会话） */
    @DeleteMapping("/conversations")
    public ApiResponse<Void> clear() {
        if (dify.enabled()) {
            dify.clearAll();
            return ApiResponse.ok();
        }
        store.clearAll();
        return ApiResponse.ok();
    }

    /**
     * 会话消息列表（Dify 模式从平台拉取一问一答历史）。
     * 附件由 {@link DifyChatService#messages} 直接从该条消息的 {@code inputs.files} 还原 ——
     * 那是发消息时一并下发的文件列表，Dify 原样持久化，回带文件名/大小/类型与当前有效的下载地址，
     * 应用侧不再需要任何「消息 ↔ 附件」留档。
     */
    @GetMapping("/conversations/{id}/messages")
    public ApiResponse<List<ChatMessage>> messages(@PathVariable String id) {
        if (dify.enabled()) {
            return ApiResponse.ok(dify.messages(id));
        }
        return ApiResponse.ok(store.messageList(id));
    }

    /**
     * 发送消息（已合并原「创建会话」接口，不再单独提供新建会话入口）
     * <p>
     * body: {conversationId?, content, operatetype, intent?, company?, scene?, category?, images?,
     *        files?, extraData?}
     * <ul>
     *   <li>conversationId 为空或对应会话不存在 → Dify 侧自动创建新会话并回传 conversation_id</li>
     *   <li>conversationId 有效 → 续写同一 Dify 会话（平台侧自带多轮记忆）</li>
     *   <li>operatetype：底部菜单选择（菜单查找 / 今日任务 / 营销助手），作为 inputs 参数传给 Chatflow</li>
     *   <li><b>content 始终是用户可见的输入文本</b>（如点击企业卡片时的企业名称）；
     *       {@code extraData} 是卡片附带、只给后台用的附加数据（任意 JSON，如统一社会信用代码）。
     *       后端按 {@code ok.assistant.dify.query-format}（默认 always）把两者合成 query 信封
     *       {@code {"userinput":content,"extra_data":extraData}} 再交给 Chatflow（见 {@link QueryPayload}）。
     *       <b>所有类型的对话（文本输入 / 卡片点击 / 快捷菜单 / 带附件的消息）都走同一信封</b>，
     *       没有附加数据时 extra_data 为 {@code {}}；前端无需自己拼 JSON，所有卡片点击共用同一套入口。</li>
     * </ul>
     * Chatflow 的 answer 为 JSON 协议：{@code {"operatetype":"...","type":"text","content":"..."}}，
     * 由 {@link DifyAnswerResolver} 解析为「渲染类型 + 展示文本 + 结构化数据」。
     * <p>
     * intent 为 mock 演示链路专用（company_click / deep_* / report_upload），Dify 模式下仅透传文本。
     * <p>
     * 返回: {conversationId, isNew, conversation, messages}，前端首次发送后据此记住会话 id。
     */
    @PostMapping("/messages")
    public ApiResponse<Map<String, Object>> send(@RequestBody Map<String, Object> body) {
        String conversationId = trimToNull((String) body.get("conversationId"));
        String content = str(body.get("content"));
        String intent = str(body.get("intent"));
        String operateType = str(body.get("operatetype"));
        List<Map<String, Object>> files = body.get("files") instanceof List
                ? (List<Map<String, Object>>) body.get("files") : null;
        // 卡片附加数据（通用）：兼容 snake_case；字符串仅在以 { 或 [ 开头时按 JSON 解析，其余原样透传
        Object extraData = QueryPayload.normalize(
                body.get("extraData") == null ? body.get("extra_data") : body.get("extraData"));

        if (dify.enabled()) {
            return ApiResponse.ok(sendByDify(conversationId, content, operateType, files, extraData));
        }
        return ApiResponse.ok(sendByMock(body, conversationId, content, intent, files, extraData));
    }

    /**
     * 文件上传：前端「+」按钮 / 左下角相机选择文件后先调此接口，发消息时把 {id, name, size, kind} 列表随 body.files 带上。
     * <p>
     * <b>应用侧不保存任何文件</b>：启用 Dify 时直接转发平台的 {@code /v1/files/upload}，
     * 返回的 id 就是平台文件 id（发消息时由顶层 files 引用，即预设变量 {@code userinput.files}；
     * 同时写进 {@code inputs.files} 让平台持久化该条消息的附件）。
     * 未启用 Dify（离线演示）时只发一个临时 id，同样不保存字节 —— 该模式下的预览由浏览器本地对象承担。
     */
    @PostMapping("/files")
    public ApiResponse<Map<String, Object>> upload(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("请选择要上传的文件");
        }
        String name = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
        String contentType = file.getContentType();
        try {
            byte[] bytes = file.getBytes();
            if (dify.enabled()) {
                Map<String, Object> res = dify.uploadFile(bytes, name, contentType);
                String id = str(res.get("id"));
                if (id.isEmpty()) {
                    throw new IllegalStateException("Dify 未返回文件 id，上传失败");
                }
                return ApiResponse.ok(files.meta(id, name, bytes.length, contentType));
            }
            return ApiResponse.ok(files.meta(files.newLocalId(), name, bytes.length, contentType));
        } catch (java.io.IOException e) {
            throw new IllegalStateException("读取上传文件失败: " + e.getMessage(), e);
        }
    }

    /**
     * 附件读取，三种用途共用一条通路：
     * <ul>
     *   <li>图片（默认）→ 内联预览；</li>
     *   <li>{@code inline=1} → 弹层内联预览：PDF 原件直通，Word/Excel/PPT 由服务端转 PDF 后返回
     *       （浏览器无法直接渲染 Office，转换细节见 {@link DocumentPreviewService}）；</li>
     *   <li>{@code download=1} → 原始文件按附件下载（任何类型都返回原件，不是预览产物）。</li>
     * </ul>
     *
     * <p>每次都实时向 Dify 按需取：按「会话 + 文件 id」读一次会话历史拿到<b>刚签发</b>的地址 →
     * 服务端拉字节 → 转发给前端（转发而非 302，是为了保留文件名与 {@code Content-Disposition}）。
     * 应用侧不落盘、不缓存，故集群里任意实例都能处理 —— 详见 {@link FileTransferService}。
     *
     * <p>预览请求还需要一次「文件字节 → PDF」的本地转换。转换只在实例临时目录里进行、结束即清理，
     * 因此同样不破坏无状态：谁接到请求谁自己转一遍，不需要共享缓存或粘性会话。
     *
     * @param id       文件 id（Dify 平台文件 id）
     * @param cid      会话 id：文件对象挂在会话消息的 inputs 上，缺它无从取得
     * @param download 非空时按附件下载（返回原件）
     * @param inline   非空时按内联预览返回（PDF / Office 转 PDF）
     */
    @GetMapping("/files/{id}")
    public ResponseEntity<byte[]> download(@PathVariable String id,
                                           @RequestParam(required = false) String cid,
                                           @RequestParam(required = false) String download,
                                           @RequestParam(required = false) String inline) {
        boolean wantInline = download == null && inline != null;
        if (wantInline && (cid == null || cid.trim().isEmpty())) {
            // 还没随消息发出去的附件在平台上没有「会话」可以定位，预览无从取字节（前端会提示先发送）
            return errorResponse(HttpStatus.BAD_REQUEST, "附件尚未随消息发送，发送后即可预览");
        }
        FileTransferService.Content content = files.open(id, cid);
        if (content == null) {
            // 取不到字节：缺会话上下文、文件不在该会话、会话已删除，或平台侧瞬时不可用
            return ResponseEntity.notFound().build();
        }

        if (wantInline && DocumentPreviewService.canPreview(content.getName())) {
            String name = content.getName();
            if (DocumentPreviewService.isPdf(name)) {
                // PDF 原件浏览器就能显示，直接内联回吐，无需转换
                return inlineResponse(content.getBytes(), "application/pdf", name);
            }
            try {
                byte[] pdf = preview.toPdf(content.getBytes(), name);
                return inlineResponse(pdf, "application/pdf", baseNameOf(name) + ".pdf");
            } catch (DocumentPreviewService.PreviewException e) {
                // 未装 LibreOffice / 超时 / 转换失败 / 文件过大：给前端一句能直接展示的说明
                return errorResponse(HttpStatus.SERVICE_UNAVAILABLE, e.getMessage());
            }
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(content.getContentType()));
        boolean inlineImage = download == null && content.getContentType().startsWith("image/");
        headers.set(HttpHeaders.CONTENT_DISPOSITION,
                (inlineImage ? "inline" : "attachment") + "; filename=\"" + encodeFilename(content.getName(), id) + "\"");
        return new ResponseEntity<>(content.getBytes(), headers, HttpStatus.OK);
    }

    /** 内联预览响应：固定 PDF + 文件名 + 不缓存（会话删除后立即失效，避免浏览器留住旧副本） */
    private ResponseEntity<byte[]> inlineResponse(byte[] bytes, String contentType, String filename) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(contentType));
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + encodeFilename(filename, "preview.pdf") + "\"");
        headers.setCacheControl("no-store");
        return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
    }

    /** 失败响应：统一用 JSON 体，前端读 message 直接展示 */
    private ResponseEntity<byte[]> errorResponse(HttpStatus status, String message) {
        String json = "{\"code\":" + status.value() + ",\"message\":\""
                + (message == null ? "预览失败" : message.replace("\\", "\\\\").replace("\"", "\\\""))
                + "\",\"data\":null}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(new MediaType(MediaType.APPLICATION_JSON, StandardCharsets.UTF_8));
        headers.setCacheControl("no-store");
        return new ResponseEntity<>(json.getBytes(StandardCharsets.UTF_8), headers, status);
    }

    /** 文件名做 URL 编码（中文/空格都能在 Content-Disposition 里安全传递） */
    private String encodeFilename(String name, String fallback) {
        try {
            return URLEncoder.encode(name == null || name.isEmpty() ? fallback : name, "UTF-8")
                    .replace("+", "%20");
        } catch (java.io.UnsupportedEncodingException e) {
            return fallback;
        }
    }

    /** 去掉扩展名的文件名（预览产物用 .pdf 后缀） */
    private String baseNameOf(String name) {
        String n = name == null ? "" : name;
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(0, i) : n;
    }

    /**
     * Dify 链路：conversation_id 直接使用 Dify 会话 id；
     * answer 按 Chatflow 的 JSON 协议解析（type → 渲染模板、content → 展示文本、operatetype → 菜单归属）；
     * 新会话发送成功后按首条消息设置标题（平台侧 rename，失败不影响主流程）。
     *
     * <p>query 与 extraData 在 {@link DifyChatService#send} 内合成 query 信封；
     * 会话标题用<b>用户可见文本</b>（content），保证列表标题不被 JSON 污染。
     * 附件（本轮的与历史的）由 Dify 自己保存与回带，应用侧不落盘、不留档。
     */
    private Map<String, Object> sendByDify(String conversationId, String query, String operateType,
                                           List<Map<String, Object>> files, Object extraData) {
        boolean isNew = conversationId == null;

        // 前端拿到的文件 id 就是 Dify 平台文件 id（上传接口直接回传平台 id），原样透传即可：
        // 平台最终以顶层 files 字段发出（即开始节点预设变量 userinput.files），
        // 并在 DifyChatService 内同时写进 inputs.files 让平台持久化该条消息的附件
        List<Map<String, Object>> platformFiles = files == null ? new ArrayList<>() : new ArrayList<>(files);

        Map<String, Object> turn = dify.send(query, conversationId, operateType, platformFiles, extraData);
        String difyCid = str(turn.get("conversationId"));
        if (difyCid.isEmpty()) {
            difyCid = conversationId;
        }
        if (isNew) {
            // 标题用「用户可见文本」：query 本身已是可见文本，这里再过一次拆包兜底，
            // 防止调用点传入的是信封 JSON 时把 JSON 写进会话标题
            dify.rename(difyCid, conversationTitle(QueryPayload.userInput(query)));
        }

        Object ts = turn.get("createTime");
        long createTime = ts instanceof Number ? ((Number) ts).longValue() : System.currentTimeMillis();

        ChatMessage bot = DifyAnswerResolver.toBotMessage(str(turn.get("answer")), difyCid,
                str(turn.get("messageId")), createTime);
        if (bot.getOperateType().isEmpty() && operateType != null) {
            // Chatflow 未在应答里声明菜单时，用本轮实际传入的菜单兜底
            bot.setOperateType(operateType);
        }

        Conversation conv = new Conversation(difyCid,
                isNew ? conversationTitle(QueryPayload.userInput(query)) : null, Conversation.ICON_BLUE, createTime);
        conv.setOperateType(bot.getOperateType().isEmpty() ? null : bot.getOperateType());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("conversationId", difyCid);
        data.put("isNew", isNew);
        data.put("conversation", conv);
        data.put("messages", Collections.singletonList(bot));
        return data;
    }

    /** mock 回退链路（ok.assistant.dify.enabled=false 时使用），逻辑与原实现一致 */
    private Map<String, Object> sendByMock(Map<String, Object> body, String conversationId,
                                           String content, String intent, List<Map<String, Object>> files,
                                           Object extraData) {
        String company = (String) body.get("company");
        String scene = (String) body.get("scene");
        String category = (String) body.get("category");

        // ---------- 会话：有 conversationId 且存在则复用，否则新建 ----------
        // 标题统一取「用户可见文本」（content 已是可见文本，再过一次拆包兜底，与 Dify 链路一致）
        boolean isNew = false;
        Conversation conv = conversationId == null ? null : store.get(conversationId);
        if (conv == null) {
            conv = store.create(conversationTitle(QueryPayload.userInput(content)));
            conversationId = conv.getId();
            isNew = true;
        } else if (store.messageList(conversationId).isEmpty() && !content.isEmpty()) {
            // 空会话的首条消息：用消息内容刷新标题
            store.touch(conversationId, conversationTitle(QueryPayload.userInput(content)));
        } else {
            store.touch(conversationId, null);
        }

        // 用户消息（报表上传时保存为图片消息）
        ChatMessage userMsg;
        if ("report_upload".equals(intent) && body.get("images") instanceof List) {
            userMsg = new ChatMessage(ChatMessage.FROM_USER, ChatMessage.TYPE_REPORT_IMAGES, "[报表已上传]");
            userMsg.setPayload(new java.util.HashMap<>());
            userMsg.getPayload().put("images", body.get("images"));
        } else {
            userMsg = new ChatMessage(ChatMessage.FROM_USER, ChatMessage.TYPE_TEXT, content);
        }
        userMsg.setId("M" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 4).toUpperCase());
        userMsg.setConversationId(conversationId);
        userMsg.setCreateTime(System.currentTimeMillis());
        if (!QueryPayload.isEmpty(extraData)) {
            // mock 链路不调 Dify，附加数据留在消息上，便于本地演示时核对前端传了什么
            userMsg.setExtraData(extraData);
        }
        if (files != null && !files.isEmpty()) {
            userMsg.setFiles(files);
        }
        store.append(userMsg);

        // 上下文企业
        String contextCompany = company;
        if (contextCompany == null) {
            contextCompany = currentCompany.get(conversationId);
        }

        // 生成应答
        List<ChatMessage> replies;
        if ("company_click".equals(intent) && company != null) {
            currentCompany.put(conversationId, company);
            replies = new ArrayList<>();
            replies.add(intentService.analysisReply(conversationId, company, company));
        } else if ("deep_industry".equals(intent)) {
            replies = list(intentService.industryReply(conversationId, contextCompany));
        } else if ("deep_business".equals(intent)) {
            replies = list(intentService.businessReply(conversationId, contextCompany));
        } else if ("deep_opportunity".equals(intent)) {
            currentCompany.put(conversationId, contextCompany);
            replies = list(intentService.opportunityReply(conversationId, contextCompany,
                    category == null ? "存款" : category));
        } else if ("deep_script".equals(intent)) {
            currentCompany.put(conversationId, contextCompany);
            replies = list(intentService.scriptReply(conversationId, contextCompany,
                    scene == null ? "办公室场景" : scene));
        } else if ("report_upload".equals(intent)) {
            replies = list(intentService.reportAnalysisReply(conversationId,
                    contextCompany == null ? "江苏韵瑞新能源汽车配件公司" : contextCompany));
        } else {
            replies = intentService.reply(conversationId, content, contextCompany);
        }

        // 记录应答 + 维护上下文
        for (ChatMessage r : replies) {
            r.setConversationId(conversationId);
            store.append(r);
            rememberContext(conversationId, r);
        }

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("conversationId", conversationId);
        data.put("isNew", isNew);
        data.put("conversation", store.get(conversationId));
        data.put("messages", replies);
        return data;
    }

    /** 消息反馈（点赞/点踩/复制；Dify 模式代理平台的 feedbacks 接口） */
    @PostMapping("/messages/{id}/feedback")
    public ApiResponse<Void> feedback(@PathVariable String id, @RequestParam String type) {
        if (dify.enabled()) {
            dify.feedback(id, type);
            return ApiResponse.ok();
        }
        feedbacks.put(id, type);
        return ApiResponse.ok();
    }

    private final Map<String, String> currentCompany = new LinkedHashMap<>();
    private final Map<String, String> feedbacks = new LinkedHashMap<>();

    private void rememberContext(String conversationId, ChatMessage msg) {
        if (msg.getPayload() == null) {
            return;
        }
        Object company = msg.getPayload().get("company");
        if (company != null) {
            currentCompany.put(conversationId, String.valueOf(company));
        }
    }

    private List<ChatMessage> list(ChatMessage m) {
        List<ChatMessage> l = new ArrayList<>();
        l.add(m);
        return l;
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    /** 空串 / 全空白 视为「没有会话」 */
    private static String trimToNull(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    /** 新会话标题：取首条消息前 12 个字 */
    private static String conversationTitle(String content) {
        String t = content == null ? "" : content.trim();
        if (t.isEmpty()) {
            return "新会话";
        }
        return t.length() > 12 ? t.substring(0, 12) : t;
    }
}
