package com.ok.chat.service;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 界面文案与上传/预览能力配置（application.yml: ok.assistant.*，全部可配置）
 *
 * <p>登录用户（工号 / 姓名 / 部门）不在这里配置：每次请求由 userToken 经 SM4 解密得到，
 * 业务层通过 {@link com.ok.auth.UserContext} 取用。
 *
 * <p>welcome 按底部菜单区分初始化窗口的欢迎文案：
 * key 与前端底部菜单一致（menu=菜单查找 / task=今日任务 / market=营销助手），
 * 未配置的菜单由前端回落到默认文案。
 */
@Component
@ConfigurationProperties(prefix = "ok.assistant")
public class AssistantProperties {

    /** 各菜单的初始化窗口欢迎文案 */
    private Map<String, Welcome> welcome = new LinkedHashMap<>();

    /** 单次最多可附带的文件数（与 Dify 开始节点 files 变量的「最大上传数」一致） */
    private int uploadMaxFiles = 10;

    /** 单个文档类附件上限（MB），与 Dify 变量配置「文档 < 15MB」一致 */
    private int uploadDocMaxMb = 15;

    /** 单个图片类附件上限（MB），与 Dify 变量配置「图片 < 10MB」一致 */
    private int uploadImageMaxMb = 10;

    /**
     * 侧滑「最近会话」每页条数：首屏默认展示最近 N 条，点「更多」每次再加载 N 条。
     * 请求未传 limit 时后端按此值兜底，同时通过 /api/chat/profile 下发给前端。
     */
    private int conversationPageSize = 15;

    /**
     * 原生容器（门户 App）里子页面的地址前缀。
     *
     * <p>菜单检索结果里若给的是相对地址（如 {@code /mobs4.0-TMF-SIT/...}），
     * 前端会拼上该前缀再交给 JSBridge；给的是完整 http(s) 地址则原样使用。
     * 例：{@code https://10.0.0.8:8443}（对应门户里的 VUE_APP_CUSTOMER_IP）。
     */
    private String nativeBaseUrl = "";

    /** 是否允许通过 JSBridge 打开原生页面（false = 一律走浏览器打开，便于桌面调试） */
    private boolean nativeEnabled = true;

    /**
     * 是否启用前端调试面板（悬浮「调试」按钮：环境 / 凭证 / 日志）。
     *
     * <p><b>默认关闭</b>：生产环境不给最终用户看到调试入口。
     * 联调时设 {@code OK_DEBUG_ENABLED=true} 打开，前端从 {@code /api/chat/profile}
     * 的 {@code debug.enabled} 读到后才会渲染入口；关闭时整块不加载（控制台也不会被拦截）。
     */
    private boolean debugEnabled = false;

    /** 文档在线预览（Word/Excel/PPT → PDF）配置 */
    private Preview preview = new Preview();

    public Map<String, Welcome> getWelcome() {
        return welcome;
    }

    public void setWelcome(Map<String, Welcome> welcome) {
        this.welcome = welcome;
    }

    public int getUploadMaxFiles() {
        return uploadMaxFiles;
    }

    public void setUploadMaxFiles(int uploadMaxFiles) {
        this.uploadMaxFiles = uploadMaxFiles;
    }

    public int getUploadDocMaxMb() {
        return uploadDocMaxMb;
    }

    public void setUploadDocMaxMb(int uploadDocMaxMb) {
        this.uploadDocMaxMb = uploadDocMaxMb;
    }

    public int getUploadImageMaxMb() {
        return uploadImageMaxMb;
    }

    public void setUploadImageMaxMb(int uploadImageMaxMb) {
        this.uploadImageMaxMb = uploadImageMaxMb;
    }

    public int getConversationPageSize() {
        return conversationPageSize;
    }

    public void setConversationPageSize(int conversationPageSize) {
        this.conversationPageSize = conversationPageSize;
    }

    public String getNativeBaseUrl() {
        return nativeBaseUrl;
    }

    public void setNativeBaseUrl(String nativeBaseUrl) {
        this.nativeBaseUrl = nativeBaseUrl;
    }

    public boolean isNativeEnabled() {
        return nativeEnabled;
    }

    public void setNativeEnabled(boolean nativeEnabled) {
        this.nativeEnabled = nativeEnabled;
    }

    public boolean isDebugEnabled() {
        return debugEnabled;
    }

    public void setDebugEnabled(boolean debugEnabled) {
        this.debugEnabled = debugEnabled;
    }

    public Preview getPreview() {
        return preview;
    }

    public void setPreview(Preview preview) {
        this.preview = preview;
    }

    /**
     * 文档预览配置（ok.assistant.preview.*）。
     *
     * <p>对话里上传的 Word / Excel / PPT 无法被浏览器直接渲染，服务端用 LibreOffice（headless）
     * 转成 PDF 后内联展示 —— 保真度接近本地打开，前端也只需要一个 iframe。
     * 目标机器需安装 LibreOffice；没装时预览接口会给出「请下载后查看」的明确提示，
     * 对话与其他附件功能都不受影响。
     */
    public static class Preview {

        /** 是否开启文档在线预览（关掉后 Word/Excel/PPT 一律只能下载） */
        private boolean enabled = true;

        /**
         * soffice 可执行文件路径（留空 = 自动探测：PATH → 常见安装目录）。
         * 典型值：{@code C:\Program Files\LibreOffice\program\soffice.com}
         * （Windows 优先用 .com 控制台版，它会等待转换结束；也兼容 .exe）。
         */
        private String soffice = "";

        /** 单次转换超时（秒） */
        private int timeoutSeconds = 60;

        /**
         * 并发转换数。LibreOffice 不能多进程共用同一个用户配置目录，
         * 服务按此值准备等量独立配置目录（槽位），多余请求排队等待。
         */
        private int concurrency = 2;

        /** 可转换的文件大小上限（MB，0 = 不限制）；超过则提示下载后查看 */
        private int maxSizeMb = 20;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getSoffice() {
            return soffice;
        }

        public void setSoffice(String soffice) {
            this.soffice = soffice;
        }

        public int getTimeoutSeconds() {
            return timeoutSeconds;
        }

        public void setTimeoutSeconds(int timeoutSeconds) {
            this.timeoutSeconds = timeoutSeconds;
        }

        public int getConcurrency() {
            return concurrency;
        }

        public void setConcurrency(int concurrency) {
            this.concurrency = concurrency;
        }

        public int getMaxSizeMb() {
            return maxSizeMb;
        }

        public void setMaxSizeMb(int maxSizeMb) {
            this.maxSizeMb = maxSizeMb;
        }
    }

    /** 单个菜单的欢迎文案 */
    public static class Welcome {

        /** 主标题 */
        private String title;

        /** 副标题（引导语） */
        private String sub;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSub() {
            return sub;
        }

        public void setSub(String sub) {
            this.sub = sub;
        }
    }
}
