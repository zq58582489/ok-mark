package com.ok.chat.service;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Dify 平台对接参数（application.yml: ok.assistant.dify.*，全部可配置）
 */
@Component
@ConfigurationProperties(prefix = "ok.assistant.dify")
public class DifyProperties {

    /** 是否启用 Dify；false 时回退到内置 mock 意图服务（离线演示） */
    private boolean enabled = false;

    /** Dify 服务根地址（不带 /v1，接口路径由客户端统一拼接） */
    private String baseUrl = "http://127.0.0.1";

    /** Chatflow（高级聊天）应用的 API Key，app- 开头 */
    private String apiKey = "";

    /** Dify 侧终端用户标识（Dify 会话按 user 隔离，需与登录用户一致） */
    private String user = "22340117";

    /**
     * 单次请求超时（毫秒）；blocking 模式下等待 Chatflow 执行完成。
     *
     * <p>默认 <b>180000（3 分钟）</b>：Chatflow 里如果串了知识检索、多轮工具调用，
     * 一次回复跑到 1~2 分钟是正常的，90 秒会误杀。前端对话请求的超时比它再长 30 秒，
     * 这样正常情况下总是后端先返回「AI 服务响应超时」，用户看到的是明确原因而不是网络错误。
     */
    private long timeoutMs = 180000;

    /** 底部菜单选择传给 Chatflow 的输入参数名（inputs 中的 key） */
    private String inputOperateType = "operatetype";

    /**
     * query 是否包成结构化信封。
     * <ul>
     *   <li>{@code always}（默认）—— <b>所有类型的对话</b>（文本输入 / 卡片点击 / 快捷菜单 /
     *       带附件的消息）query 一律包成 {@code {"userinput":"…","extra_data":{…}}}，
     *       没有附加数据时 extra_data 为 {@code {}}。Chatflow 侧只需一套 JSON 解析逻辑；</li>
     *   <li>{@code auto} —— 只有本轮带了 extra_data 才包，其余保持纯文本（老流程行为）；</li>
     *   <li>{@code plain} —— 始终纯文本（附加数据只走 input-extra-data 变量，若有配置）。</li>
     * </ul>
     */
    private String queryFormat = "always";

    /**
     * 额外数据（extra_data）同时作为开始节点变量传入时的变量名；
     * 空 = 不传。主通道是 query 信封（Dify 会持久化 query，附加数据因此可随历史回看）。
     */
    private String inputExtraData = "";

    /**
     * 会话检索时最多向后扫描的条数。
     * Dify 会话列表接口没有「按名称检索」参数，只能按游标从新到旧翻页后在服务端过滤，
     * 这里限制一次检索最多回溯多少条，避免大账号下全量拉取。
     */
    private int conversationScanMax = 300;

    /**
     * 承载「本轮附件」的 <b>inputs 变量名</b>（默认 {@code files}，即 Chatflow 开始节点自带的文件变量）。
     *
     * <p>发消息时文件会走两条通道：顶层 {@code files} 字段（预设变量 {@code userinput.files}，
     * 供 Chatflow 取用）与 {@code inputs.<本变量>}（供 Dify 持久化）。后者是历史回显附件的前提：
     * 实测只传顶层 files 时，历史 {@code /v1/messages} 的 {@code message_files} 恒为空、
     * {@code inputs.files} 回带 null；带 inputs.files 后历史会回带
     * {@code filename / size / mime_type / type / related_id / url}，且 url 每次读取都重新签名。
     *
     * <p>留空 = 不写该通道（历史将不再回带附件）。本项目的附件字节<b>不落本地盘</b>，
     * 预览 / 下载由 {@link FileTransferService} 按会话向 Dify 取当前签名地址后实时拉取。
     */
    private String inputFiles = "files";

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public long getTimeoutMs() {
        return timeoutMs;
    }

    public void setTimeoutMs(long timeoutMs) {
        this.timeoutMs = timeoutMs;
    }

    public String getInputOperateType() {
        return inputOperateType;
    }

    public void setInputOperateType(String inputOperateType) {
        this.inputOperateType = inputOperateType;
    }

    public int getConversationScanMax() {
        return conversationScanMax;
    }

    public void setConversationScanMax(int conversationScanMax) {
        this.conversationScanMax = conversationScanMax;
    }

    public String getQueryFormat() {
        return queryFormat;
    }

    public void setQueryFormat(String queryFormat) {
        this.queryFormat = queryFormat;
    }

    public String getInputExtraData() {
        return inputExtraData;
    }

    public void setInputExtraData(String inputExtraData) {
        this.inputExtraData = inputExtraData;
    }

    public String getInputFiles() {
        return inputFiles;
    }

    public void setInputFiles(String inputFiles) {
        this.inputFiles = inputFiles;
    }
}
