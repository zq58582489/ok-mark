package com.ok.chat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 附件读取服务：<b>字节的唯一来源是 Dify，应用侧既不落盘也不在内存里留副本</b>。
 *
 * <p>本类<b>没有任何实例字段状态</b>（除注入的客户端），因此可以水平扩展：集群里上传落在实例 A、
 * 下载打到实例 B，B 也能照样取到字节；实例随时重启、扩缩容不影响任何请求。
 *
 * <p><b>为什么可以彻底去掉本地存储与内存快照</b>（2026-10 实测，api.dify.ai / Dify 1.17.1 Chatflow）：
 * <ul>
 *   <li>服务 API <b>没有</b>「按文件 id 取文件」的接口 ——
 *       {@code GET /v1/files/{id}/preview} 返回 {@code file_not_found}，无下载出口；</li>
 *   <li>但把文件写进 <b>{@code inputs.files}</b> 后，Dify 会把文件对象持久化在该条消息的 inputs 上，
 *       {@code GET /v1/messages} 回带 {@code filename / size / mime_type / type / related_id / url}
 *       （{@code url} 是免令牌可直连的签名预览地址）；</li>
 *   <li>该 {@code url} <b>每次读取都重新签名</b>（实测连续两次拉取 timestamp、nonce 均不同）——
 *       于是「每次实时读一次历史 → 拿最新地址 → 拉字节」就是一套永远不过期的方案，
 *       既不需要缓存字节，也不需要续期逻辑。</li>
 * </ul>
 *
 * <p>代价是每次下载多打一次平台历史接口（{@link DifyChatService#fileObject}）。这是刻意的取舍：
 * 用一点点延迟换取「无状态」，集群部署与多实例扩容都不需要任何跨实例共享或粘性会话。
 */
@Service
public class FileTransferService {

    private static final Logger log = LoggerFactory.getLogger(FileTransferService.class);

    /** 单文件下载超时（毫秒）：连接 5 秒、读取 30 秒 */
    private static final int CONNECT_TIMEOUT_MS = 5_000;
    private static final int READ_TIMEOUT_MS = 30_000;

    /** Dify 对话服务：按「会话 + 文件 id」实时取回刚签发的下载地址 */
    private final DifyChatService dify;

    /** 拉取文件服务地址用的轻量客户端（签名地址自带鉴权，无需 Bearer） */
    private final RestTemplate http;

    public FileTransferService(DifyChatService dify) {
        this.dify = dify;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(CONNECT_TIMEOUT_MS);
        factory.setReadTimeout(READ_TIMEOUT_MS);
        this.http = new RestTemplate(factory);
    }

    // ---------------- 元数据（上传响应与历史消息共用同一形状） ----------------

    /**
     * 组装前端使用的附件元数据：{@code {id, name, size, kind}}。
     * {@code kind} 由扩展名判定（图片 → image，其余 → document），与发给 Dify 的 {@code type} 一致。
     */
    public Map<String, Object> meta(String id, String name, long size, String contentType) {
        String safeName = name == null || name.isEmpty() ? "file" : name;
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", id);
        out.put("name", safeName);
        out.put("size", size);
        out.put("kind", DifyChatService.isImageName(safeName) ? "image" : "document");
        return out;
    }

    /**
     * 未启用 Dify（离线演示）时给上传文件发一个临时 id —— 应用侧<b>只发号，不保存任何东西</b>。
     * 这种模式下服务端没有字节来源，预览/下载由浏览器侧自己持有的本地对象承担（见前端 {@code fileUrl}）。
     */
    public String newLocalId() {
        return "L" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
    }

    // ---------------- 读取（每次实时向 Dify 按需取） ----------------

    /**
     * 取文件内容：按「会话 + 文件 id」实时向 Dify 要一个<b>本次新签发</b>的地址，服务端拉取后原样回吐
     * （服务端转发而非 302，是为了保留附件下载的 {@code Content-Disposition} 与文件名）。取不到返回 null。
     *
     * @param id             文件 id（Dify 侧 {@code related_id}）
     * @param conversationId 会话 id —— 文件对象挂在会话消息的 inputs 上，没有它就无从取得（必填）
     */
    public Content open(String id, String conversationId) {
        if (id == null || id.isEmpty()) {
            return null;
        }
        if (conversationId == null || conversationId.isEmpty()) {
            // 没有会话上下文：文件对象挂在消息 inputs 上，只能按会话取。
            // 印象里「刚上传还没发消息」的附件就属于这种情形 —— 前端此时用本地 blob 预览，不打扰服务端。
            log.debug("附件读取缺少会话上下文，无法定位: {}", id);
            return null;
        }
        Map<String, Object> f = dify.fileObject(conversationId, id);
        if (f == null) {
            log.debug("附件不在该会话内（或会话已删除）: {} @ {}", id, conversationId);
            return null;
        }
        byte[] bytes = fetchBytes(str(f.get("url")));
        if (bytes == null) {
            // 地址可能在拉取的瞬间失效（签名 TTL 由平台 FILES_ACCESS_TIMEOUT 控制，默认 300 秒）：
            // 再实时读一次历史拿一个刚签发的地址重试一次
            Map<String, Object> again = dify.fileObject(conversationId, id);
            if (again != null) {
                bytes = fetchBytes(str(again.get("url")));
                if (bytes != null) {
                    f = again;
                }
            }
        }
        if (bytes == null) {
            return null;
        }
        String name = str(f.get("filename"));
        return new Content(bytes, contentTypeOf(f), name.isEmpty() ? id : name);
    }

    /** 服务端拉取签名地址的字节（签名自带鉴权，不需要请求头） */
    private byte[] fetchBytes(String url) {
        if (url == null || url.isEmpty()) {
            return null;
        }
        try {
            return http.getForObject(URI.create(url), byte[].class);
        } catch (Exception e) {
            log.warn("文件读取失败（地址可能已过期）: {}", e.getMessage());
            return null;
        }
    }

    private static String contentTypeOf(Map<String, Object> f) {
        String ct = str(f.get("mime_type"));
        return ct.isEmpty() ? "application/octet-stream" : ct;
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    /** 一次读取的结果 */
    public static class Content {
        private final byte[] bytes;
        private final String contentType;
        private final String name;

        public Content(byte[] bytes, String contentType, String name) {
            this.bytes = bytes;
            this.contentType = contentType;
            this.name = name;
        }

        public byte[] getBytes() {
            return bytes;
        }

        public String getContentType() {
            return contentType;
        }

        public String getName() {
            return name;
        }
    }
}
