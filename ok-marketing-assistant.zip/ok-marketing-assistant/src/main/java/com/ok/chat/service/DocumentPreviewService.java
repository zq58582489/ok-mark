package com.ok.chat.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/**
 * 文档预览服务：把 <b>Word / Excel / PPT / CSV</b> 等浏览器无法直接渲染的文档，
 * 用服务端 LibreOffice（headless）转成 PDF 后再交给浏览器内联展示。
 *
 * <p><b>为什么走「转 PDF」</b>：图片与 PDF 浏览器原生就能显示，Office 三件套则不能 ——
 * 纯前端 JS 库（docx-preview / SheetJS / pptxjs）对 PPT 与复杂 Excel 的保真度损失较大，
 * 而 LibreOffice 转换出来的 PDF 与本地打开基本一致，且前端只要一个 iframe 就能显示所有格式。
 *
 * <p><b>仍然是无状态的</b>：输入文件与转换产物都只在实例本地临时目录里存在，转换完成（或失败）立即删除；
 * 不写数据目录、不缓存字节、不留索引。各实例各自调用自己机器上的 LibreOffice，
 * 因此集群里上传落在 A、预览打到 B 也能正常工作（B 自己转一遍）。
 *
 * <p><b>并发与隔离</b>：LibreOffice 不支持多进程共用同一个用户配置目录，
 * 这里按 {@code ok.assistant.preview.concurrency} 准备若干个「槽位」，
 * 每个槽位固定一个独立的 {@code -env:UserInstallation} 配置目录（进程内复用、加速首次启动），
 * 转换任务先取槽位再执行，从而既限制并发度又互不干扰。
 *
 * <p><b>部署前提</b>：目标机器需要安装 LibreOffice（或用 {@code ok.assistant.preview.soffice}
 * 指定 {@code soffice} 可执行文件路径）。未安装时预览接口返回明确提示，引导用户下载后查看，
 * 对话主链路不受任何影响。
 */
@Service
public class DocumentPreviewService {

    private static final Logger log = LoggerFactory.getLogger(DocumentPreviewService.class);

    /** 可直接内联预览（浏览器原生阅读器） */
    private static final Set<String> PDF_EXTS = new LinkedHashSet<>(Arrays.asList("pdf"));

    /** 需要转成 PDF 才能预览的文档类型 */
    private static final Set<String> OFFICE_EXTS = new LinkedHashSet<>(Arrays.asList(
            "doc", "docx", "docm", "dot", "dotx", "rtf", "odt",
            "xls", "xlsx", "xlsm", "xlt", "xltx", "ods", "csv", "tsv",
            "ppt", "pptx", "pptm", "pot", "potx", "odp"));

    /** 等待空闲转换槽位的最长时间（秒）：超过即提示用户稍后重试，避免请求长时间挂起 */
    private static final int SLOT_WAIT_SECONDS = 15;

    private final AssistantProperties assistant;

    /** 转换槽位（初始为 0..n-1）：取到即占用，用完归还；槽位号决定使用哪个 LibreOffice 配置目录 */
    private final BlockingQueue<Integer> slots = new LinkedBlockingQueue<>();

    /** 临时工作根目录：按实例端口隔离，避免同机多实例共用同一 LibreOffice 配置目录而互相干扰 */
    private final Path root;

    /** 解析出的 soffice 可执行文件路径（空串 = 不可用）；只探测一次 */
    private volatile String soffice;

    /** 是否已经探测过（避免每次请求都去翻文件系统） */
    private volatile boolean probed;

    public DocumentPreviewService(AssistantProperties assistant,
                                  @Value("${server.port:0}") int port) {
        this.assistant = assistant;
        this.root = Paths.get(System.getProperty("java.io.tmpdir"), "ok-preview",
                port > 0 ? ("p" + port) : "default");
        int n = Math.max(1, assistant.getPreview().getConcurrency());
        for (int i = 0; i < n; i++) {
            slots.offer(i);
        }
        cleanupStaleJobs();
    }

    /** 清理上次异常退出可能残留的一次性作业目录（配置目录保留，可加速下次启动） */
    private void cleanupStaleJobs() {
        if (!Files.isDirectory(root)) {
            return;
        }
        try (Stream<Path> list = Files.list(root)) {
            list.filter(p -> p.getFileName().toString().startsWith("job-")).forEach(this::deleteQuietly);
        } catch (IOException e) {
            log.debug("清理预览历史临时目录失败: {} - {}", root, e.getMessage());
        }
    }

    // ---------------- 类型判定（前后端一致：按扩展名，最直观也最稳） ----------------

    /** 取小写扩展名（不含点） */
    public static String extOf(String name) {
        String n = name == null ? "" : name.trim();
        int i = n.lastIndexOf('.');
        if (i < 0 || i == n.length() - 1) {
            return "";
        }
        return n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    /** 是否 PDF（浏览器原生阅读器可内联显示） */
    public static boolean isPdf(String name) {
        return PDF_EXTS.contains(extOf(name));
    }

    /** 是否需要转换成 PDF 才能预览 */
    public static boolean isOffice(String name) {
        return OFFICE_EXTS.contains(extOf(name));
    }

    /** 是否支持内联预览（PDF 直通 / Office 转换） */
    public static boolean canPreview(String name) {
        return isPdf(name) || isOffice(name);
    }

    // ---------------- 可用性 ----------------

    /** 配置开关是否打开 */
    public boolean enabled() {
        return assistant.getPreview().isEnabled();
    }

    /** 预览能力是否可用（开关打开 + 找到 LibreOffice） */
    public boolean available() {
        return enabled() && !resolveSoffice().isEmpty();
    }

    /** 当前使用的 soffice 路径（空串 = 不可用），供日志与接口自检用 */
    public String sofficePath() {
        return resolveSoffice();
    }

    // ---------------- 转换 ----------------

    /**
     * 把文档字节转成 PDF 字节。
     *
     * @param bytes    原始文件字节（来自 Dify）
     * @param filename 原始文件名（只用它的扩展名判断格式）
     * @throws PreviewException 任何不可预览的情形（未安装 / 超时 / 过大 / 转换失败），message 可直接展示给用户
     */
    public byte[] toPdf(byte[] bytes, String filename) {
        if (!assistant.getPreview().isEnabled()) {
            throw new PreviewException("文档预览未开启，请下载后查看");
        }
        String exe = resolveSoffice();
        if (exe.isEmpty()) {
            throw new PreviewException("服务端未安装 LibreOffice，暂不支持在线预览，请下载后查看");
        }
        int maxMb = assistant.getPreview().getMaxSizeMb();
        if (maxMb > 0 && bytes.length > (long) maxMb * 1024 * 1024) {
            throw new PreviewException("文件超过 " + maxMb + "MB，暂不支持在线预览，请下载后查看");
        }
        int slot = acquireSlot();
        try {
            return convert(exe, slot, bytes, filename);
        } finally {
            slots.offer(slot);
        }
    }

    /** 取一个空闲槽位（等待超时即放弃，避免请求长时间挂起） */
    private int acquireSlot() {
        try {
            Integer slot = slots.poll(SLOT_WAIT_SECONDS, TimeUnit.SECONDS);
            if (slot == null) {
                throw new PreviewException("预览任务较多，请稍后重试或直接下载");
            }
            return slot;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PreviewException("预览被中断，请重试");
        }
    }

    /** 单次转换：临时目录内写输入 → 调 soffice → 读回 PDF → 清理（无论成败） */
    private byte[] convert(String exe, int slot, byte[] bytes, String filename) {
        Path job = null;
        try {
            Files.createDirectories(root);
            // 每个槽位固定一个用户配置目录：LibreOffice 不允许并发共用同一 profile
            Path profile = root.resolve("profile-" + slot);
            Files.createDirectories(profile);
            job = root.resolve("job-" + UUID.randomUUID().toString().replace("-", "").substring(0, 12));
            Path out = job.resolve("out");
            Files.createDirectories(out);

            String ext = extOf(filename);
            // 固定输入文件名（不带用户原名）：输出名因此恒为 input.pdf，也不受中文/空格影响
            Path input = job.resolve(ext.isEmpty() ? "input.bin" : "input." + ext);
            Files.write(input, bytes);

            Path convertLog = job.resolve("convert.log");
            ProcessBuilder pb = new ProcessBuilder(command(exe, profile, out, input));
            pb.directory(job.toFile());
            pb.redirectErrorStream(true);
            pb.redirectOutput(convertLog.toFile());

            long begin = System.currentTimeMillis();
            Process p = pb.start();
            int timeout = Math.max(5, assistant.getPreview().getTimeoutSeconds());
            if (!p.waitFor(timeout, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                p.waitFor(3, TimeUnit.SECONDS);
                throw new PreviewException("文档转换超时（超过 " + timeout + " 秒），请下载后查看");
            }
            Path pdf = out.resolve("input.pdf");
            if (p.exitValue() != 0 || !Files.isRegularFile(pdf)) {
                log.warn("LibreOffice 转换失败（exit={}）: {} | {}",
                        p.exitValue(), filename, tail(convertLog));
                throw new PreviewException("文档转换失败，请下载后查看");
            }
            byte[] result = Files.readAllBytes(pdf);
            log.debug("文档预览转换完成: {} ({} 字节 → {} 字节, {} ms)",
                    filename, bytes.length, result.length, System.currentTimeMillis() - begin);
            return result;
        } catch (IOException e) {
            log.warn("文档预览转换异常: {} - {}", filename, e.getMessage());
            throw new PreviewException("文档转换失败，请下载后查看");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PreviewException("预览被中断，请重试");
        } finally {
            deleteQuietly(job);
        }
    }

    /** 组装 soffice 命令行（Windows 下若是 .cmd/.bat 包装脚本，需经 cmd /c 启动） */
    private List<String> command(String exe, Path profile, Path out, Path input) {
        List<String> cmd = new ArrayList<>();
        String lower = exe.toLowerCase(Locale.ROOT);
        if (isWindows() && (lower.endsWith(".cmd") || lower.endsWith(".bat"))) {
            cmd.add("cmd.exe");
            cmd.add("/c");
        }
        cmd.add(exe);
        cmd.add("-env:UserInstallation=" + profile.toUri());
        cmd.add("--headless");
        cmd.add("--norestore");
        cmd.add("--nolockcheck");
        cmd.add("--nodefault");
        cmd.add("--nologo");
        cmd.add("--nofirststartwizard");
        cmd.add("--convert-to");
        cmd.add("pdf");
        cmd.add("--outdir");
        cmd.add(out.toAbsolutePath().toString());
        cmd.add(input.toAbsolutePath().toString());
        return cmd;
    }

    // ---------------- LibreOffice 探测 ----------------

    /** 解析 soffice 可执行文件（只做一次；结果为空串表示不可用） */
    private String resolveSoffice() {
        if (probed) {
            return soffice;
        }
        synchronized (this) {
            if (probed) {
                return soffice;
            }
            String found = probe();
            if (found.isEmpty()) {
                log.warn("未找到 LibreOffice：Word/Excel/PPT 将只能下载、不能在线预览。"
                        + "安装后重启即可自动启用，或用 ok.assistant.preview.soffice 指定 soffice 可执行文件路径");
            } else {
                log.info("文档在线预览已启用，使用 LibreOffice: {}", found);
            }
            soffice = found;
            probed = true;
            return found;
        }
    }

    private String probe() {
        String configured = assistant.getPreview().getSoffice();
        if (configured != null && !configured.trim().isEmpty()) {
            File f = new File(configured.trim());
            if (f.isFile()) {
                return f.getAbsolutePath();
            }
            log.warn("ok.assistant.preview.soffice 指向的文件不存在: {}", configured);
        }
        for (String candidate : candidates()) {
            if (new File(candidate).isFile()) {
                return candidate;
            }
        }
        String fromPath = findOnPath();
        if (!fromPath.isEmpty()) {
            return fromPath;
        }
        return "";
    }

    /** 常见安装位置（按优先级） */
    private List<String> candidates() {
        List<String> list = new ArrayList<>();
        if (isWindows()) {
            String pf = System.getenv("ProgramFiles");
            String pf86 = System.getenv("ProgramFiles(x86)");
            for (String home : new String[]{pf, pf86}) {
                if (home != null && !home.isEmpty()) {
                    list.add(home + "\\LibreOffice\\program\\soffice.com");
                    list.add(home + "\\LibreOffice\\program\\soffice.exe");
                }
            }
        } else {
            list.add("/usr/bin/soffice");
            list.add("/usr/local/bin/soffice");
            list.add("/opt/libreoffice/program/soffice");
            list.add("/Applications/LibreOffice.app/Contents/MacOS/soffice");
        }
        return list;
    }

    /** 在 PATH 里查找 soffice（Windows 优先 .com，它是控制台版、会等待转换结束） */
    private String findOnPath() {
        String path = System.getenv("PATH");
        if (path == null || path.isEmpty()) {
            return "";
        }
        String[] names = isWindows()
                ? new String[]{"soffice.com", "soffice.exe"}
                : new String[]{"soffice"};
        for (String dir : path.split(File.pathSeparator)) {
            if (dir == null || dir.trim().isEmpty()) {
                continue;
            }
            for (String name : names) {
                File f = new File(dir.trim(), name);
                if (f.isFile()) {
                    return f.getAbsolutePath();
                }
            }
        }
        return "";
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    // ---------------- 清理工具 ----------------

    /** 递归删除临时作业目录（失败只记日志，绝不因为清理问题影响预览结果） */
    private void deleteQuietly(Path dir) {
        if (dir == null) {
            return;
        }
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // 个别文件可能还被 LibreOffice 短暂占用，留给系统临时目录清理
                }
            });
        } catch (IOException e) {
            log.debug("清理预览临时目录失败: {} - {}", dir, e.getMessage());
        }
    }

    /** 读取转换日志尾部（诊断用，避免日志过长） */
    private String tail(Path logFile) {
        try {
            if (!Files.isRegularFile(logFile)) {
                return "(无输出)";
            }
            String text = new String(Files.readAllBytes(logFile), StandardCharsets.UTF_8).trim();
            return text.length() <= 400 ? text : text.substring(text.length() - 400);
        } catch (IOException e) {
            return "(读取日志失败)";
        }
    }

    /** 预览不可用（message 可直接展示给用户） */
    public static class PreviewException extends RuntimeException {
        public PreviewException(String message) {
            super(message);
        }
    }
}
