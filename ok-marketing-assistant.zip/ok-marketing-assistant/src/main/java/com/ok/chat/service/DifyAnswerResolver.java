package com.ok.chat.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ok.common.ChatMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Chatflow 应答协议解析器。
 *
 * <p>Chatflow 的 answer 统一输出 JSON，例如：
 * <pre>
 * {"operatetype":"菜单查找","type":"text","content":"正在查找菜单"}
 * </pre>
 *
 * <p>协议约定（服务端 ↔ 前端）：
 * <ul>
 *   <li>{@code type} —— 渲染模板标识，映射为消息的 {@code msgType}，决定前端用哪种卡片渲染。
 *       约定使用小写下划线风格（text / company_list / task_flow …）。
 *       新增 type 时后端无需改动，前端在 index.html 补一个模板分支即可；
 *       前端未实现模板前，该消息只展示 {@code content} 文本，不会渲染异常。</li>
 *   <li>{@code content} —— 直接展示给用户的文本内容。</li>
 *   <li>{@code operatetype} —— 该轮所属底部菜单（菜单查找 / 今日任务 / 营销助手），
 *       历史会话回看时据此自动选中对应菜单；同时会把菜单值透传给 Chatflow 作为输入参数。</li>
 *   <li>{@code extra_data} —— <b>任意卡片通用</b>的附加数据（如企业统一社会信用代码）。
 *       提到消息的 {@code extraData} 字段下发前端；前端点击卡片元素（企业名称、chips、条目…）
 *       时把它连同用户可见输入一起回传，后端再包进 query 信封交给 Chatflow。</li>
 *   <li>其余字段（如 list / sections / items / chips / deepQuestion）—— 结构化数据，
 *       原样进入 {@code payload} 供对应模板取用。</li>
 * </ul>
 *
 * <p>兼容性：answer 不是 JSON、或 JSON 中既无 type 也无 content 时，整段按纯文本消息处理，
 * 保证历史数据、异常输出、以及未按协议输出的节点都能正常展示。
 */
public final class DifyAnswerResolver {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** 协议保留字段：不进入 payload */
    private static final Set<String> RESERVED_KEYS = new LinkedHashSet<>(Arrays.asList(
            "type", "content", "operatetype", "chips", "deepQuestion", "deep_question",
            "extra_data", "extraData"));

    private DifyAnswerResolver() {
    }

    /**
     * 把 Chatflow 的 answer 解析为一条机器人消息。
     *
     * @param rawAnswer      Dify 返回的 answer 原文（JSON 字符串或纯文本）
     * @param conversationId 所属会话
     * @param messageId      Dify message_id（反馈接口直接使用）
     * @param createTime     毫秒时间戳
     */
    public static ChatMessage toBotMessage(String rawAnswer, String conversationId,
                                           String messageId, long createTime) {
        Answer a = resolve(rawAnswer);
        ChatMessage m = new ChatMessage(ChatMessage.FROM_BOT, a.msgType, a.content);
        m.setConversationId(conversationId);
        m.setId(messageId);
        m.setCreateTime(createTime);
        m.setPayload(a.payload);
        m.setChips(a.chips);
        m.setDeepQuestion(a.deepQuestion);
        m.setOperateType(a.operateType);
        m.setExtType(a.extType);
        m.setExtraData(a.extraData);
        return m;
    }

    /** 解析 answer 文本（不构造消息） */
    public static Answer resolve(String rawAnswer) {
        String text = rawAnswer == null ? "" : rawAnswer.trim();
        if (!text.startsWith("{") || !text.endsWith("}")) {
            return Answer.plain(text);
        }
        Map<String, Object> map;
        try {
            map = MAPPER.readValue(text, new TypeReference<Map<String, Object>>() { });
        } catch (Exception e) {
            return Answer.plain(text);
        }
        if (map == null || (map.get("type") == null && map.get("content") == null)) {
            // 不是本协议的结构化应答（普通 JSON 文本），按纯文本处理
            return Answer.plain(text);
        }

        Answer ans = new Answer();
        ans.extType = str(map.get("type"));
        ans.msgType = toMsgType(ans.extType);
        ans.content = str(map.get("content"));
        ans.operateType = str(map.get("operatetype"));
        ans.chips = toChips(map.get("chips"));
        Object deep = map.get("deepQuestion") == null ? map.get("deep_question") : map.get("deepQuestion");
        ans.deepQuestion = deep == null ? null : str(deep);
        // 卡片附加数据（通用）：任意 type 的卡片都可用，前端点击卡片元素时随用户输入回传
        Object extra = map.get("extra_data") == null ? map.get("extraData") : map.get("extra_data");
        ans.extraData = QueryPayload.isEmpty(extra) ? null : extra;

        Map<String, Object> payload = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!RESERVED_KEYS.contains(e.getKey())) {
                payload.put(e.getKey(), e.getValue());
            }
        }
        // 无结构化数据的纯文本消息不带 payload（前端渲染时按 msgType 取用）
        ans.payload = payload.isEmpty() ? null : payload;
        return ans;
    }

    /** 结构性 type（text / company_list / task_flow …）→ 消息类型（TEXT / COMPANY_LIST / TASK_FLOW …） */
    private static String toMsgType(String extType) {
        if (extType == null) {
            return ChatMessage.TYPE_TEXT;
        }
        String t = extType.trim();
        if (t.isEmpty()) {
            return ChatMessage.TYPE_TEXT;
        }
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (ch >= 'a' && ch <= 'z') {
                sb.append((char) (ch - 32));
            } else if ((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) {
                sb.append(ch);
            } else {
                sb.append('_');
            }
        }
        return sb.length() == 0 ? ChatMessage.TYPE_TEXT : sb.toString();
    }

    /** chips 支持字符串数组，也兼容逗号分隔的字符串 */
    private static List<String> toChips(Object v) {
        List<String> out = new ArrayList<>();
        if (v instanceof List) {
            for (Object o : (List<?>) v) {
                String s = str(o);
                if (!s.isEmpty()) {
                    out.add(s);
                }
            }
        } else if (v != null) {
            for (String s : str(v).split("[,，]")) {
                String t = s.trim();
                if (!t.isEmpty()) {
                    out.add(t);
                }
            }
        }
        return out.isEmpty() ? null : out;
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    /** 解析结果（不可变） */
    public static final class Answer {

        private String msgType = ChatMessage.TYPE_TEXT;
        private String extType = "";
        private String content = "";
        private String operateType = "";
        private Map<String, Object> payload;
        private List<String> chips;
        private String deepQuestion;
        private Object extraData;

        private static Answer plain(String text) {
            Answer a = new Answer();
            a.content = text;
            return a;
        }

        /** 前端渲染类型（msgType） */
        public String getMsgType() {
            return msgType;
        }

        /** Chatflow 声明的原始 type */
        public String getExtType() {
            return extType;
        }

        /** 展示文本 */
        public String getContent() {
            return content;
        }

        /** 所属底部菜单（菜单查找 / 今日任务 / 营销助手），可能为空 */
        public String getOperateType() {
            return operateType;
        }

        /** 结构化数据（模板取用），无则为空 Map */
        public Map<String, Object> getPayload() {
            return payload;
        }

        /** 推荐选项，无则为 null */
        public List<String> getChips() {
            return chips;
        }

        /** 深入提示语，无则为 null */
        public String getDeepQuestion() {
            return deepQuestion;
        }

        /** 卡片附加数据（应答里的 extra_data），无则 null */
        public Object getExtraData() {
            return extraData;
        }
    }
}
