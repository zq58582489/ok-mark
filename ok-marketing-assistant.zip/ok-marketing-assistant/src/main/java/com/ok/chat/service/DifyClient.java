package com.ok.chat.service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Collections;
import java.util.Map;

/**
 * Dify Service API 轻量客户端（Spring Boot 2.7 / RestTemplate，无需新增依赖）
 * <p>
 * 对接 Dify 1.17.1 Chatflow（高级聊天）应用：
 * <ul>
 *   <li>POST /v1/chat-messages          发送对话消息（blocking）</li>
 *   <li>GET  /v1/conversations           会话列表</li>
 *   <li>GET  /v1/messages                会话消息历史</li>
 *   <li>POST /v1/conversations/{id}/name 会话重命名</li>
 *   <li>DELETE /v1/conversations/{id}    删除会话</li>
 *   <li>POST /v1/messages/{id}/feedbacks 消息点赞/点踩</li>
 * </ul>
 * 所有路径基于 base-url（根地址，不含 /v1）拼接。
 */
@Service
public class DifyClient {

    private final DifyProperties props;
    private final RestTemplate rest;

    public DifyClient(DifyProperties props) {
        this.props = props;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) Math.min(props.getTimeoutMs(), 10000));
        factory.setReadTimeout((int) props.getTimeoutMs());
        this.rest = new RestTemplate(factory);
    }

    private HttpHeaders headers() {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        h.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        h.setBearerAuth(props.getApiKey());
        return h;
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> post(String path, Map<String, Object> body) {
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers());
        Object res = rest.postForObject(props.getBaseUrl() + path, entity, Map.class);
        return (Map<String, Object>) res;
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> delete(String path, Map<String, Object> body) {
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers());
        ResponseEntity<Map> res =
                rest.exchange(props.getBaseUrl() + path, HttpMethod.DELETE, entity, Map.class);
        return (Map<String, Object>) res.getBody();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> get(String path, MultiValueMap<String, String> query) {
        URI uri = UriComponentsBuilder.fromHttpUrl(props.getBaseUrl() + path)
                .queryParams(query)
                .build()
                .encode()
                .toUri();
        // 注意：getForObject 无法携带请求头，必须用 exchange + HttpEntity，否则 Authorization 丢失（Dify 返回 401）
        ResponseEntity<Map> res =
                rest.exchange(uri, HttpMethod.GET, new HttpEntity<>(headers()), Map.class);
        return (Map<String, Object>) res.getBody();
    }

    /** 空 query 的 GET */
    public Map<String, Object> get(String path) {
        return get(path, new LinkedMultiValueMap<>());
    }

    /**
     * multipart 表单上传（POST），用于 /v1/files/upload 文件上传。
     * 表单字段由调用方组装（file + user），此处只负责带 Bearer 头发送。
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> upload(String path, MultiValueMap<String, Object> form) {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.MULTIPART_FORM_DATA);
        h.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        h.setBearerAuth(props.getApiKey());
        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(form, h);
        ResponseEntity<Map> res =
                rest.exchange(props.getBaseUrl() + path, HttpMethod.POST, entity, Map.class);
        return (Map<String, Object>) res.getBody();
    }
}
