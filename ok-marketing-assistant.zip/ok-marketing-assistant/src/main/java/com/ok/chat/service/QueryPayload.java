package com.ok.chat.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用户输入信封（query 结构化）。
 *
 * <p>卡片点击类操作既要给用户看到「企业名称」这样的自然语言，又要把后台查询所需的
 * 附加数据（如统一社会信用代码）一并带给 Chatflow。Dify 的会话历史只持久化 {@code query}
 * 等字段、额外的输入变量不保证留存，因此约定把两者一起放进 query：
 *
 * <pre>
 * {"userinput":"国泰航空有限公司","extra_data":{"creditCode":"91320100123456789X"}}
 * </pre>
 *
 * <p>规则：
 * <ul>
 *   <li>{@code userinput} —— 用户可见的输入文本（前端气泡展示、会话标题、附件对齐都用它）；</li>
 *   <li>{@code extra_data} —— 卡片附带的附加数据（任意 JSON）；<b>没有数据时也输出空对象 {@code {}}</b>，
 *       这样 Chatflow 侧每轮对话都能稳定取到该字段（统一按 JSON 解析，无需为空值分支）；</li>
 *   <li>整段作为一个 JSON <b>字符串</b> 放进 {@code query}，因此历史消息回看时也能取回附加数据。</li>
 * </ul>
 *
 * <p><b>所有类型的对话（文本输入 / 卡片点击 / 快捷菜单 / 附件随消息）都走这个信封</b> ——
 * 由 {@code ok.assistant.dify.query-format=always}（默认）保证，Chatflow 侧只需一套解析逻辑。
 * 解包（{@link #userInput}/{@link #extraData}）对老数据天然兼容：不是信封格式时原样返回。
 */
public final class QueryPayload {

    /** 用户可见输入字段名 */
    public static final String KEY_USER_INPUT = "userinput";
    /** 附加数据字段名 */
    public static final String KEY_EXTRA_DATA = "extra_data";

    /** 读取时兼容的 userinput 别名 */
    private static final String[] USER_INPUT_ALIASES = {KEY_USER_INPUT, "userInput", "user_input"};
    /** 读取时兼容的 extra_data 别名 */
    private static final String[] EXTRA_DATA_ALIASES = {KEY_EXTRA_DATA, "extraData"};

    /** 截断信封兜底用：匹配 userinput / userInput / user_input 的字符串值（含转义） */
    private static final Pattern USER_INPUT_PATTERN =
            Pattern.compile("\"(?:userinput|userInput|user_input)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private QueryPayload() {
    }

    /**
     * 组装信封：{@code {"userinput":...,"extra_data":...}}。
     *
     * <p>extra_data <b>始终输出</b>：没有附加数据时给空对象 {@code {}}，保证 Chatflow 侧每轮
     * 都能取到该字段（统一的 JSON 解析，不必再判空）。
     */
    public static String wrap(String userInput, Object extraData) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put(KEY_USER_INPUT, userInput == null ? "" : userInput);
        Object extra = normalize(extraData);
        m.put(KEY_EXTRA_DATA, isEmpty(extra) ? new LinkedHashMap<String, Object>() : extra);
        return toJson(m);
    }

    /**
     * 结构化 query → 展示文本；非信封（普通文本 / 解析失败 / 无 userinput）时原样返回。
     *
     * <p>另外对<b>被截断的信封</b>做了兜底：Dify 自动生成的会话标题只取原文前若干字符，
     * JSON 可能不完整（如 {@code {"userinput":"江苏国泰国际集团","extra_}}）。这类文本解析
     * 必然失败，但又明显是信封残片 —— 用正则把 {@code userinput} 的值抠出来，避免会话列表里
     * 出现 {@code {"userinput":"…"} 这样的原文。
     */
    public static String userInput(String rawQuery) {
        if (rawQuery == null) {
            return "";
        }
        Map<String, Object> m = parse(rawQuery);
        if (m != null) {
            for (String k : USER_INPUT_ALIASES) {
                Object v = m.get(k);
                if (v != null) {
                    return v instanceof Map || v instanceof Collection ? toJson(v) : String.valueOf(v);
                }
            }
            return rawQuery;
        }
        String salvaged = salvageUserInput(rawQuery);
        return salvaged == null ? rawQuery : salvaged;
    }

    /** 信封被截断时的兜底：仅当文本形似信封（以 { 开头且含 userinput 键）才抠值，返回 null 表示不适用 */
    private static String salvageUserInput(String raw) {
        String s = raw.trim();
        if (s.length() < 2 || s.charAt(0) != '{') {
            return null;
        }
        Matcher matcher = USER_INPUT_PATTERN.matcher(s);
        if (!matcher.find()) {
            return null;
        }
        String value = matcher.group(1);
        try {
            // 按 JSON 字符串规则反转义（引号、反斜杠、换行等）
            return MAPPER.readValue("\"" + value + "\"", String.class);
        } catch (Exception e) {
            return value;
        }
    }

    /** 结构化 query → extra_data（无则 null）；非信封时返回 null */
    public static Object extraData(String rawQuery) {
        Map<String, Object> m = parse(rawQuery);
        if (m == null) {
            return null;
        }
        for (String k : EXTRA_DATA_ALIASES) {
            Object v = m.get(k);
            if (!isEmpty(v)) {
                return v;
            }
        }
        return null;
    }

    /** 是否为协议信封（含 userinput 或 extra_data 的 JSON 对象） */
    public static boolean isEnvelope(String rawQuery) {
        return parse(rawQuery) != null;
    }

    /**
     * 归一化外部传入的额外数据：
     * 已是对象/集合则原样返回；是一段 JSON 文本则解析成对象（解析失败保留原文）。
     */
    public static Object normalize(Object extraData) {
        if (extraData instanceof String) {
            String s = ((String) extraData).trim();
            if (s.isEmpty()) {
                return null;
            }
            if (s.startsWith("{") || s.startsWith("[")) {
                try {
                    return MAPPER.readValue(s, new TypeReference<Object>() { });
                } catch (Exception ignored) {
                    // 不是合法 JSON：按普通字符串处理
                }
            }
        }
        return extraData;
    }

    /** 空判定：null / 空串 / 空 Map / 空集合 */
    public static boolean isEmpty(Object v) {
        if (v == null) {
            return true;
        }
        if (v instanceof String) {
            return ((String) v).trim().isEmpty();
        }
        if (v instanceof Map) {
            return ((Map<?, ?>) v).isEmpty();
        }
        if (v instanceof Collection) {
            return ((Collection<?>) v).isEmpty();
        }
        return false;
    }

    /** 任意对象 → JSON 文本（失败返回 String.valueOf） */
    public static String toJson(Object v) {
        try {
            return MAPPER.writeValueAsString(v);
        } catch (Exception e) {
            return String.valueOf(v);
        }
    }

    /** 解析信封；不是 JSON 对象、或既无 userinput 也无 extra_data 时返回 null */
    private static Map<String, Object> parse(String rawQuery) {
        if (rawQuery == null) {
            return null;
        }
        String s = rawQuery.trim();
        if (s.length() < 2 || s.charAt(0) != '{' || s.charAt(s.length() - 1) != '}') {
            return null;
        }
        Map<String, Object> m;
        try {
            m = MAPPER.readValue(s, new TypeReference<Map<String, Object>>() { });
        } catch (Exception e) {
            return null;
        }
        if (m == null) {
            return null;
        }
        for (String k : USER_INPUT_ALIASES) {
            if (m.containsKey(k)) {
                return m;
            }
        }
        for (String k : EXTRA_DATA_ALIASES) {
            if (m.containsKey(k)) {
                return m;
            }
        }
        return null;
    }
}
