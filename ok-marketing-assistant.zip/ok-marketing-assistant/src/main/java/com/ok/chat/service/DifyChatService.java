package com.ok.chat.service;

import com.ok.auth.UserContext;
import com.ok.common.ChatMessage;
import com.ok.common.Conversation;
import com.ok.common.PageResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Dify 对话业务服务：发送消息、历史会话、消息历史、反馈。
 * 负责把 Dify Service API 返回结构映射为前端使用的 Conversation / ChatMessage。
 */
@Service
public class DifyChatService {

    private static final Logger log = LoggerFactory.getLogger(DifyChatService.class);

    /** Dify 单页最大条数 */
    private static final int PAGE_LIMIT = 100;

    private final DifyProperties props;
    private final DifyClient client;

    public DifyChatService(DifyProperties props, DifyClient client) {
        this.props = props;
        this.client = client;
    }

    public boolean enabled() {
        return props.isEnabled();
    }

    /**
     * Dify 侧的终端用户标识（{@code user} 参数）。
     *
     * <p><b>取当前登录用户工号</b>（userToken 解密结果）：Dify 的会话按 user 隔离，
     * 用固定值会让所有用户共用一份会话列表。只有拿不到登录用户时
     * （鉴权被关闭、或白名单接口在无上下文线程里调用）才回落到配置的 {@code ok.assistant.dify.user}。
     */
    private String user() {
        String uid = UserContext.userId();
        return (uid == null || uid.trim().isEmpty()) ? props.getUser() : uid.trim();
    }

    /**
     * 发送一条消息（blocking 模式），并把底部菜单选择作为 inputs 参数传给 Chatflow。
     * 返回 {conversationId, messageId, answer, createTime}；
     * 其中 answer 是 Chatflow 的 JSON 协议原文，由 {@link DifyAnswerResolver} 解析为渲染类型与展示文本。
     */
    public Map<String, Object> send(String query, String conversationId, String operateType) {
        return send(query, conversationId, operateType, null);
    }

    public Map<String, Object> send(String query, String conversationId, String operateType,
                                    List<Map<String, Object>> files) {
        return send(query, conversationId, operateType, files, null);
    }

    /**
     * 带附件 + 附加数据发送：files 为前端上传后拿到的文件元数据列表（{id, name, kind}），
     * 会以<b>两条通道</b>同时下发（内容相同，作用不同）：
     * <ul>
     *   <li><b>顶层 files 字段</b> —— 即开始节点自带的预设变量 {@code userinput.files}（数组[文件]），
     *       Chatflow 侧用 {@code {{#userinput.files#}}} 取用，是流程的实际输入；</li>
     *   <li><b>{@code inputs.files}</b>（变量名由 {@code ok.assistant.dify.input-files} 配置，默认 {@code files}）
     *       —— 唯一目的是让 <b>Dify 把文件对象持久化到该条消息的 inputs 上</b>：
     *       实测只走顶层 files 时，历史 {@code /v1/messages} 的 {@code message_files} 恒为空、
     *       {@code inputs.files} 回带 null，附件在历史里彻底消失；而带 inputs.files 后，
     *       历史会回带 {@code filename / size / mime_type / type / related_id / url}，
     *       且 {@code url} 每次读取都重新签名（见 {@link FileTransferService}）。
     *       因此这是「历史回显附件 + 按需取字节」的前提，不是可选装饰。</li>
     * </ul>
     * 文件项格式统一为 {@code {type: image|document, transfer_method: local_file, upload_file_id}}。
     *
     * <p>extraData 为卡片附带的附加数据（如企业统一社会信用代码，可为 null）。按
     * {@code ok.assistant.dify.query-format}（默认 always：所有对话都包）把 query 包成
     * {@code {"userinput":"用户可见输入","extra_data":{…}}}，没有附加数据时 extra_data 为 {@code {}} ——
     * 走 query 而不是单独的输入变量，是因为 Dify 只持久化 query，附加数据因此能随会话历史回看。
     *
     * @param query      用户可见输入文本（前端气泡展示的内容）
     * @param extraData  卡片附加数据（任意 JSON），无则 null
     */
    public Map<String, Object> send(String query, String conversationId, String operateType,
                                    List<Map<String, Object>> files, Object extraData) {
        Map<String, Object> inputs = new LinkedHashMap<>();
        if (operateType != null && !operateType.trim().isEmpty()) {
            inputs.put(props.getInputOperateType(), operateType.trim());
        }
        List<Map<String, Object>> difyFiles = toDifyFiles(files);
        String filesVar = filesVariable();
        if (!difyFiles.isEmpty() && !filesVar.isEmpty()) {
            // 存档通道：Dify 会把文件对象写进该条消息的 inputs，历史接口因此能回带（含随取随新的下载地址）
            inputs.put(filesVar, difyFiles);
        }
        // 可选通道：附加数据同时作为开始节点变量下发（默认关闭；主通道是 query 信封）
        Object extra = QueryPayload.normalize(extraData);
        if (!props.getInputExtraData().trim().isEmpty() && !QueryPayload.isEmpty(extra)) {
            inputs.put(props.getInputExtraData().trim(), QueryPayload.toJson(extra));
        }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("inputs", inputs);
        body.put("query", buildQuery(query, extra));
        body.put("response_mode", "blocking");
        body.put("conversation_id", conversationId == null ? "" : conversationId);
        body.put("user", user());
        if (!difyFiles.isEmpty()) {
            body.put("files", difyFiles);
        }

        Map<String, Object> res = post("/v1/chat-messages", body);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("conversationId", str(res.get("conversation_id")));
        out.put("messageId", str(res.get("message_id")));
        out.put("answer", str(res.get("answer")));
        out.put("createTime", secToMs(res.get("created_at")));
        return out;
    }

    /** 按 ok.assistant.dify.query-format 决定 query 形态：always（默认，所有对话都包信封）/ auto（有附加数据才包）/ plain */
    private String buildQuery(String query, Object extraData) {
        String text = query == null ? "" : query;
        String fmt = props.getQueryFormat() == null ? "always" : props.getQueryFormat().trim().toLowerCase();
        boolean wrap = !"plain".equals(fmt) && ("always".equals(fmt) || !QueryPayload.isEmpty(extraData));
        return wrap ? QueryPayload.wrap(text, extraData) : text;
    }

    /**
     * 上传文件到 Dify（POST /v1/files/upload），返回 Dify 的文件元数据（含 id）。
     * 上传时的 user 必须与发消息的 user 一致，否则 chat-messages 会报文件不存在。
     */
    public Map<String, Object> uploadFile(byte[] bytes, String filename, String contentType) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("file", new ByteArrayResource(bytes) {
            @Override
            public String getFilename() {
                return filename;
            }
        });
        form.add("user", user());
        try {
            Map<String, Object> res = client.upload("/v1/files/upload", form);
            if (res == null) {
                throw new IllegalStateException("Dify 返回为空: /v1/files/upload");
            }
            return res;
        } catch (HttpStatusCodeException e) {
            throw new IllegalStateException(
                    "Dify 文件上传失败[" + e.getRawStatusCode() + "]: " + brief(e.getResponseBodyAsString()), e);
        } catch (RestClientException e) {
            throw failure(e);
        }
    }

    /**
     * 前端文件元数据 → Dify files 参数（写入顶层 files 字段，对应预设变量 userinput.files）。
     * type 按扩展名判定：图片 → image，其余 → document（与 Dify 文件列表变量的文档/图片类型对应）。
     *
     * <p>两种来源：
     * <ul>
     *   <li>带 {@code id}（应用侧 {@code /api/chat/files} 上传到 Dify）→ {@code transfer_method=local_file}；</li>
     *   <li>只有 {@code url}（原生容器把图片传到了门户文件服务器，H5 取不回字节）→
     *       {@code transfer_method=remote_url}，由 Dify 自行拉取。</li>
     * </ul>
     * 后者要求 Dify 服务能访问该地址（内网部署时注意）。
     */
    private List<Map<String, Object>> toDifyFiles(List<Map<String, Object>> files) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (files == null) {
            return out;
        }
        for (Map<String, Object> f : files) {
            if (f == null) {
                continue;
            }
            Object id = f.get("id");
            Object url = f.get("url");
            String name = str(f.get("name"));
            boolean hasId = id != null && !String.valueOf(id).trim().isEmpty();
            boolean hasUrl = url != null && !String.valueOf(url).trim().isEmpty();
            if (!hasId && !hasUrl) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("type", isImageName(name) ? "image" : "document");
            if (hasId) {
                item.put("transfer_method", "local_file");
                item.put("upload_file_id", String.valueOf(id));
            } else {
                item.put("transfer_method", "remote_url");
                item.put("url", String.valueOf(url).trim());
            }
            out.add(item);
        }
        return out;
    }

    /** 按扩展名判断是否图片（与 Chatflow 变量勾选的「图片」类型一致） */
    public static boolean isImageName(String name) {
        String n = name == null ? "" : name.toLowerCase();
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")
                || n.endsWith(".gif") || n.endsWith(".webp") || n.endsWith(".svg");
    }

    /**
     * 最近会话分页列表。
     *
     * <p>Dify 会话列表接口只有游标（{@code last_id}）翻页，没有「按名称检索」参数，
     * 因此这里的做法是：从最新开始按游标逐批拉取 → 在服务端按 keyword 过滤 → 截取 [offset, offset+limit) 返回。
     * 一旦「已命中条数」够本页 + 能判定是否还有下一页就停止拉取，避免无谓的全量扫描；
     * 单次最多回溯 {@code ok.assistant.dify.conversation-scan-max} 条。
     *
     * @param keyword 标题检索关键词（空 = 不检索）
     * @param offset  起始偏移（= 前端已加载条数）
     * @param limit   本页条数
     */
    public PageResult<Conversation> conversations(String keyword, int offset, int limit) {
        String kw = keyword == null ? "" : keyword.trim();
        int size = Math.max(1, limit);
        int from = Math.max(0, offset);
        int scanMax = Math.max(props.getConversationScanMax(), size);
        if (from >= scanMax) {
            // 已到达单次可回溯的最大深度：不再向下翻，避免「更多」按钮点了没反应
            return new PageResult<>(new ArrayList<>(), 0, from, size, false);
        }
        int need = from + size + 1;   // 多取 1 条用于判定「是否还有下一页」

        List<Conversation> matched = new ArrayList<>();
        int scanned = 0;
        boolean exhausted = false;   // Dify 侧已无更早的会话
        String lastId = null;

        while (!exhausted && scanned < scanMax && matched.size() < need) {
            // 不检索：精确取够即可（少拉数据）；检索：整批拉取（少一次往返）
            int batch = kw.isEmpty()
                    ? Math.min(PAGE_LIMIT, need - matched.size())
                    : Math.min(PAGE_LIMIT, scanMax - scanned);
            batch = Math.max(1, batch);

            Map<String, Object> res = conversationsRaw(lastId, batch);
            List<?> data = dataOf(res);
            if (data.isEmpty()) {
                break;
            }
            matched.addAll(mapConversations(data, kw));
            scanned += data.size();

            // has_more 由 Dify 下发；缺失时按「本批是否拉满」推断
            boolean more = res.get("has_more") instanceof Boolean
                    ? (Boolean) res.get("has_more")
                    : data.size() >= batch;
            String cursor = cursorOf(data);
            if (!more || cursor == null) {
                exhausted = true;
            } else {
                lastId = cursor;
            }
        }

        matched.sort(Comparator.comparing(Conversation::getUpdateTime).reversed());
        int start = Math.min(from, matched.size());
        int to = Math.min(from + size, matched.size());
        List<Conversation> page = new ArrayList<>(matched.subList(start, to));
        // 还有下一页：本页之后仍有命中，或还能继续向后扫描
        boolean hasMore = to < matched.size() || (!exhausted && scanned < scanMax);
        return new PageResult<>(page, matched.size(), from, size, hasMore);
    }

    /** 最近会话（内部使用：清空会话等场景；单批最多 100 条） */
    public List<Conversation> conversations(String keyword) {
        String kw = keyword == null ? "" : keyword.trim();
        return mapConversations(dataOf(conversationsRaw(null, PAGE_LIMIT)), kw);
    }

    /** 拉取一批原始会话（游标翻页的最小单元） */
    private Map<String, Object> conversationsRaw(String lastId, int batch) {
        MultiValueMap<String, String> query = new LinkedMultiValueMap<>();
        query.add("user", user());
        query.add("limit", String.valueOf(batch));
        if (lastId != null && !lastId.isEmpty()) {
            query.add("last_id", lastId);
        }
        return get("/v1/conversations", query);
    }

    private static List<?> dataOf(Map<String, Object> res) {
        return res.get("data") instanceof List ? (List<?>) res.get("data") : Collections.emptyList();
    }

    /** 批内最后一条的 id，作为下一批的游标 */
    private static String cursorOf(List<?> data) {
        for (int i = data.size() - 1; i >= 0; i--) {
            Object o = data.get(i);
            if (o instanceof Map) {
                String id = str(((Map<?, ?>) o).get("id"));
                if (!id.isEmpty()) {
                    return id;
                }
            }
        }
        return null;
    }

    /**
     * 原始会话 → 前端 Conversation，并按 keyword 过滤（keyword 为空 = 不过滤）。
     *
     * <p>会话标题取 Dify 的 {@code name}，但该字段可能是**query 原文**（Dify 自动命名会直接用首轮
     * query 前若干字符，而应用发出的 query 是 JSON 信封），因此这里统一过一次拆包
     * （{@link QueryPayload#userInput}），列表里只展示 {@code userinput}。
     * 关键词过滤同样基于拆包后的标题，避免「用 JSON 里的附加数据误命中」或「中文关键词匹配不上」。
     */
    private List<Conversation> mapConversations(List<?> data, String kw) {
        List<Conversation> list = new ArrayList<>();
        for (Object o : data) {
            if (!(o instanceof Map)) {
                continue;
            }
            Map<?, ?> c = (Map<?, ?>) o;
            String id = str(c.get("id"));
            String name = QueryPayload.userInput(str(c.get("name")));
            if (!kw.isEmpty() && !name.contains(kw)) {
                continue;
            }
            Conversation conv = new Conversation(id, name, icon(id), secToMs(c.get("created_at")));
            conv.setUpdateTime(secToMs(c.get("updated_at")));
            // 会话首轮传入的 operatetype = 该会话所属底部菜单，前端打开历史会话时据此默认选中菜单
            String op = inputsOperateType(c.get("inputs"));
            conv.setOperateType(op.isEmpty() ? null : op);
            list.add(conv);
        }
        return list;
    }

    /**
     * 会话消息历史：Dify 一条记录 = 一问一答，拆成 user + bot 两条消息。
     * 应答按 Chatflow 的 JSON 协议解析（type → 渲染模板、content → 展示文本、operatetype → 菜单归属）；
     * bot 消息 id = Dify message_id（反馈接口直接使用）。
     *
     * <p><b>历史附件来源</b>：用户消息的附件直接从该条消息的 {@code inputs.files} 读取 ——
     * 那是发消息时一并下发的文件列表（见 {@link #send}），Dify 原样持久化，
     * 回带 {@code filename / size / mime_type / type / related_id / url}。
     * 因此应用侧既不用留档「消息 ↔ 附件」映射，也不用留档文件字节。
     */
    public List<ChatMessage> messages(String conversationId) {
        MultiValueMap<String, String> query = new LinkedMultiValueMap<>();
        query.add("user", user());
        query.add("conversation_id", conversationId);
        query.add("limit", String.valueOf(PAGE_LIMIT));
        Map<String, Object> res = get("/v1/messages", query);

        List<ChatMessage> list = new ArrayList<>();
        Object data = res.get("data");
        if (data instanceof List) {
            for (Object o : (List<?>) data) {
                if (!(o instanceof Map)) {
                    continue;
                }
                Map<?, ?> m = (Map<?, ?>) o;
                String messageId = str(m.get("id"));
                long ts = secToMs(m.get("created_at"));
                Object inputs = m.get("inputs");
                String op = inputsOperateType(inputs);
                // query 可能是结构化信封（{"userinput":..,"extra_data":..}）：展示取 userinput，
                // 附加数据原样带回，使历史会话里再次点击卡片仍能带上（如统一社会信用代码）
                String rawQuery = str(m.get("query"));

                ChatMessage q = new ChatMessage(ChatMessage.FROM_USER, ChatMessage.TYPE_TEXT,
                        QueryPayload.userInput(rawQuery));
                q.setId("U" + messageId);
                q.setConversationId(conversationId);
                q.setCreateTime(ts);
                Object extra = QueryPayload.extraData(rawQuery);
                if (!QueryPayload.isEmpty(extra)) {
                    q.setExtraData(extra);
                }
                if (!op.isEmpty()) {
                    q.setOperateType(op);
                }
                List<Map<String, Object>> metas = fileMetas(inputs);
                if (!metas.isEmpty()) {
                    q.setFiles(metas);
                }
                list.add(q);

                ChatMessage a = DifyAnswerResolver.toBotMessage(str(m.get("answer")), conversationId, messageId, ts);
                if (a.getOperateType().isEmpty() && !op.isEmpty()) {
                    a.setOperateType(op);
                }
                list.add(a);
            }
        }
        list.sort(Comparator.comparing(ChatMessage::getCreateTime));
        return list;
    }

    // ---------------- 附件（文件字节与下载地址全部来自 Dify，应用侧不留任何副本） ----------------

    /**
     * 取「会话内某个文件」的原始对象，其中 {@code url} 是<b>本次重新签名</b>的下载地址
     * （Dify 每次返回历史消息都会重签，所以「取一次用一次」永远有效）。
     *
     * <p><b>每次都实时读一次会话历史，不做任何缓存</b> —— 本类因此是无状态的：
     * 集群里任意实例都能处理任意一次附件读取（upload 落在 A、下载打到 B 也照样成功），
     * 实例重启也不会丢任何东西。
     *
     * @param conversationId 会话 id（文件对象存在消息 inputs 上，必须按会话取）
     * @param fileId         Dify 文件 id（历史回带为 {@code related_id}）
     * @return 文件对象；Dify 未启用 / 会话或文件不存在返回 null
     */
    public Map<String, Object> fileObject(String conversationId, String fileId) {
        if (!props.isEnabled() || conversationId == null || conversationId.isEmpty()
                || fileId == null || fileId.isEmpty()) {
            return null;
        }
        Map<String, Map<String, Object>> byId = new LinkedHashMap<>();
        try {
            MultiValueMap<String, String> query = new LinkedMultiValueMap<>();
            query.add("user", user());
            query.add("conversation_id", conversationId);
            query.add("limit", String.valueOf(PAGE_LIMIT));
            for (Object o : dataOf(get("/v1/messages", query))) {
                if (o instanceof Map) {
                    collectFiles(byId, ((Map<?, ?>) o).get("inputs"));
                }
            }
        } catch (Exception e) {
            log.warn("读取会话文件列表失败（附件可能暂时不可用）: {} - {}", conversationId, e.getMessage());
            return null;
        }
        return byId.get(fileId);
    }

    /** 把一条消息 inputs 里的文件对象收进映射（键 = 文件 id） */
    private void collectFiles(Map<String, Map<String, Object>> out, Object inputs) {
        for (Map<String, Object> f : filesOfInputs(inputs)) {
            String id = fileIdOf(f);
            if (!id.isEmpty()) {
                out.put(id, f);
            }
        }
    }

    /** inputs 里的文件列表变量 → 前端附件元数据（{id, name, size, kind}） */
    private List<Map<String, Object>> fileMetas(Object inputs) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> f : filesOfInputs(inputs)) {
            String id = fileIdOf(f);
            if (id.isEmpty()) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", id);
            item.put("name", str(f.get("filename")));
            item.put("size", f.get("size") instanceof Number ? ((Number) f.get("size")).longValue() : 0L);
            item.put("kind", isImageFile(f) ? "image" : "document");
            out.add(item);
        }
        return out;
    }

    /** 取 inputs 里的文件列表变量（默认为开始节点的文件变量名，如 files） */
    private List<Map<String, Object>> filesOfInputs(Object inputs) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (!(inputs instanceof Map)) {
            return out;
        }
        Object v = ((Map<?, ?>) inputs).get(filesVariable());
        if (!(v instanceof List)) {
            return out;
        }
        for (Object o : (List<?>) v) {
            if (o instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> f = (Map<String, Object>) o;
                out.add(f);
            }
        }
        return out;
    }

    /** 承载文件列表的 inputs 变量名：未配置时按 Chatflow 开始节点的默认文件名 files 解析 */
    private String filesVariable() {
        String v = props.getInputFiles() == null ? "" : props.getInputFiles().trim();
        return v.isEmpty() ? "files" : v;
    }

    /** 文件 id：历史回带放在 related_id，直接上传响应里是 id */
    private static String fileIdOf(Map<String, Object> f) {
        String id = str(f.get("related_id"));
        return id.isEmpty() ? str(f.get("id")) : id;
    }

    private static boolean isImageFile(Map<String, Object> f) {
        return "image".equals(str(f.get("type"))) || str(f.get("mime_type")).startsWith("image/");
    }

    /** 删除单个会话 */
    public void delete(String conversationId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("user", user());
        deleteInternal("/v1/conversations/" + conversationId, body);
    }

    /** 清空全部会话（Dify 无批量删除，按页循环逐个删除） */
    public void clearAll() {
        for (int page = 0; page < 50; page++) {
            List<Conversation> batch = conversations(null);
            if (batch.isEmpty()) {
                return;
            }
            for (Conversation c : batch) {
                try {
                    delete(c.getId());
                } catch (Exception e) {
                    log.warn("Dify 会话删除失败（跳过）: {} - {}", c.getId(), e.getMessage());
                }
            }
        }
    }

    /** 点赞/点踩（rating: like / dislike，与前端一致透传） */
    public void feedback(String messageId, String type) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("rating", type);
        body.put("user", user());
        post("/v1/messages/" + messageId + "/feedbacks", body);
    }

    /** 新会话按首条消息设置标题（Dify 自动命名有延迟，主动改名；失败不影响主流程） */
    public void rename(String conversationId, String title) {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("name", title);
            post("/v1/conversations/" + conversationId + "/name", body);
        } catch (Exception e) {
            log.warn("Dify 会话重命名失败（忽略）: {}", e.getMessage());
        }
    }

    // ---------------- 内部工具 ----------------

    private Map<String, Object> post(String path, Map<String, Object> body) {
        try {
            Map<String, Object> res = client.post(path, body);
            if (res == null) {
                throw new IllegalStateException("Dify 返回为空: " + path);
            }
            return res;
        } catch (HttpStatusCodeException e) {
            throw new IllegalStateException(
                    "Dify 调用失败[" + e.getRawStatusCode() + "]: " + brief(e.getResponseBodyAsString()), e);
        } catch (RestClientException e) {
            throw failure(e);
        }
    }

    private Map<String, Object> get(String path, MultiValueMap<String, String> query) {
        try {
            Map<String, Object> res = client.get(path, query);
            if (res == null) {
                throw new IllegalStateException("Dify 返回为空: " + path);
            }
            return res;
        } catch (HttpStatusCodeException e) {
            throw new IllegalStateException(
                    "Dify 调用失败[" + e.getRawStatusCode() + "]: " + brief(e.getResponseBodyAsString()), e);
        } catch (RestClientException e) {
            throw failure(e);
        }
    }

    private void deleteInternal(String path, Map<String, Object> body) {
        try {
            client.delete(path, body);
        } catch (HttpStatusCodeException e) {
            throw new IllegalStateException(
                    "Dify 调用失败[" + e.getRawStatusCode() + "]: " + brief(e.getResponseBodyAsString()), e);
        } catch (RestClientException e) {
            throw failure(e);
        }
    }

    private static String rootMessage(Throwable e) {
        Throwable t = e;
        while (t.getCause() != null && t.getCause() != t) {
            t = t.getCause();
        }
        return t.getMessage() == null ? e.getClass().getSimpleName() : t.getMessage();
    }

    /**
     * 把「连不上」和「等太久」区分开。
     *
     * <p>两者在 RestTemplate 里都是 {@link RestClientException}，但用户看到的提示完全不同：
     * 超时要说明已经等了多久、可以怎么处理；连不上只需要提示稍后重试。
     */
    private IllegalStateException failure(RestClientException e) {
        if (isTimeout(e)) {
            return new IllegalStateException("AI 服务响应超时（已等待 " + humanTimeout()
                    + "）。问题可能比较复杂，请稍后重试，或把它拆成几步分别提问。", e);
        }
        return new IllegalStateException("无法连接 AI 服务（" + props.getBaseUrl() + "）："
                + rootMessage(e) + "。请稍后重试。", e);
    }

    /** 是否为读超时（socket / connection 超时），逐个 cause 向下找 */
    private static boolean isTimeout(Throwable e) {
        Throwable t = e;
        for (int depth = 0; t != null && depth < 10; depth++) {
            // HttpTimeoutException 是 Java 11+ 的类，镜像是 Java 8 —— 用类名判断，避免 NoClassDefFoundError
            if (t instanceof java.net.SocketTimeoutException
                    || t.getClass().getName().endsWith("TimeoutException")) {
                return true;
            }
            String m = t.getMessage();
            if (m != null && (m.contains("timed out") || m.contains("Timeout") || m.contains("超时"))) {
                return true;
            }
            if (t.getCause() == t) {
                break;
            }
            t = t.getCause();
        }
        return false;
    }

    /** 超时秒数 → 人话（180000 → 3 分钟，95000 → 95 秒） */
    private String humanTimeout() {
        long sec = Math.max(1, props.getTimeoutMs() / 1000);
        return sec % 60 == 0 ? (sec / 60) + " 分钟" : sec + " 秒";
    }

    private static String brief(String body) {
        if (body == null) {
            return "";
        }
        return body.length() > 200 ? body.substring(0, 200) : body;
    }

    /** Dify 时间为秒级时间戳 → 毫秒 */
    private static long secToMs(Object v) {
        if (v instanceof Number) {
            return ((Number) v).longValue() * 1000L;
        }
        return System.currentTimeMillis();
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    /** 从 Dify 返回的 inputs 中取出「底部菜单」参数（会话与消息都会记录传入的 inputs） */
    private String inputsOperateType(Object inputs) {
        if (inputs instanceof Map) {
            Object v = ((Map<?, ?>) inputs).get(props.getInputOperateType());
            return v == null ? "" : String.valueOf(v);
        }
        return "";
    }

    private static String icon(String id) {
        String[] icons = {Conversation.ICON_BLUE, Conversation.ICON_YELLOW, Conversation.ICON_GREEN};
        return icons[Math.abs(id.hashCode()) % icons.length];
    }
}
