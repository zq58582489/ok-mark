package com.ok.chat.store;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 业务知识问答（原型：固定资产贷款怎么做）
 */
public final class KnowledgeQA {

    private KnowledgeQA() {
    }

    public static KnowledgeQA fixAssetLoan() {
        return new KnowledgeQA();
    }

    public String getIntro() {
        return "针对您的问题我将从①定义、②准入条件、③适用范围、④营销话术这几块给您介绍";
    }

    public List<Map<String, Object>> getSections() {
        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(sec("1. 固定资产贷款的定义",
                "固定资产贷款是向企（事）业法人发放的，用于新建、扩建、改造、购置固定资产投资项目 的本外币贷款"));
        sections.add(sec("2. 准入条件",
                "固定资产贷款的准入条件固定资产贷款的准入条件固定资产贷款的准入条件"));
        sections.add(sec("3. 适用范围", null));
        sections.add(sec("4. 营销话术", null));
        return sections;
    }

    public List<String> getScopeItems() {
        List<String> items = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            items.add("（" + i + "）业务适用的范围" + i);
        }
        return items;
    }

    public List<Map<String, Object>> getScriptItems() {
        List<Map<String, Object>> scripts = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("title", (i <= 4 ? "(" + i + ")、" : i + ")、") + "营销话术场景" + (i <= 4 ? i : (i == 5 ? 3 : 4)));
            s.put("body", "营销话术营销话术营销话术营销话术营销话术");
            scripts.add(s);
        }
        return scripts;
    }

    /**
     * 分段图文小节：标题右侧带「全部 &gt;」详情链接。
     * linkText 为链接文案（前端不传则不渲染）；linkQuery 为点击后回传的文本（缺省取标题）。
     */
    private Map<String, Object> sec(String title, String body) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        m.put("body", body);
        m.put("linkText", "全部");
        m.put("linkQuery", title);
        return m;
    }
}
