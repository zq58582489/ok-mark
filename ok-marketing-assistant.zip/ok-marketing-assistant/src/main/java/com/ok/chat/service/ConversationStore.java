package com.ok.chat.service;

import com.ok.common.ChatMessage;
import com.ok.common.Conversation;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 会话与消息存储（内存实现，可替换为 DB）
 */
@Service
public class ConversationStore {

    private final Map<String, Conversation> conversations = new ConcurrentHashMap<>();
    private final Map<String, List<ChatMessage>> messages = new ConcurrentHashMap<>();

    public Conversation create(String title) {
        long now = System.currentTimeMillis();
        String id = "C" + now + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        Conversation c = new Conversation(id, title, pickIcon(), now);
        conversations.put(id, c);
        messages.put(id, new ArrayList<>());
        return c;
    }

    private String pickIcon() {
        String[] icons = {Conversation.ICON_BLUE, Conversation.ICON_YELLOW, Conversation.ICON_GREEN,
                Conversation.ICON_BLUE, Conversation.ICON_BLUE};
        return icons[(int) (Math.random() * icons.length)];
    }

    public List<Conversation> list() {
        return list(null);
    }

    /** 按标题检索（keyword 为空 = 全量），按更新时间倒序 */
    public List<Conversation> list(String keyword) {
        String kw = keyword == null ? "" : keyword.trim();
        List<Conversation> list = new ArrayList<>();
        for (Conversation c : conversations.values()) {
            if (kw.isEmpty() || (c.getTitle() != null && c.getTitle().contains(kw))) {
                list.add(c);
            }
        }
        list.sort(Comparator.comparing(Conversation::getUpdateTime).reversed());
        return list;
    }

    public Conversation get(String id) {
        return conversations.get(id);
    }

    public void delete(String id) {
        conversations.remove(id);
        messages.remove(id);
    }

    public void clearAll() {
        conversations.clear();
        messages.clear();
    }

    public void touch(String id, String newTitle) {
        Conversation c = conversations.get(id);
        if (c != null) {
            c.setUpdateTime(System.currentTimeMillis());
            if (newTitle != null && !newTitle.trim().isEmpty()) {
                c.setTitle(newTitle.trim());
            }
        }
    }

    public List<ChatMessage> messageList(String conversationId) {
        return messages.getOrDefault(conversationId, new ArrayList<>());
    }

    public void append(ChatMessage msg) {
        messages.computeIfAbsent(msg.getConversationId(), k -> new ArrayList<>()).add(msg);
    }
}
