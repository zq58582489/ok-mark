package com.ok.web.asset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 静态资源版本号计算：取 classpath:/static 下资源内容的 MD5 前 8 位。
 *
 * <p>用内容哈希而不是时间戳：同一份内容在任何机器、任何次启动得到的版本都一样，
 * 有利于缓存命中；只有文件真的改了版本才会变。
 *
 * <p>结果按「最后修改时间」缓存：同一进程内重复取不重复算哈希；
 * 用 IDE 直接跑（classpath 指向 target/classes）时改了文件也能自动重算，无需重启。
 *
 * <p>另有 {@link #fingerprint()}：全部 js/css 的合并指纹，用于给「前端运行时拼接」的
 * 资源地址（如 {@code 'assets/' + it.icon + '@2x.png'}）兜底加版本——这类地址服务端无法逐个展开。
 */
@Component
public class AssetVersionResolver {

    private static final Logger log = LoggerFactory.getLogger(AssetVersionResolver.class);

    /** 静态资源根（classpath 下） */
    private static final String STATIC_ROOT = "static/";

    /** 参与全局指纹的 js/css（用内容哈希，目录通配，新增文件无需改代码） */
    private static final String[] CONTENT_PATTERNS = {"classpath:static/js/*.js", "classpath:static/css/*.css"};

    /** 参与全局指纹的图片等资源（只用「名字+大小+修改时间」，避免为了算指纹把大图全读一遍） */
    private static final String[] META_PATTERNS = {"classpath:static/assets/*"};

    /** path → 版本（含计算时的最后修改时间，用于失效判断） */
    private final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();

    private volatile String fingerprint;

    /** 取某个静态资源的版本号；资源不存在返回 null（调用方原样输出地址） */
    public String versionOf(String path) {
        if (path == null || path.isEmpty()) {
            return null;
        }
        String p = normalize(path);
        if (p.isEmpty()) {
            return null;
        }
        try {
            Resource resource = new ClassPathResource(STATIC_ROOT + p);
            if (!resource.exists()) {
                cache.remove(p);
                return null;
            }
            long lastModified = resource.lastModified();
            CacheEntry entry = cache.get(p);
            if (entry != null && entry.lastModified == lastModified) {
                return entry.version;
            }
            String version = hash(resource);
            if (version == null) {
                return null;
            }
            cache.put(p, new CacheEntry(lastModified, version));
            return version;
        } catch (Exception ex) {
            log.debug("计算静态资源版本失败: {}（{}）", p, ex.getMessage());
            return null;
        }
    }

    /**
     * 全局静态资源指纹：js/css 的内容哈希 + assets 图片的名字/大小/修改时间，合并后取 8 位。
     *
     * <p>用途是给「前端运行时拼接」的资源地址兜底（{@code 'assets/' + it.icon + '@2x.png'}）——
     * 这类地址服务端无法逐个展开，只能共用一个版本号。为了「只换了一张图、前端 js 没动」
     * 也能刷新，图片的元信息（大小 + 修改时间）同样纳入指纹。
     */
    public String fingerprint() {
        String f = fingerprint;
        if (f != null) {
            return f;
        }
        synchronized (this) {
            if (fingerprint != null) {
                return fingerprint;
            }
            List<String> inputs = fingerprintInputs();
            String joined = String.join(";", inputs);
            fingerprint = md5(joined.getBytes(StandardCharsets.UTF_8)).substring(0, 8);
            log.info("静态资源指纹: {}（参与计算 {} 项，js/css 按内容、图片按元信息）", fingerprint, inputs.size());
            log.debug("指纹输入: {}", inputs);
            return fingerprint;
        }
    }

    /** 指纹输入项（路径排序，保证同内容得到同指纹） */
    private List<String> fingerprintInputs() {
        List<String> parts = new ArrayList<>();
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        for (String pattern : CONTENT_PATTERNS) {
            String dir = pattern.contains("/js/") ? "js/" : "css/";
            for (Resource resource : resources(resolver, pattern)) {
                String name = resource.getFilename();
                if (name != null && !name.isEmpty()) {
                    parts.add(dir + name + "=" + versionOf(dir + name));
                }
            }
        }
        for (String pattern : META_PATTERNS) {
            for (Resource resource : resources(resolver, pattern)) {
                String name = resource.getFilename();
                if (name == null || name.isEmpty()) {
                    continue;
                }
                try {
                    parts.add("assets/" + name + ":" + resource.contentLength() + ":" + resource.lastModified());
                } catch (IOException ex) {
                    parts.add("assets/" + name + ":?");
                }
            }
        }
        Collections.sort(parts);
        return parts;
    }

    private Resource[] resources(PathMatchingResourcePatternResolver resolver, String pattern) {
        try {
            return resolver.getResources(pattern);
        } catch (IOException ex) {
            log.warn("扫描静态资源失败: {}（{}）", pattern, ex.getMessage());
            return new Resource[0];
        }
    }

    /** 去掉查询串 / 锚点 / 前导 "./"、"~/" */
    private String normalize(String path) {
        String p = path.trim();
        int cut = indexOfAny(p, '?', '#');
        if (cut >= 0) {
            p = p.substring(0, cut);
        }
        while (p.startsWith("./") || p.startsWith("~/")) {
            p = p.substring(2);
        }
        while (p.startsWith("/")) {
            p = p.substring(1);
        }
        return p;
    }

    private int indexOfAny(String s, char a, char b) {
        int i = s.indexOf(a);
        int j = s.indexOf(b);
        if (i < 0) {
            return j;
        }
        return j < 0 ? i : Math.min(i, j);
    }

    private String hash(Resource resource) {
        try (InputStream in = resource.getInputStream()) {
            return md5(StreamUtils.copyToByteArray(in)).substring(0, 8);
        } catch (IOException ex) {
            log.debug("读取静态资源失败: {}（{}）", resource, ex.getMessage());
            return null;
        }
    }

    private String md5(byte[] bytes) {
        return DigestUtils.md5DigestAsHex(bytes);
    }

    /** 版本缓存项 */
    private static final class CacheEntry {

        private final long lastModified;

        private final String version;

        CacheEntry(long lastModified, String version) {
            this.lastModified = lastModified;
            this.version = version;
        }
    }
}
