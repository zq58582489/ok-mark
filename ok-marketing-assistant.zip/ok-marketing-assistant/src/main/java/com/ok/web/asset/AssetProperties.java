package com.ok.web.asset;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 静态资源缓存配置（application.yml: ok.web.assets.*，全部可配置）
 *
 * <p>前端是无构建的 Vue2 静态页（js/css/图片直接引用），浏览器与中间代理会缓存旧文件，
 * 导致「改了前端但页面还是老样子」。这里由 {@link AssetVersionFilter} 在返回 index.html 时
 * 给引用的静态资源统一追加内容哈希版本参数（{@code js/app.js?v=1a2b3c4d}），
 * 从而：文件内容不变 → 版本不变（继续用缓存）；文件内容变了 → 版本变（强制拉新）。
 *
 * <p>可调项：
 * <ul>
 *     <li>{@code enabled=false}：整体关闭（排查缓存问题时用）</li>
 *     <li>{@code max-age-seconds=0}：静态资源不加长缓存头，仅保留版本参数</li>
 *     <li>{@code param}：版本参数名，默认 {@code v}（如需与网关既有约定一致可改）</li>
 * </ul>
 */
@Component
@ConfigurationProperties(prefix = "ok.web.assets")
public class AssetProperties {

    /** 是否开启静态资源版本注入与缓存头（关闭后行为与改造前完全一致） */
    private boolean enabled = true;

    /** 版本参数名（附加在资源地址后的查询参数） */
    private String param = "v";

    /** HTML 入口的 Cache-Control：必须协商缓存，否则版本参数本身会被缓存住 */
    private String htmlCacheControl = "no-cache, must-revalidate";

    /** 带版本参数的静态资源强缓存秒数（默认 1 年）；0 = 不加缓存头 */
    private long maxAgeSeconds = 31536000L;

    /** 是否附加 immutable（内容哈希地址不会变，浏览器可跳过校验） */
    private boolean immutable = true;

    /**
     * 需要加版本参数的资源类型（按扩展名判定）。
     * 图片一并纳入：改图后同样能立刻生效（动态拼接的图片走 {@code okAsset()} 兜底）。
     */
    private List<String> extensions = new ArrayList<>(Arrays.asList(
            "js", "css", "json",
            "png", "jpg", "jpeg", "gif", "webp", "svg", "ico",
            "woff", "woff2", "ttf", "eot"));

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public String getHtmlCacheControl() {
        return htmlCacheControl;
    }

    public void setHtmlCacheControl(String htmlCacheControl) {
        this.htmlCacheControl = htmlCacheControl;
    }

    public long getMaxAgeSeconds() {
        return maxAgeSeconds;
    }

    public void setMaxAgeSeconds(long maxAgeSeconds) {
        this.maxAgeSeconds = maxAgeSeconds;
    }

    public boolean isImmutable() {
        return immutable;
    }

    public void setImmutable(boolean immutable) {
        this.immutable = immutable;
    }

    public List<String> getExtensions() {
        return extensions;
    }

    public void setExtensions(List<String> extensions) {
        this.extensions = extensions;
    }
}
