package com.ok.web;

import com.ok.auth.AuthException;
import com.ok.common.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理（单体应用统一入口）
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 鉴权异常：统一 401（令牌缺失/无效/过期）与 403（无权限），
     * 与 {@code AuthInterceptor} 写出的响应结构保持一致，便于前端统一处理。
     */
    @ExceptionHandler(AuthException.class)
    public ResponseEntity<ApiResponse<Void>> handleAuth(AuthException e) {
        HttpStatus status = e.getCode() == 403 ? HttpStatus.FORBIDDEN : HttpStatus.UNAUTHORIZED;
        log.debug("鉴权异常: {}", e.getMessage());
        return ResponseEntity.status(status).body(new ApiResponse<>(e.getCode(), e.getMessage(), null));
    }

    @ExceptionHandler(Exception.class)
    public ApiResponse<Void> handle(Exception e) {
        log.error("接口处理异常", e);
        return ApiResponse.error(e.getMessage() == null ? "服务异常，请稍后再试" : e.getMessage());
    }
}
