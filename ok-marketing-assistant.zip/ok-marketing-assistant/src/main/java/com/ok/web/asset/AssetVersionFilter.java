package com.ok.web.asset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.DispatcherType;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 静态资源「动态版本参数」注入 —— 解决前端改了但浏览器/CDN 拿旧缓存的问题。
 *
 * <p>做法：返回 HTML 入口（{@code /} 与 {@code /index.html}）时把响应体读出来，
 * 给其中引用的本地静态资源统一追加内容哈希参数，并在 {@code </head>} 前注入全局版本号：
 * <pre>
 * 改造前： &lt;script src="js/app.js"&gt;&lt;/script&gt;          &lt;link href="css/app.css"&gt;
 * 改造后： &lt;script src="js/app.js?v=1a2b3c4d"&gt;&lt;/script&gt; &lt;link href="css/app.css?v=9f8e7d6c"&gt;
 *          &lt;script&gt;window.OK_ASSET_VERSION='7c1d...'&lt;/script&gt;
 * </pre>
 *
 * <p>配套的缓存头（HTML 与静态资源分开）：
 * <ul>
 *     <li>HTML 入口：{@code no-cache} + 「重写后内容」的强 ETag —— 每次都会校验，未改则 304（几十字节），
 *         改了则立刻拿到新 HTML（从而拿到新的资源版本号）；</li>
 *     <li>带版本参数的静态资源：{@code max-age=31536000, immutable} —— 地址随内容变，可放心长缓存。</li>
 * </ul>
 *
 * <p>注意：模板里用表达式动态拼出来的地址（如 Vue 的 {@code :src="'assets/'+it.icon+'@2x.png'"}）
 * 服务端无法逐个展开，这类地址由注入的 {@code window.OK_ASSET_VERSION} + 前端 {@code okAsset()} 兜底。
 *
 * <p>关闭方式：{@code ok.web.assets.enabled=false}（行为退回改造前）。
 */
@Component
@Order(AssetVersionFilter.ORDER)
public class AssetVersionFilter extends OncePerRequestFilter {

    /** 要在 CharacterEncodingFilter 之后执行（响应已确定编码），又要在业务之前包住响应 */
    static final int ORDER = 0;

    private static final Logger log = LoggerFactory.getLogger(AssetVersionFilter.class);

    /** HTML 入口路径（上下文根按需拼接；/ 会 forward 到 /index.html，forward 不再经过本过滤器） */
    private static final String[] HTML_ENTRIES = {"/", "/index.html", "/index.htm"};

    /** 属性引用：src="..." / href="..."（带前导空白，避免误伤 :src / v-bind:src 等动态绑定） */
    private static final Pattern REF_PATTERN = Pattern.compile(
            "(?i)(\\s(?:src|href)\\s*=\\s*)([\"'])([^\"'<>\\r\\n]{1,400})\\2");

    /** head 结束标签（注入全局版本号的位置） */
    private static final Pattern HEAD_END_PATTERN = Pattern.compile("(?i)</head\\s*>");

    private final AssetProperties props;

    private final AssetVersionResolver resolver;

    public AssetVersionFilter(AssetProperties props, AssetVersionResolver resolver) {
        this.props = props;
        this.resolver = resolver;
    }

    /** 只放行 GET/HEAD 的普通请求，其余（含 forward 进来的 /index.html）一律跳过 */
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        if (!props.isEnabled()) {
            return true;
        }
        if (!"GET".equals(request.getMethod()) && !"HEAD".equals(request.getMethod())) {
            return true;
        }
        return request.getDispatcherType() != DispatcherType.REQUEST;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String uri = path(request);

        // 1) 带版本参数的静态资源：可放心长缓存（地址随内容变化，内容不变则命不变）
        if (props.getMaxAgeSeconds() > 0 && isAssetPath(uri) && request.getParameter(props.getParam()) != null) {
            StringBuilder cc = new StringBuilder("public, max-age=").append(props.getMaxAgeSeconds());
            if (props.isImmutable()) {
                cc.append(", immutable");
            }
            response.setHeader("Cache-Control", cc.toString());
            chain.doFilter(request, response);
            return;
        }

        // 2) 其它请求：非 HTML 入口直接放行
        if (!isHtmlEntry(uri)) {
            chain.doFilter(request, response);
            return;
        }

        // 3) HTML 入口：协商缓存 + 重写资源引用（带上内容哈希版本参数）
        if (props.getHtmlCacheControl() != null && !props.getHtmlCacheControl().isEmpty()) {
            response.setHeader("Cache-Control", props.getHtmlCacheControl());
        }
        ContentCachingResponseWrapper wrapper = new ContentCachingResponseWrapper(response);
        chain.doFilter(request, wrapper);

        byte[] body = wrapper.getContentAsByteArray();
        if (body.length == 0 || wrapper.getStatus() != HttpServletResponse.SC_OK) {
            // 304 / 302 / 404 等：原样回写，不做重写
            wrapper.copyBodyToResponse();
            return;
        }

        Charset charset = charsetOf(wrapper.getContentType());
        String html = new String(body, charset);
        String rewritten = rewrite(html);
        byte[] bytes = rewritten.getBytes(charset);

        // 重写后的内容才是真实响应体，用它的哈希做 ETag（否则会拿旧 HTML 复用缓存的旧版本号）
        String etag = "\"" + DigestUtils.md5DigestAsHex(bytes) + "\"";
        String ifNoneMatch = request.getHeader("If-None-Match");
        if (etag.equals(ifNoneMatch)) {
            response.reset();
            response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
            if (props.getHtmlCacheControl() != null && !props.getHtmlCacheControl().isEmpty()) {
                response.setHeader("Cache-Control", props.getHtmlCacheControl());
            }
            response.setHeader("ETag", etag);
            response.setContentLength(0);
            return;
        }

        response.setHeader("ETag", etag);
        response.setContentLength(bytes.length);
        response.getOutputStream().write(bytes);
        response.flushBuffer();
    }

    /** 给 HTML 里引用的本地静态资源加版本参数，并注入全局版本号 */
    private String rewrite(String html) {
        Matcher matcher = REF_PATTERN.matcher(html);
        StringBuffer sb = new StringBuffer(html.length() + 512);
        int hit = 0;
        while (matcher.find()) {
            String prefix = matcher.group(1);
            String quote = matcher.group(2);
            String url = matcher.group(3);
            String versioned = versioned(url);
            // null = 不是本站静态资源 / 取不到版本号 → 原样保留
            String replacement = versioned == null ? matcher.group(0) : prefix + quote + versioned + quote;
            if (versioned != null) {
                hit++;
            }
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);

        String out = sb.toString();
        String script = versionScript();
        Matcher headEnd = HEAD_END_PATTERN.matcher(out);
        if (headEnd.find()) {
            int at = headEnd.start();
            out = out.substring(0, at) + script + out.substring(at);
        }
        log.debug("静态资源版本注入：命中 {} 处", hit);
        return out;
    }

    /**
     * 给单个地址加版本参数。
     *
     * @return 加了版本参数的地址；null 表示「不是本地静态资源，原样保留」
     */
    private String versioned(String url) {
        if (url == null || url.isEmpty() || !isLikelyLocal(url)) {
            return null;
        }
        String version = resolver.versionOf(url);
        if (version == null) {
            return null;
        }
        char sep = url.indexOf('?') >= 0 ? '&' : '?';
        return url + sep + props.getParam() + "=" + version;
    }

    /** 是否可能是本站静态资源：排除外部地址、行内协议、锚点、以及模板表达式拼接出来的地址 */
    private boolean isLikelyLocal(String url) {
        String u = url.trim();
        if (u.isEmpty()) {
            return false;
        }
        String lower = u.toLowerCase();
        if (lower.startsWith("#") || lower.startsWith("/api/") || lower.startsWith("api/")) {
            return false;
        }
        // 外部地址 / 行内协议
        if (u.startsWith("//") || lower.contains("://") || lower.startsWith("data:")
                || lower.startsWith("blob:") || lower.startsWith("mailto:") || lower.startsWith("javascript:")) {
            return false;
        }
        // 模板表达式（Vue/JS 拼接）：'assets/' + it.icon + '@2x.png'、{{ }} 等，服务端无法展开
        if (u.indexOf('\'') >= 0 || u.indexOf('"') >= 0 || u.indexOf('+') >= 0
                || u.indexOf('{') >= 0 || u.indexOf('(') >= 0 || u.indexOf(' ') >= 0) {
            return false;
        }
        // 已带版本参数：幂等处理，不重复追加
        if (u.contains(props.getParam() + "=")) {
            return false;
        }
        // 其它查询参数（如下载接口的 ?id=x）：不确定含义，不动
        if (u.indexOf('?') >= 0) {
            return false;
        }
        String ext = extension(u);
        return ext != null && props.getExtensions().contains(ext);
    }

    /** 取小写扩展名（无扩展名返回 null） */
    private String extension(String url) {
        int slash = url.lastIndexOf('/');
        int dot = url.lastIndexOf('.');
        if (dot <= slash || dot == url.length() - 1) {
            return null;
        }
        return url.substring(dot + 1).toLowerCase();
    }

    /** 注入全局版本号与 okAsset()：给前端运行时拼接的静态资源地址兜底加版本参数 */
    private String versionScript() {
        String fp = resolver.fingerprint();
        return "\n<!-- 静态资源版本：服务端按内容哈希生成（AssetVersionFilter），okAsset() 供 js 动态拼接的地址使用 -->\n"
                + "<script>window.OK_ASSET_VERSION=" + jsString(fp) + ";"
                + "window.okAsset=function(u){if(!u)return u;var s=String(u);"
                + "if(/^(https?:)?\\/\\//.test(s)||s.indexOf('data:')===0||s.indexOf('blob:')===0)return s;"
                + "if(s.indexOf('" + props.getParam() + "=')>-1)return s;"
                + "if(s.indexOf('?')>-1||s.indexOf('#')>-1)return s;"
                + "return s+'?" + props.getParam() + "='+window.OK_ASSET_VERSION;};</script>\n";
    }

    /** Java 字符串 → JS 字面量（这里只会用到 ASCII 路径与十六进制哈希） */
    private String jsString(String s) {
        if (s == null) {
            return "''";
        }
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    /** 响应体字符集（取不到时按 UTF-8） */
    private Charset charsetOf(String contentType) {
        if (contentType != null) {
            String lower = contentType.toLowerCase();
            int at = lower.indexOf("charset=");
            if (at >= 0) {
                String name = contentType.substring(at + "charset=".length()).trim();
                int end = name.indexOf(';');
                if (end >= 0) {
                    name = name.substring(0, end).trim();
                }
                try {
                    return Charset.forName(name);
                } catch (Exception ignored) {
                    // 落到默认
                }
            }
        }
        return StandardCharsets.UTF_8;
    }

    /** 是否 HTML 入口页面 */
    private boolean isHtmlEntry(String uri) {
        for (String entry : HTML_ENTRIES) {
            if (entry.equals(uri)) {
                return true;
            }
        }
        return false;
    }

    /** 当前请求路径（去掉上下文根） */
    private String path(HttpServletRequest request) {
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        if (contextPath != null && !contextPath.isEmpty() && uri.startsWith(contextPath)) {
            uri = uri.substring(contextPath.length());
        }
        return uri;
    }

    /** 是否静态资源路径（js/css/图片等，用于判断能否加长缓存） */
    private boolean isAssetPath(String uri) {
        String lower = uri.toLowerCase();
        return lower.startsWith("/js/") || lower.startsWith("/css/") || lower.startsWith("/assets/")
                || lower.endsWith(".js") || lower.endsWith(".css") || lower.endsWith(".json");
    }
}
