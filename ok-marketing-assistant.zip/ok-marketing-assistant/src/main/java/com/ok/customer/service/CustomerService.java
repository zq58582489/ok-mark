package com.ok.customer.service;

import com.ok.customer.store.MockStore;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 企业检索 / 画像 / 商机 / 话术 数据服务（还原原型数据）
 */
@Service
public class CustomerService {

    /** analysis 分段图文：小节标题右侧「全部 >」详情链接的文案 */
    private static final String SECTION_LINK_TEXT = "全部";

    /** 关键词检索企业（原型：帮我搜索国泰 -> 匹配10条，展示5条） */
    public Map<String, Object> search(String keyword, int limit) {
        List<Map<String, Object>> all = MockStore.companies();
        List<Map<String, Object>> hit = new ArrayList<>();
        for (Map<String, Object> c : all) {
            if (keyword == null || keyword.trim().isEmpty() || String.valueOf(c.get("name")).contains(keyword.trim())) {
                hit.add(c);
            }
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("total", hit.size());
        int lim = limit > 0 ? limit : 5;
        List<Map<String, Object>> page = hit.subList(0, Math.min(lim, hit.size()));
        for (int i = 0; i < page.size(); i++) {
            page.get(i).put("index", i + 1);
        }
        result.put("list", page);
        result.put("more", hit.size() > lim);
        return result;
    }

    /** 企业四段分析（1.行业类型 2.业务信息 3.商机线索 4.营销话术） */
    public Map<String, Object> analysis(String company) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);

        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(secLinked("1. 行业类型",
                "江苏国泰是**\"供应链服务 + 化工新能源\" 双主业**模式"));
        sections.add(secLinked("2. 业务信息",
                "江苏国泰是我行的存量客户，业务已经有对应的客户经理在维护"));

        List<Map<String, Object>> opps = MockStore.opportunities(company);
        m.put("opportunityTotal", opps.size());
        m.put("opportunities", names(opps));

        sections.add(secLinked("3. 商机线索", null));

        List<Map<String, Object>> scripts = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("title", (i <= 4 ? "(" + i + ")、" : i + ")、") + "营销话术场景" + (i <= 4 ? i : (i == 5 ? 3 : 4)));
            s.put("body", "营销话术营销话术营销话术营销话术营销话术");
            scripts.add(s);
        }
        sections.add(secLinked("4. 营销话术", null));
        m.put("scriptItems", scripts);
        m.put("sections", sections);
        return m;
    }

    /** 行业画像卡 */
    public Map<String, Object> industryProfile(String company) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);
        m.put("cardTitle", "江苏国泰集团");
        m.put("lights", 2); // 5盏灯，前2盏点亮
        m.put("industry", "服务行业");
        m.put("industryDesc", "江苏国泰是**\"供应链服务 + 化工新能源\" 双主业**模式");
        m.put("honors", new String[]{"专精特新“小巨人“", "高新技术企业", "省级名优企业", "绿色工厂认证", "优秀企业"});

        List<Map<String, Object>> features = new ArrayList<>();
        features.add(feature("产业链位置", "新能源汽车产业链上游.核心零部件供应"));
        features.add(feature("所属产业集群", "长三角新能源汽车零部件产业集群"));
        features.add(feature("区域产业带", "江苏张家港. 动力电池产业带"));
        features.add(feature("行业景气度", "新能晕啊行业景气上行. 扩产预期明显"));
        m.put("features", features);
        return m;
    }

    /** 业务画像卡 */
    public Map<String, Object> businessProfile(String company) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);
        m.put("cardTitle", "江苏国泰集团");
        m.put("lights", 2);
        m.put("openBranch", "总行营业厅");
        m.put("years", "5年以上");
        m.put("capital", "200-500万");
        m.put("tags", new String[]{"合作客户", "风险五级客户", "标签"});

        // 我行持有情况
        List<Map<String, Object>> holdings = new ArrayList<>();
        holdings.add(holding("存款余额", "88,888.88", "存款日均", "8888.88",
                "最近有一笔 600,000.00存款 2026.9.30 到期"));
        holdings.add(holding("贷款余额", "88,888.88", "贷款日均", "8888.88", null));
        holdings.add(holding("理财", "88,888.88", "理财日均", "8888.88", null));
        m.put("holdings", holdings);

        // 账户信息
        List<Map<String, Object>> accounts = new ArrayList<>();
        Map<String, Object> a1 = new LinkedHashMap<>();
        a1.put("name", "结算户");
        a1.put("count", 1);
        a1.put("unit", "户");
        a1.put("extra", "月均流水：88,888.88");
        accounts.add(a1);
        Map<String, Object> a2 = new LinkedHashMap<>();
        a2.put("name", "一般户");
        a2.put("count", 2);
        a2.put("unit", "户");
        a2.put("extra", null);
        accounts.add(a2);
        m.put("accounts", accounts);

        m.put("holdProducts", new String[]{"自营理财", "代销理财", "存款"});
        m.put("signProducts", new String[]{"待发工资", "结售汇"});

        // 渠道信息
        List<Map<String, Object>> channels = new ArrayList<>();
        channels.add(channel("手机银行", true));
        channels.add(channel("网上银行", true));
        channels.add(channel("柜面", false));
        m.put("channels", channels);
        m.put("channelStatus", "正常");
        m.put("yearAmount", "100,000,000.00");
        m.put("yearCount", "999");

        // 授信视图
        m.put("creditLoanCustomer", "是");
        m.put("creditCardCustomer", "是");
        m.put("debtTypes", "消费贷、XX贷、XXXXXX贷");
        return m;
    }

    /** 商机线索（分类 tab：存款/贷款/供应链） */
    public Map<String, Object> opportunities(String company, String category) {
        List<Map<String, Object>> all = MockStore.opportunities(company);
        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> o : all) {
            if (category == null || "全部".equals(category) || category.equals(o.get("category"))) {
                filtered.add(o);
            }
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);
        m.put("total", all.size());
        m.put("tabs", new String[]{"存款", "贷款", "供应链"});
        m.put("current", category == null ? "存款" : category);
        m.put("list", filtered);
        return m;
    }

    /** 营销话术（场景 tab） */
    public Map<String, Object> scripts(String company, String scene) {
        List<Map<String, Object>> all = MockStore.scripts(company);
        List<Map<String, Object>> filtered = new ArrayList<>();
        String cur = scene == null ? "办公室场景" : scene;
        for (Map<String, Object> s : all) {
            if (cur.equals(s.get("scene"))) {
                filtered.add(s);
            }
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);
        m.put("tabs", new String[]{"办公室场景", "生产车间", "仓库场景", "初次拜访"});
        m.put("current", cur);
        m.put("list", filtered);
        return m;
    }

    /** 经营/财务报表分析（场景b补充报表） */
    public Map<String, Object> reportAnalysis(String company) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("company", company);

        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(sec("1. 经营报表数据",
                "(1). 近 3 年营业收入：7600 万→8230 万 →9150 万，逐年稳步增长，本年营收同比 +11.2%\n" +
                        "(2). 主营业务：工业配套设备生产销售，行业景气度稳定；前五大客户营收占比 38%，无单一客户依赖\n" +
                        "(3). 经营记录：无行政处罚、无司法涉诉、无失信记录；纳税正常，订单饱满，产能利用率 76%\n" +
                        "(4). 贷款用途：申请固定资产抵押贷款 750 万，期限 5 年，用于车间设备更新改造\n" +
                        "(5). 抵押物：自有工业厂房，不动产权证齐全，无查封、无在先抵押；第三方评估价值 1580 万"));
        sections.add(sec("2、财务报表数据（本年）",
                "– 资产总额：11800 万元，负债总额：5428 万元，资产负债率 46.0%\n" +
                        "– 流动比率：1.91，速动比率：1.36\n" +
                        "– 营业收入：9150 万元，净利润：822 万元，毛利率 21.8%，净利率 9.0%\n" +
                        "– 经营活动现金净流量：1016 万元\n" +
                        "– 应收账款周转率 7.1 次，平均回款周期 51 天；无大额逾期应收款\n" +
                        "– 征信：企业及实际控制人无逾期、欠息，信贷记录良好"));
        sections.add(sec("3、交叉分析（经营 + 财务联动校验）",
                "(1). **营收与现金流交叉验证**\n" +
                        "经营报表显示营收持续增长、订单稳定；财务报表经营性现金流净额 > 净利润，说明收入不是账面虚增，销售回款质量较好，经营产生的现金可以持续覆盖贷款本息。\n" +
                        "(2). **盈利与经营稳定性交叉验证**\n" +
                        "经营端订单持续落地，对应财务端连续三年净利润为正、毛利率高于行业平均水平，盈利具备持续性，不是一次性收益。\n" +
                        "(3). **偿债指标交叉校验**\n" +
                        "资产负债率 46% 处于较低水平；流动比率、速动比率达标，短期偿债压力小。结合经营端稳定的订单和现金流，企业中长期还款来源充足。\n" +
                        "(4). **抵押物与授信额度校验**\n" +
                        "抵押物评估值 1580 万，申请贷款 750 万，抵押率 = 750÷1580≈47.5%，低于我行固定资产抵押 70% 上限，抵押缓释充足，产权干净。\n" +
                        "(5). **风险点排查**\n" +
                        "经营层面无重大负面信息；财务无大额其他应收款、无异常关联资金占用；企业征信干净。本次资金用于设备升级，属于主业投入，用途合规。"));
        sections.add(sec("4、综合结论",
                "通过经营报表与财务报表交叉比对，" + company + " 公司主营业务稳定，营收、利润、经营性现金流匹配度高，偿债能力良好，抵押物产权清晰、抵押率合理，整体风险可控。符合我行固定资产抵押贷款准入要求，可以办理该笔固定资产抵押贷款。是否给您安排走访任务？"));
        m.put("sections", sections);
        return m;
    }

    // ---------------- private ----------------

    private Map<String, Object> sec(String title, String body) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        m.put("body", body);
        return m;
    }

    /**
     * 分段图文小节（analysis 模板）：标题右侧带详情链接。
     * linkText = 链接文案（不传则前端不渲染链接）；linkQuery = 点击后回传的文本（缺省取标题）。
     */
    private Map<String, Object> secLinked(String title, String body) {
        Map<String, Object> m = sec(title, body);
        m.put("linkText", SECTION_LINK_TEXT);
        m.put("linkQuery", title);
        return m;
    }

    private List<String> names(List<Map<String, Object>> opps) {
        List<String> list = new ArrayList<>();
        for (Map<String, Object> o : opps) {
            list.add(String.valueOf(o.get("name")));
        }
        return list;
    }

    private Map<String, Object> feature(String label, String value) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("label", label);
        m.put("value", value);
        return m;
    }

    private Map<String, Object> holding(String type, String amount, String dailyLabel, String daily, String tip) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("amount", amount);
        m.put("dailyLabel", dailyLabel);
        m.put("daily", daily);
        m.put("tip", tip);
        return m;
    }

    private Map<String, Object> channel(String name, boolean signed) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", name);
        m.put("signed", signed);
        return m;
    }
}
