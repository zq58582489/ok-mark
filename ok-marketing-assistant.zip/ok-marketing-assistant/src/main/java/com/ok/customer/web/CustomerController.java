package com.ok.customer.web;

import com.ok.common.ApiResponse;
import com.ok.customer.service.CustomerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    /** 关键词检索企业 */
    @GetMapping("/search")
    public ApiResponse<Map<String, Object>> search(@RequestParam String keyword,
                                                   @RequestParam(defaultValue = "5") int limit) {
        return ApiResponse.ok(customerService.search(keyword, limit));
    }

    /** 企业四段分析 */
    @GetMapping("/{company}/analysis")
    public ApiResponse<Map<String, Object>> analysis(@PathVariable String company) {
        return ApiResponse.ok(customerService.analysis(company));
    }

    /** 行业画像卡 */
    @GetMapping("/{company}/industry-profile")
    public ApiResponse<Map<String, Object>> industryProfile(@PathVariable String company) {
        return ApiResponse.ok(customerService.industryProfile(company));
    }

    /** 业务画像卡 */
    @GetMapping("/{company}/business-profile")
    public ApiResponse<Map<String, Object>> businessProfile(@PathVariable String company) {
        return ApiResponse.ok(customerService.businessProfile(company));
    }

    /** 商机线索 */
    @GetMapping("/{company}/opportunities")
    public ApiResponse<Map<String, Object>> opportunities(@PathVariable String company,
                                                          @RequestParam(required = false) String category) {
        return ApiResponse.ok(customerService.opportunities(company, category));
    }

    /** 营销话术 */
    @GetMapping("/{company}/scripts")
    public ApiResponse<Map<String, Object>> scripts(@PathVariable String company,
                                                    @RequestParam(required = false) String scene) {
        return ApiResponse.ok(customerService.scripts(company, scene));
    }

    /** 报表分析（场景b补充报表） */
    @PostMapping("/report-analysis")
    public ApiResponse<Map<String, Object>> reportAnalysis(@RequestBody Map<String, String> body) {
        return ApiResponse.ok(customerService.reportAnalysis(
                body.getOrDefault("company", "江苏韵瑞新能源汽车配件公司")));
    }
}
