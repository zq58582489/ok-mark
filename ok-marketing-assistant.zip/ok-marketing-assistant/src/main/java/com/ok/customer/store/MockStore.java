package com.ok.customer.store;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 原型 Mock 数据（与设计稿内容一致）
 */
public final class MockStore {

    private MockStore() {
    }

    /** 企业库（原型：搜索“国泰”命中10条，页面上展示5条） */
    public static List<Map<String, Object>> companies() {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(company("国泰航空有限公司", "江苏南京", "91320100MA1X2K3P7L"));
        list.add(company("江苏国泰国际集团", "江苏张家港", "91320582MA1XR4T58N"));
        list.add(company("国泰海通证券股份有限公司", "江苏张家港", "91320582MA1X9B6W2F"));
        list.add(company("国泰航空", "江苏南京", "91320100MA1XM8J41D"));
        list.add(company("国泰航空", "江苏南京", "91320100MA1XM8J42C"));
        list.add(company("国泰人寿保险有限责任公司", "江苏南京", "91320100MA1XK7Q93H"));
        list.add(company("国泰君安期货有限公司", "江苏南京", "91320100MA1XL2V76P"));
        list.add(company("国泰盛世（张家港）新材料有限公司", "江苏张家港", "91320582MA1XN5G08T"));
        list.add(company("国泰精密机械有限公司", "江苏南京", "91320100MA1XP6H84R"));
        list.add(company("江苏国泰汉森国际贸易有限公司", "江苏张家港", "91320582MA1XQ3D29V"));
        return list;
    }

    /**
     * 企业卡片数据。含 {@code extra_data}（卡片附加数据，通用字段）：
     * 前端点击企业名称时把「企业名称」作为用户输入展示、把统一社会信用代码随输入回传后台，
     * Chatflow 用它精确检索企业信息（Dify 链路下由 Chatflow 应答自行下发同样的字段）。
     */
    private static Map<String, Object> company(String name, String city, String creditCode) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", name);
        m.put("city", city);
        m.put("status", "存续");
        m.put("legalRep", "王*云");
        Map<String, Object> extra = new LinkedHashMap<>();
        extra.put("creditCode", creditCode);
        m.put("extra_data", extra);
        return m;
    }

    /** 商机线索 5 条（原型内容） */
    public static List<Map<String, Object>> opportunities(String company) {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(opp("存款", "opp-ck",
                "存量存款到期转化",
                "防止存款流失，争取续存或转化",
                "有存款到期，请及时续期",
                "客户经理提前联系，提供 \"自动续存\" 或推荐当期收益更高的存款 / 理财方案。"));
        list.add(opp("贷款", "opp-cw",
                "企业主个人财资管理",
                "提升私人银行 / 财富管理 AUM",
                "法人代表在我行的 AUM 值大于等于 100 万",
                "提供 \"企业家庭财富综合规划\"，以企业服务为纽带，吸引其将个人存款、理财、信托等资产转入我行。"));
        list.add(opp("存款", "opp-df",
                "待发工资资金留存",
                "提升代发工资留存率",
                "企业员工代发工资日均留存偏低",
                "推荐 \"薪理财\" 产品，引导员工工资卡资金留存我行。"));
        list.add(opp("供应链", "opp-wh",
                "外汇收汇资金留存",
                "提升跨境结算份额",
                "企业月度出口收汇量稳定",
                "提供优惠结汇汇率与远期锁汇方案，引导收汇资金归行。"));
        list.add(opp("供应链", "opp-zx",
                "专项资金承接营销",
                "承接政府专项资金账户",
                "企业符合专项资金申报条件",
                "主动对接专项债、补贴资金账户开立与承接服务。"));
        return list;
    }

    private static Map<String, Object> opp(String category, String id, String name,
                                           String goal, String tip, String action) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("category", category);
        m.put("name", name);
        m.put("goal", goal);
        m.put("tip", tip);
        m.put("action", action);
        return m;
    }

    /** 营销话术（场景分组，原型内容） */
    public static List<Map<String, Object>> scripts(String company) {
        List<Map<String, Object>> list = new ArrayList<>();
        String text = "您好，我是XX银行客户经理小李。了解到贵公司近期在园区新投产生产基地。我们在结算与代发工资上有针对性优惠方案，方便用3分钟给您介绍一下吗?";
        list.add(script("办公室场景", "开场白", text));
        list.add(script("办公室场景", "需求挖掘", text));
        list.add(script("办公室场景", "破冰提问", text));
        list.add(script("生产车间", "开场白", text));
        list.add(script("生产车间", "需求挖掘", text));
        list.add(script("仓库场景", "开场白", text));
        list.add(script("初次拜访", "开场白", text));
        return list;
    }

    private static Map<String, Object> script(String scene, String step, String content) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("scene", scene);
        m.put("title", scene + "." + step);
        m.put("content", content);
        m.put("compliant", true); // 合规词库已校验
        return m;
    }

    /** 业务知识问答（固定资产贷款怎么做） */
    public static Map<String, Object> businessQA(String question) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("intro", "针对您的问题我将从①定义、②准入条件、③适用范围、④营销话术这几块给您介绍");
        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(sec("1. 固定资产贷款的定义",
                "固定资产贷款是向企（事）业法人发放的，用于新建、扩建、改造、购置固定资产投资项目 的本外币贷款"));
        sections.add(sec("2. 准入条件",
                "固定资产贷款的准入条件固定资产贷款的准入条件固定资产贷款的准入条件"));
        sections.add(sec("3. 适用范围", null));
        m.put("scopeItems", Arrays.asList(
                "（1）业务适用的范围1", "（2）业务适用的范围2", "（3）业务适用的范围3",
                "（4）业务适用的范围4", "（5）业务适用的范围5"));
        List<Map<String, Object>> scripts = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("title", (i <= 4 ? "(" + i + ")、" : i + ")、") + "营销话术场景" + (i <= 4 ? i : (i == 5 ? 3 : 4)));
            s.put("body", "营销话术营销话术营销话术营销话术营销话术");
            scripts.add(s);
        }
        sections.add(sec("4. 营销话术", null));
        m.put("scriptItems", scripts);
        m.put("sections", sections);
        return m;
    }

    private static Map<String, Object> sec(String title, String body) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        m.put("body", body);
        return m;
    }
}
