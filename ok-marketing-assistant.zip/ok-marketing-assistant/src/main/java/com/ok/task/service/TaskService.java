package com.ok.task.service;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 今日任务 / 触达任务
 */
@Service
public class TaskService {

    /** 今日任务（原型：49条 = 客户经理工作3条 + 客户信息提示任务23条 + 管理审批任务23条） */
    public Map<String, Object> todayTasks() {
        List<Map<String, Object>> groups = new ArrayList<>();

        // 客户经理工作 3条
        List<Map<String, Object>> g1 = new ArrayList<>();
        g1.add(item("开户尽调", "营销工作台-客户洽谈-尽职调查"));
        g1.add(item("客户信息维护后尽调", "营销工作台-客户洽谈-尽职调查"));
        g1.add(item("转介", "转介中心-转介管理"));
        groups.add(group("客户经理工作", 3, g1));

        // 客户信息提示任务 23条
        List<Map<String, Object>> g2 = new ArrayList<>();
        for (int i = 1; i <= 23; i++) {
            g2.add(item("客户信息提示任务" + i, "客户信息提示-待处理"));
        }
        groups.add(group("客户信息提示任务", 23, g2));

        // 管理审批任务 23条
        List<Map<String, Object>> g3 = new ArrayList<>();
        for (int i = 1; i <= 23; i++) {
            g3.add(item("管理审批任务" + i, "审批中心-待审批"));
        }
        groups.add(group("管理审批任务", 23, g3));

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("total", 49);
        m.put("groups", groups);
        return m;
    }

    /** 分配触达任务（原型：对江苏韵瑞新能源汽车配件公司开展固定资产贷款的触达任务） */
    public Map<String, Object> assignReachTask(String company, String business) {
        Map<String, Object> m = new LinkedHashMap<>();
        String taskId = "RT" + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
                + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        m.put("taskId", taskId);
        m.put("company", company);
        m.put("business", business == null ? "固定资产贷款" : business);
        m.put("createTime", System.currentTimeMillis());
        m.put("status", "已生成");
        return m;
    }

    /** 固定资产贷款业务流程（原型流程图节点：主流程 + 右侧支线分组） */
    public Map<String, Object> flow() {
        List<String> main = new ArrayList<>();
        main.add("创建临时客户");
        main.add("临时客户");
        main.add("(开户后)临时客户\n转正");
        main.add("正式客户");
        main.add("资前准备");
        main.add("对公客户开户预约");
        main.add("客户经理尽调");
        main.add("柜面开户");
        main.add("一体化PAD上门开户");
        main.add("(开户后)临时客户\n转正");
        main.add("授信");
        main.add("合同申请");
        main.add("合同签订");
        main.add("合同影像审核(贸易融资、贴现)");
        main.add("出账");

        List<Map<String, Object>> sideGroups = new ArrayList<>();
        sideGroups.add(sideGroup("资前准备", "征信查询", "融资申请",
                "贷前尽调(双录、现场拍照)", "不动产估值(如需)"));
        sideGroups.add(sideGroup("授信", "资前准备", "授信方案确定",
                "撰写调查报告", "利率定价", "其他事项申请(如需)"));
        sideGroups.add(sideGroup("合同影像审核(贸易融 资、贴现)", "国结、票据系统出账"));
        sideGroups.add(sideGroup("出账", "线上签订模式：客户渠道确认",
                "线下纸质签订模式：纸质线下审批"));

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("main", main);
        m.put("sideGroups", sideGroups);
        return m;
    }

    private Map<String, Object> sideGroup(String anchor, String... nodes) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("anchor", anchor);
        m.put("nodes", new ArrayList<>(Arrays.asList(nodes)));
        return m;
    }

    private Map<String, Object> group(String name, int count, List<Map<String, Object>> items) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", name);
        m.put("count", count);
        m.put("open", "客户经理工作".equals(name)); // 原型：第一组展开
        m.put("items", items);
        return m;
    }

    private Map<String, Object> item(String title, String path) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        m.put("path", path);
        return m;
    }
}
