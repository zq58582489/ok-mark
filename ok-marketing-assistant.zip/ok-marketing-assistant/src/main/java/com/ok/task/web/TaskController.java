package com.ok.task.web;

import com.ok.common.ApiResponse;
import com.ok.task.service.TaskService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/task")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    /** 今日任务 */
    @GetMapping("/today")
    public ApiResponse<Map<String, Object>> today() {
        return ApiResponse.ok(taskService.todayTasks());
    }

    /** 分配触达任务 */
    @PostMapping("/reach/assign")
    public ApiResponse<Map<String, Object>> assign(@RequestBody Map<String, String> body) {
        return ApiResponse.ok(taskService.assignReachTask(
                body.getOrDefault("company", "江苏韵瑞新能源汽车配件公司"),
                body.get("business")));
    }

    /** 固定资产贷款业务流程图节点 */
    @GetMapping("/reach/flow")
    public ApiResponse<Map<String, Object>> flow(@RequestParam(required = false) String company) {
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("company", company == null ? "江苏韵瑞新能源汽车配件公司" : company);
        m.putAll(taskService.flow());
        return ApiResponse.ok(m);
    }
}
