package com.ok.auth;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 接口鉴权配置（application.yml: ok.auth.*）。
 *
 * <p>当前对接方式：<b>前端把门户下发的 {@code userToken} 放在 URL 查询参数里</b>
 * （参数名 {@link #param}，默认 {@code userToken}），后端用国密 SM4 解密该密文，
 * 得到用户信息（工号 / 姓名 / 部门）后放行请求。详见 {@link UserTokenService}。
 *
 * <p>所有字段都有可用的默认值，<b>部署时只需要配 {@code ok.auth.sm4.key}</b>；
 * 其余（参数名、受保护路径、SM4 模式 / 填充 / 字符集）按平台约定写在代码里，
 * 需要时用环境变量覆盖即可，不必改 yml。
 *
 * <p>前端 {@code static/js/auth.js} 里的参数名（{@code CFG.param}）与此处保持一致。
 */
@Component
@ConfigurationProperties(prefix = "ok.auth")
public class AuthProperties {

    /** 是否开启接口鉴权；false = 全部放行（仅本地排查问题用，生产勿关） */
    private boolean enabled = true;

    /**
     * 携带用户凭证的查询参数名。
     *
     * <p>门户打开 H5 时拼在地址上（{@code ?userToken=...}），前端后续每个后台请求
     * 都会自动带上同名参数，服务端从这里取。
     */
    private String param = "userToken";

    /**
     * 兼容用的请求头名（默认关闭）。
     *
     * <p>留空表示只认查询参数；如需同时支持请求头（例如自测脚本），填 {@code Authorization} 即可。
     */
    private String header = "";

    /** 请求头前缀（header 开启时生效，如 {@code Bearer }）；默认无前缀 */
    private String prefix = "";

    /** 需要鉴权的路径（Ant 风格），默认只保护 /api/**（静态前端不受影响） */
    private List<String> includePaths = new ArrayList<>(Arrays.asList("/api/**"));

    /** 免鉴权路径白名单（默认无；静态页面与静态资源不在保护范围内） */
    private List<String> whitelist = new ArrayList<>();

    /** SM4 解密参数 */
    private Sm4 sm4 = new Sm4();

    /**
     * SM4 参数。
     *
     * <p>默认值即门户当前约定（ECB + PKCS7 + UTF-8），<b>通常只需要覆盖 {@code key}</b>。
     */
    public static class Sm4 {

        /**
         * 密钥原文（门户提供，原样粘贴）。
         *
         * <p>注意：平台 {@code Util.hexStringToBytes} 用 {@code "0123456789ABCDEF".indexOf(c)}，
         * 非十六进制字符（如本串里的 {@code S}）得到 {@code -1} 而不报错，会参与位运算变成 {@code 0xFF}。
         * {@link com.ok.auth.sm4.Sm4Cipher#parse} 与之逐字对齐，所以这里必须原样保留 {@code S}，
         * <b>不要「修正」成 {@code 45}</b> —— 那样反而解不出。
         */
        private String key = "56896765E334464SD5343396A7215B35";

        /** 密钥书写形式：auto | hex | ascii | base64 */
        private String keyFormat = "auto";

        /** 工作模式：ecb | cbc */
        private String mode = "ecb";

        /** CBC 的初始向量；ECB 模式忽略。留空 = 全 0 */
        private String iv = "";

        /** IV 书写形式：auto | hex | ascii | base64 */
        private String ivFormat = "auto";

        /** 填充方式：pkcs7（含 Java 的 PKCS5Padding）| none | zero */
        private String padding = "pkcs7";

        /** 明文（解密后 JSON）的字符集 */
        private String charset = "UTF-8";

        /**
         * 启动自检用的样例密文（可选）。
         *
         * <p>配置后，应用启动时会尝试解密并打印结果 —— 真实环境里用它确认
         * 「密钥 / 模式 / IV / 填充」四项是否与门户一致，不必等页面报错。
         */
        private String selfTestToken = "";

        /**
         * 调试开关（默认关）。
         *
         * <p>打开后每次解析 userToken 都会把「密文 / 明文的十六进制 + 多种字符集的解码结果」
         * 写入 {@code <java.io.tmpdir>/ok-auth-last-token.txt}（UTF-8），并在日志里打印密文与明文
         * 的 hex —— hex 全是 ASCII，不受 Windows 控制台编码（GBK/UTF-8）影响，
         * 能准确判断「是解密不对，还是只是控制台显示乱码」。
         */
        private boolean debug = false;

        public boolean isDebug() {
            return debug;
        }

        public void setDebug(boolean debug) {
            this.debug = debug;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getKeyFormat() {
            return keyFormat;
        }

        public void setKeyFormat(String keyFormat) {
            this.keyFormat = keyFormat;
        }

        public String getMode() {
            return mode;
        }

        public void setMode(String mode) {
            this.mode = mode;
        }

        public String getIv() {
            return iv;
        }

        public void setIv(String iv) {
            this.iv = iv;
        }

        public String getIvFormat() {
            return ivFormat;
        }

        public void setIvFormat(String ivFormat) {
            this.ivFormat = ivFormat;
        }

        public String getPadding() {
            return padding;
        }

        public void setPadding(String padding) {
            this.padding = padding;
        }

        public String getCharset() {
            return charset;
        }

        public void setCharset(String charset) {
            this.charset = charset;
        }

        public String getSelfTestToken() {
            return selfTestToken;
        }

        public void setSelfTestToken(String selfTestToken) {
            this.selfTestToken = selfTestToken;
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public List<String> getIncludePaths() {
        return includePaths;
    }

    public void setIncludePaths(List<String> includePaths) {
        this.includePaths = includePaths;
    }

    public List<String> getWhitelist() {
        return whitelist;
    }

    public void setWhitelist(List<String> whitelist) {
        this.whitelist = whitelist;
    }

    public Sm4 getSm4() {
        return sm4;
    }

    public void setSm4(Sm4 sm4) {
        this.sm4 = sm4;
    }
}
