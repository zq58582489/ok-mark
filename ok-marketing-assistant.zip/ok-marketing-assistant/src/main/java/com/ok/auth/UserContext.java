package com.ok.auth;

/**
 * 当前请求的登录用户上下文（由 {@link AuthInterceptor} 在校验通过后写入，请求结束时清理）。
 *
 * <p>业务代码里取当前用户统一走这里，例如：
 * <pre>
 *     String userId = UserContext.userId();
 *     LoginUser me = UserContext.get();
 * </pre>
 */
public final class UserContext {

    private static final ThreadLocal<LoginUser> HOLDER = new ThreadLocal<>();

    private UserContext() {
    }

    public static void set(LoginUser user) {
        HOLDER.set(user);
    }

    public static LoginUser get() {
        return HOLDER.get();
    }

    /** 当前登录用户工号；未登录（鉴权关闭或白名单接口）时返回 null */
    public static String userId() {
        LoginUser u = HOLDER.get();
        return u == null ? null : u.getUserId();
    }

    /** 当前登录用户名；未登录时返回 null */
    public static String userName() {
        LoginUser u = HOLDER.get();
        return u == null ? null : u.getUserName();
    }

    public static void clear() {
        HOLDER.remove();
    }
}
