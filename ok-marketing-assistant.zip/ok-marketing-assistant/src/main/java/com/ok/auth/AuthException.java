package com.ok.auth;

/**
 * 鉴权异常：令牌缺失 / 无效 / 过期。
 *
 * <p>统一由 {@code GlobalExceptionHandler} 转成
 * {@code HTTP 401 + {"code":401,"message":"...","data":null}} 返回，前端据此走统一校验失败处理。
 */
public class AuthException extends RuntimeException {

    /** 业务码：401 未认证（默认）/ 403 无权限 */
    private final int code;

    public AuthException(String message) {
        this(401, message);
    }

    public AuthException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
