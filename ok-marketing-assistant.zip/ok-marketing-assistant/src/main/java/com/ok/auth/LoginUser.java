package com.ok.auth;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 当前登录用户（userToken 经 SM4 解密后由 {@link UserTokenService} 装配）
 */
public class LoginUser {

    /** 工号 */
    private String userId;

    /** 姓名 */
    private String userName;

    /** 部门 */
    private String dept;

    /** 签发时间（秒） */
    private long issuedAt;

    /** 过期时间（秒），0 = 不过期 */
    private long expiresAt;

    public LoginUser() {
    }

    public LoginUser(String userId, String userName, String dept, long issuedAt, long expiresAt) {
        this.userId = userId;
        this.userName = userName;
        this.dept = dept;
        this.issuedAt = issuedAt;
        this.expiresAt = expiresAt;
    }

    /** 对外输出（/api/auth/me、/api/auth/token 的 user 字段） */
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("userId", userId);
        m.put("name", userName);
        m.put("dept", dept);
        m.put("issuedAt", issuedAt);
        m.put("expiresAt", expiresAt);
        return m;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public long getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(long issuedAt) {
        this.issuedAt = issuedAt;
    }

    public long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(long expiresAt) {
        this.expiresAt = expiresAt;
    }
}
