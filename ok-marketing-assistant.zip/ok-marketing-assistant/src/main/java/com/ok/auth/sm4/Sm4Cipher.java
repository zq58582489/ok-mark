package com.ok.auth.sm4;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * SM4 分组工作模式与填充（在 {@link Sm4} 之上的一层薄封装）。
 *
 * <p>支持实际联调中最常见的几种约定：
 * <ul>
 *   <li>模式：{@code ECB} / {@code CBC}（IV 固定值；不支持的 GCM/CTR 等不做，避免误用）</li>
 *   <li>填充：{@code PKCS7}（Java 里常叫 PKCS5Padding）/ {@code NONE} / {@code ZERO}</li>
 *   <li>密钥与 IV 的书写形式：{@code hex}（32 个十六进制字符）/ {@code ascii}（16 字符原文）
 *       / {@code base64}；{@code auto} 会自动判断</li>
 * </ul>
 *
 * <p>解密是「宽容」的：服务端不掌握加密方的每个细节，因此 PKCS7 去填充失败时
 * 会退化为「去掉末尾 0x00」，仍失败则原样返回 —— 由上层按 JSON 解析结果判定是否有效，
 * 解析不出来统一按 401 处理，不会因为填充风格差异把合法用户挡在外面。
 */
public final class Sm4Cipher {

    private Sm4Cipher() {
    }

    /** 工作模式 */
    public enum Mode {
        ECB, CBC;

        public static Mode of(String s) {
            return "cbc".equalsIgnoreCase(trim(s)) ? CBC : ECB;
        }
    }

    /** 填充方式 */
    public enum Padding {
        PKCS7, NONE, ZERO;

        public static Padding of(String s) {
            String v = trim(s).toLowerCase();
            if ("none".equals(v) || "nopadding".equals(v)) {
                return NONE;
            }
            if ("zero".equals(v) || "zeros".equals(v)) {
                return ZERO;
            }
            return PKCS7;
        }
    }

    /** 解密（自动校验分组长度，返回已去填充的明文） */
    public static byte[] decrypt(byte[] cipher, byte[] key, Mode mode, byte[] iv, Padding padding) {
        if (cipher == null || cipher.length == 0) {
            throw new IllegalArgumentException("SM4 密文为空");
        }
        if (cipher.length % Sm4.BLOCK_SIZE != 0) {
            throw new IllegalArgumentException("SM4 密文长度（" + cipher.length + " 字节）不是 16 的整数倍");
        }
        Sm4 sm4 = new Sm4(key);
        int blocks = cipher.length / Sm4.BLOCK_SIZE;
        byte[] out = new byte[cipher.length];
        byte[] prev = new byte[Sm4.BLOCK_SIZE];
        if (mode == Mode.CBC && iv != null) {
            System.arraycopy(iv, 0, prev, 0, Math.min(iv.length, Sm4.BLOCK_SIZE));
        }
        byte[] tmp = new byte[Sm4.BLOCK_SIZE];
        for (int i = 0; i < blocks; i++) {
            int off = i * Sm4.BLOCK_SIZE;
            sm4.decryptBlock(cipher, off, tmp, 0);
            if (mode == Mode.CBC) {
                for (int j = 0; j < Sm4.BLOCK_SIZE; j++) {
                    out[off + j] = (byte) (tmp[j] ^ prev[j]);
                    prev[j] = cipher[off + j];
                }
            } else {
                System.arraycopy(tmp, 0, out, off, Sm4.BLOCK_SIZE);
            }
        }
        return unpad(out, padding);
    }

    /** 加密（仅供自检 / 联调造数使用） */
    public static byte[] encrypt(byte[] plain, byte[] key, Mode mode, byte[] iv, Padding padding) {
        byte[] data = pad(plain, padding);
        Sm4 sm4 = new Sm4(key);
        byte[] prev = new byte[Sm4.BLOCK_SIZE];
        if (mode == Mode.CBC && iv != null) {
            System.arraycopy(iv, 0, prev, 0, Math.min(iv.length, Sm4.BLOCK_SIZE));
        }
        byte[] out = new byte[data.length];
        byte[] tmp = new byte[Sm4.BLOCK_SIZE];
        for (int off = 0; off < data.length; off += Sm4.BLOCK_SIZE) {
            if (mode == Mode.CBC) {
                for (int j = 0; j < Sm4.BLOCK_SIZE; j++) {
                    tmp[j] = (byte) (data[off + j] ^ prev[j]);
                }
            } else {
                System.arraycopy(data, off, tmp, 0, Sm4.BLOCK_SIZE);
            }
            sm4.encryptBlock(tmp, 0, out, off);
            if (mode == Mode.CBC) {
                System.arraycopy(out, off, prev, 0, Sm4.BLOCK_SIZE);
            }
        }
        return out;
    }

    /* ---------------- 填充 ---------------- */

    private static byte[] pad(byte[] plain, Padding padding) {
        int remain = plain.length % Sm4.BLOCK_SIZE;
        int padLen = Sm4.BLOCK_SIZE - remain;
        if (padding == Padding.NONE) {
            if (remain != 0) {
                throw new IllegalArgumentException("NONE 填充要求明文长度是 16 的整数倍");
            }
            return plain;
        }
        byte[] out = new byte[plain.length + padLen];
        System.arraycopy(plain, 0, out, 0, plain.length);
        byte fill = (byte) (padding == Padding.ZERO ? 0 : padLen);
        for (int i = plain.length; i < out.length; i++) {
            out[i] = fill;
        }
        return out;
    }

    private static byte[] unpad(byte[] data, Padding padding) {
        if (padding == Padding.NONE) {
            return data;
        }
        if (padding == Padding.PKCS7) {
            int n = data[data.length - 1] & 0xff;
            if (n >= 1 && n <= Sm4.BLOCK_SIZE && n <= data.length) {
                boolean ok = true;
                for (int i = data.length - n; i < data.length; i++) {
                    if ((data[i] & 0xff) != n) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    return slice(data, data.length - n);
                }
            }
            // 填充风格不是 PKCS7：退化为去尾部 0x00（下面统一处理）
        }
        int len = data.length;
        while (len > 0 && data[len - 1] == 0) {
            len--;
        }
        return slice(data, len);
    }

    /* ---------------- 密钥 / IV / Base64 解析 ---------------- */

    /**
     * 解析密钥或 IV。
     *
     * @param text   配置里的原值
     * @param format hex | ascii | base64 | auto
     * @param name   日志里显示的名字（key / iv）
     */
    public static byte[] parse(String text, String format, String name) {
        String s = trim(text);
        if (s.isEmpty()) {
            return null;
        }
        String f = trim(format).toLowerCase();
        if (f.isEmpty()) {
            f = "auto";
        }
        if ("base64".equals(f)) {
            return decodeBase64(s);
        }
        if ("hex".equals(f) || ("auto".equals(f) && looksLikeHex(s))) {
            byte[] raw = hexToBytesCompat(s);
            // auto：解析出的长度不对（例如 16 位纯 ascii 密钥本身也像 hex）时退回 ascii
            if (raw.length == Sm4.KEY_SIZE || !"auto".equals(f)) {
                return raw;
            }
        }
        // ascii：不足 16 字节按 0 补齐，超过 16 字节取前 16（与多数工具类一致）
        byte[] raw = s.getBytes(StandardCharsets.UTF_8);
        if (raw.length == Sm4.KEY_SIZE) {
            return raw;
        }
        byte[] out = new byte[Sm4.KEY_SIZE];
        System.arraycopy(raw, 0, out, 0, Math.min(raw.length, Sm4.KEY_SIZE));
        return out;
    }

    /**
     * 十六进制字符串 → 字节，<b>按平台 {@code SM4Utils} 的 {@code Util.hexStringToBytes} 语义</b>。
     *
     * <p>平台工具类用的是 {@code "0123456789ABCDEF".indexOf(c)}，遇到非十六进制字符
     * 得到 {@code -1} 而<b>不会报错</b>，随后连同高位一起参与 {@code << 4 | } 运算再截断成字节。
     * 例如密钥 {@code 56896765E334464SD5343396A7215B35} 里的 {@code S}：
     * {@code '4'→4}、{@code 'S'→-1}，{@code (4<<4)|-1 = -1}，于是该字节是 {@code 0xFF}。
     *
     * <p>实际联调中这类「密钥里混入一个笔误字符」很常见，且加密方自己验得通，
     * 因此这里必须逐字对齐，否则同样一段密文在加密方能解、在我们这就解不出。
     * 长度取整（奇数长度丢弃最后一个字符）也与示例一致。
     */
    public static byte[] hexToBytesCompat(String hex) {
        String s = trim(hex).toUpperCase();
        int n = s.length() / 2;
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            int hi = "0123456789ABCDEF".indexOf(s.charAt(i * 2));
            int lo = "0123456789ABCDEF".indexOf(s.charAt(i * 2 + 1));
            out[i] = (byte) ((hi << 4) | lo);
        }
        return out;
    }

    /** 字符串里是否含非十六进制字符（用于启动日志提示「密钥按工具类规则解析」） */
    public static boolean hasNonHexChars(String text) {
        String s = trim(text);
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) < 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * 是否「看起来像十六进制」：长度为偶数，且至少 3/4 的字符是 0-9A-Fa-f。
     *
     * <p>不能要求 100% 合法 —— 平台示例的密钥里就混着 {@code S}，
     * 若判成 ascii 会把 32 字符截成前 16 字符，解密结果完全错误。
     */
    public static boolean looksLikeHex(String text) {
        String s = trim(text);
        if (s.isEmpty() || s.length() % 2 != 0) {
            return false;
        }
        int hit = 0;
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) >= 0) {
                hit++;
            }
        }
        return hit * 4 >= s.length() * 3;
    }

    /** Base64 宽容解码：兼容 URL-safe、缺失 padding、换行，以及被当成空格的 '+' */
    public static byte[] decodeBase64(String text) {
        String s = text == null ? "" : text.trim()
                .replace("\r", "").replace("\n", "").replace("\t", "");
        if (s.isEmpty()) {
            return new byte[0];
        }
        // Base64 里不会有空格：出现空格说明 '+' 在 URL 传递过程中被解码成了空格，还原回来
        s = s.replace(' ', '+').replace('-', '+').replace('_', '/');
        int mod = s.length() % 4;
        if (mod == 2) {
            s += "==";
        } else if (mod == 3) {
            s += "=";
        } else if (mod == 1) {
            throw new IllegalArgumentException("Base64 长度不合法（" + text.length() + " 字符）");
        }
        try {
            return Base64.getDecoder().decode(s);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Base64 解码失败：" + e.getMessage());
        }
    }

    /** 十六进制字符串 → 字节 */
    public static byte[] hexToBytes(String hex) {
        String s = trim(hex);
        if (s.length() % 2 != 0) {
            throw new IllegalArgumentException("十六进制长度必须是偶数：" + s.length());
        }
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) {
            int hi = Character.digit(s.charAt(i * 2), 16);
            int lo = Character.digit(s.charAt(i * 2 + 1), 16);
            if (hi < 0 || lo < 0) {
                throw new IllegalArgumentException("非法的十六进制字符：位置 " + (hi < 0 ? i * 2 : i * 2 + 1));
            }
            out[i] = (byte) ((hi << 4) | lo);
        }
        return out;
    }

    /** 字节 → 十六进制（统一小写，便于日志比对） */
    public static String toHex(byte[] bytes) {
        if (bytes == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(Character.forDigit((b >> 4) & 0xf, 16)).append(Character.forDigit(b & 0xf, 16));
        }
        return sb.toString();
    }

    /**
     * 明文按字符集解码。
     *
     * <p>若按指定字符集解出「替换符」{@code \uFFFD}，说明加密方用的不是这个字符集
     * （Windows 上的 Java 工具类默认 {@code file.encoding=GBK}，很容易出现
     * 「密文对、密钥也对，但解出来是乱码」），此时自动改用 GB18030 / UTF-8 再试一次，
     * 取第一个不含替换符的结果。都不行才返回原结果，由上层按 JSON 解析失败处理。
     */
    public static String decodeText(byte[] bytes, String charset) {
        String name = trim(charset);
        Charset cs = charsetOf(name, StandardCharsets.UTF_8);
        String text = new String(bytes, cs);
        if (!hasReplacement(text)) {
            return text;
        }
        for (String alt : new String[]{"GB18030", "UTF-8"}) {
            Charset c = charsetOf(alt, null);
            if (c == null || c.equals(cs)) {
                continue;
            }
            String t = new String(bytes, c);
            if (!hasReplacement(t)) {
                return t;
            }
        }
        return text;
    }

    /** 文本里是否含解码失败产生的替换符（{@code \uFFFD}） */
    public static boolean hasReplacement(String text) {
        return text != null && text.indexOf('\uFFFD') >= 0;
    }

    private static Charset charsetOf(String name, Charset fallback) {
        if (name == null || name.isEmpty()) {
            return fallback;
        }
        try {
            return Charset.forName(name);
        } catch (Exception e) {
            return fallback;
        }
    }

    /* ---------------- 内部小工具 ---------------- */

    private static byte[] slice(byte[] data, int len) {
        byte[] out = new byte[len];
        System.arraycopy(data, 0, out, 0, len);
        return out;
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    /** 日志里不要打出完整密钥：只留前 4 位 */
    public static String mask(String s) {
        if (s == null || s.length() <= 4) {
            return "****";
        }
        return s.substring(0, 4) + "****（长度 " + s.length() + "）";
    }
}
