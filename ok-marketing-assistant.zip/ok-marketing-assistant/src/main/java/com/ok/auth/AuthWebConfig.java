package com.ok.auth;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 注册鉴权拦截器：保护 {@code ok.auth.include-paths}（默认 {@code /api/**}），
 * 放行 {@code ok.auth.whitelist}（默认为空 —— 所有接口都要带 userToken）。
 *
 * <p>静态资源（前端页面、js/css/图片）不在保护范围内，未取到凭证时页面仍可正常打开
 * （页面本身能加载，接口会返回 401 并由前端统一提示）。
 */
@Configuration
public class AuthWebConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;

    private final AuthProperties props;

    public AuthWebConfig(AuthInterceptor authInterceptor, AuthProperties props) {
        this.authInterceptor = authInterceptor;
        this.props = props;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration registration = registry.addInterceptor(authInterceptor)
                .addPathPatterns(props.getIncludePaths().toArray(new String[0]));
        if (props.getWhitelist() != null && !props.getWhitelist().isEmpty()) {
            registration.excludePathPatterns(props.getWhitelist().toArray(new String[0]));
        }
    }
}
