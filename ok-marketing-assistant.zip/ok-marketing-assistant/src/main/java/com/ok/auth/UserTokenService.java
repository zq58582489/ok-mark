package com.ok.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ok.auth.sm4.Sm4Cipher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 用户凭证（{@code userToken}）解析服务：<b>SM4 解密 → 取用户信息</b>。
 *
 * <p>门户在打开本应用时把加密后的用户信息拼在地址上（{@code ?userToken=xxx}），
 * 本服务负责把它还原成 {@link LoginUser}：
 * <ol>
 *   <li>Base64 解码（兼容 URL-safe、缺失 padding、含换行）；</li>
 *   <li>按配置的 SM4 参数解密（见 {@link AuthProperties.Sm4}：模式 / IV / 填充 / 字符集）；</li>
 *   <li>明文按 JSON 解析（也兼容 {@code k=v&k=v} 形式），按别名表取工号、姓名、部门。</li>
 * </ol>
 *
 * <p><b>关于用户信息字段名</b>：不同平台的字段命名不一致（userId / gh / 工号 …），
 * 这里按「忽略大小写与下划线」的别名表匹配，覆盖常见写法；匹配不到工号时按「整个明文」
 * 的哈希兜底（保证请求仍可区分用户），但会在日志里提示补充别名。
 */
@Service
public class UserTokenService {

    private static final Logger log = LoggerFactory.getLogger(UserTokenService.class);

    /** 工号别名（比较时会统一去掉下划线/连字符并转小写） */
    private static final String[] USER_ID_KEYS = {
            // 秦农（人保/人力口径）：psnscode = 人员编码
            "psnscode", "psncode", "psnno",
            "userid", "user", "gh", "ygh", "jobno", "jobnumber", "empno", "employeeno",
            "account", "accountid", "loginid", "loginname", "operatorid", "operator", "staffid",
            "staffno", "工号", "员工号", "用户id", "用户编码"
    };

    /** 姓名别名 */
    private static final String[] USER_NAME_KEYS = {
            "psnname",
            "username", "name", "realname", "cnname", "displayname", "xm", "yhmc", "staffname",
            "operatorname", "姓名", "用户姓名", "员工姓名"
    };

    /** 部门别名（deptshortname = 机构简称，优先于机构编码） */
    private static final String[] DEPT_KEYS = {
            "deptshortname", "shortname", "deptname", "dept", "deptcode",
            "department", "departmentname", "orgname", "orgnm",
            "bmmc", "bmid", "branch", "branchname", "institution",
            "rldpcode", "机构", "部门", "部门名称", "所属机构"
    };

    /** 过期时间别名（若平台下发；秒或毫秒都兼容） */
    private static final String[] EXP_KEYS = {
            "exp", "expire", "expires", "expiretime", "expiresat", "expirytime", "validto",
            "validuntil", "deadline", "过期时间"
    };

    private final AuthProperties props;

    private final ObjectMapper mapper = new ObjectMapper();

    /** 解析后的密钥 / IV（首次使用时解析，避免每次请求做十六进制转换） */
    private volatile byte[] keyBytes;

    private volatile byte[] ivBytes;

    public UserTokenService(AuthProperties props) {
        this.props = props;
    }

    /** 启动自检：配置了样例密文就先解一次，把结果打到日志（真实环境校准参数用） */
    @PostConstruct
    void selfTest() {
        if (!props.isEnabled()) {
            log.warn("接口鉴权已关闭（ok.auth.enabled=false）：所有 /api 请求放行，用户固定为「本地调试」");
            return;
        }
        // 先把密钥解析一遍：配置写错时在启动日志里立刻能看到，而不是等第一个请求 401
        try {
            byte[] k = key();
            log.info("接口鉴权：SM4 模式，参数名={} mode={} padding={} keyFormat={} key={}（{} 字节）",
                    props.getParam(), props.getSm4().getMode(), props.getSm4().getPadding(),
                    props.getSm4().getKeyFormat(), Sm4Cipher.mask(props.getSm4().getKey()), k.length);
        } catch (Exception e) {
            log.error("接口鉴权：SM4 密钥配置无效 —— {}（所有 /api 请求都会 401）", e.getMessage());
            return;
        }
        String sample = props.getSm4().getSelfTestToken();
        if (sample == null || sample.trim().isEmpty()) {
            return;
        }
        try {
            LoginUser u = parseToken(sample);
            log.info("SM4 自检通过：userId={} name={} dept={}", u.getUserId(), u.getUserName(), u.getDept());
        } catch (Exception e) {
            log.warn("SM4 自检失败：{}", e.getMessage());
            // 失败时把诊断打全：明文 hex 能直接看出是「解出随机字节」还是「字符集不对」
            log.warn("SM4 自检诊断：\n{}", diagnose(sample));
        }
    }

    /**
     * 鉴权关闭（{@code ok.auth.enabled=false}）时使用的本地调试用户。
     *
     * <p>只用于本地排查问题，生产环境不会走到这里 —— 部署时保持 {@code enabled=true} 即可。
     */
    public LoginUser localUser() {
        return new LoginUser("local", "本地调试", "", 0L, 0L);
    }

    /**
     * 校验并解析用户凭证。
     *
     * @param token URL 参数 {@code userToken} 的原文（Base64 密文）
     * @return 登录用户
     * @throws AuthException 缺失 / 格式错误 / 解密失败 / 已过期
     */
    public LoginUser verify(String token) {
        return parseToken(token);
    }

    /** 解密 + 解析（不做 mock 判断，自检也走这里） */
    private LoginUser parseToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            throw new AuthException("缺少用户凭证（userToken），请从门户重新进入");
        }
        byte[] plainBytes;
        try {
            byte[] cipher = Sm4Cipher.decodeBase64(token);
            plainBytes = Sm4Cipher.decrypt(cipher, key(), mode(), iv(), padding());
        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            log.warn("userToken 解密失败：{}", e.getMessage());
            debugDiagnose(token);
            throw new AuthException("用户凭证解析失败，请从门户重新进入");
        }
        String plain = Sm4Cipher.decodeText(plainBytes, props.getSm4().getCharset());
        // 配置的字符集解出替换符 → decodeText 已自动改用 GB18030；这里提示一次，便于改成固定配置
        String asConfigured = new String(plainBytes, charsetOr(props.getSm4().getCharset()));
        if (Sm4Cipher.hasReplacement(asConfigured)) {
            log.info("userToken 明文不是 {} 编码（已自动按 GB18030 解码）；如长期如此可把 ok.auth.sm4.charset 配成 GB18030",
                    props.getSm4().getCharset());
        }
        debugDiagnose(token);
        Map<String, Object> data = parse(plain);
        LoginUser user = toUser(data, plain);
        checkExpiry(data, user);
        if (log.isDebugEnabled()) {
            log.debug("userToken 解析成功：{}", user.toMap());
        }
        return user;
    }

    /**
     * 解密诊断（{@code ok.auth.sm4.debug=true} 时生效）。
     *
     * <p>把密文 / 明文的 <b>十六进制</b>（纯 ASCII，不受 Windows 控制台 GBK/UTF-8 影响）
     * 与「按 UTF-8、GB18030 分别解码」的结果一起写入
     * {@code <java.io.tmpdir>/ok-auth-last-token.txt}，日志里同步打印 hex。
     *
     * <p>用途：区分「解密结果本身就不对」和「明文是对的、只是控制台把中文显示成乱码」。
     */
    private void debugDiagnose(String token) {
        if (!props.getSm4().isDebug()) {
            return;
        }
        String info = "=== userToken 解密诊断（ok.auth.sm4.debug=true）===\n" + diagnose(token);
        File f = new File(System.getProperty("java.io.tmpdir", "."), "ok-auth-last-token.txt");
        try {
            Files.write(f.toPath(), info.getBytes(StandardCharsets.UTF_8));
            log.info("userToken 诊断已写入 {}（UTF-8，直接打开看明文）", f.getAbsolutePath());
        } catch (Exception e) {
            log.warn("userToken 诊断写入失败：{}", e.getMessage());
        }
        log.info("userToken 诊断摘要：{}", oneLine(info));
    }

    /**
     * 生成诊断信息（不解析 JSON，只看字节形态）。
     *
     * @param token userToken 原文
     * @return 多行文本：参数、密文 hex、明文 hex、两种字符集的解码结果与结论
     */
    public String diagnose(String token) {
        AuthProperties.Sm4 cfg = props.getSm4();
        StringBuilder sb = new StringBuilder();
        sb.append("参数：key=").append(Sm4Cipher.mask(cfg.getKey()))
                .append(" keyFormat=").append(cfg.getKeyFormat())
                .append(" mode=").append(cfg.getMode())
                .append(" iv=").append(cfg.getIv() == null || cfg.getIv().trim().isEmpty() ? "(全 0)" : Sm4Cipher.mask(cfg.getIv()))
                .append(" padding=").append(cfg.getPadding())
                .append(" charset=").append(cfg.getCharset())
                .append('\n');
        byte[] cipher;
        try {
            cipher = Sm4Cipher.decodeBase64(token);
        } catch (Exception e) {
            return sb.append("Base64 解码失败：").append(e.getMessage()).append('\n').toString();
        }
        sb.append("密文：").append(cipher.length).append(" 字节\n").append(hexLines(cipher)).append('\n');
        byte[] plain;
        try {
            plain = Sm4Cipher.decrypt(cipher, key(), mode(), iv(), padding());
        } catch (Exception e) {
            return sb.append("解密失败：").append(e.getMessage()).append('\n').toString();
        }
        sb.append("明文：").append(plain.length).append(" 字节\n").append(hexLines(plain)).append('\n');
        String utf8 = new String(plain, StandardCharsets.UTF_8);
        String gbk = new String(plain, charsetOr("GB18030"));
        sb.append("按 UTF-8 解码：").append(utf8).append('\n');
        sb.append("按 GB18030 解码：").append(gbk).append('\n');
        sb.append("结论：").append(verdict(utf8, gbk)).append('\n');
        return sb.toString();
    }

    /** 根据解码结果给出「是解密不对、字符集不对，还是仅显示乱码」的判断 */
    private static String verdict(String utf8, String gbk) {
        String u = utf8 == null ? "" : utf8.trim();
        String g = gbk == null ? "" : gbk.trim();
        boolean uJson = u.startsWith("{") || u.startsWith("[");
        boolean gJson = g.startsWith("{") || g.startsWith("[");
        boolean uBad = Sm4Cipher.hasReplacement(utf8);
        if (uJson && !uBad) {
            return "明文是 JSON（UTF-8），密钥 / 模式 / IV / 填充都正确";
        }
        if (gJson && !Sm4Cipher.hasReplacement(gbk)) {
            return "密钥 / 模式 / IV / 填充都正确，但明文不是 UTF-8（GB18030 才能解出中文）——"
                    + "服务已自动按 GB18030 解码；如需固定，把 charset 配成 GB18030";
        }
        if (uJson || gJson) {
            return "明文大致是 JSON 但含非法字节（可能填充方式不同或被截断），建议核对 padding";
        }
        return "两种字符集都解不出可读文本 —— 密钥 / 模式 / IV / 填充与加密方不一致（或密文被截断/转义过）";
    }

    private static Charset charsetOr(String name) {
        try {
            return Charset.forName(name);
        } catch (Exception e) {
            return StandardCharsets.UTF_8;
        }
    }

    /** 十六进制按 32 字节一行输出，便于和加密方工具比对 */
    private static String hexLines(byte[] data) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.length; i += 32) {
            sb.append(String.format("%04x  ", i))
                    .append(Sm4Cipher.toHex(java.util.Arrays.copyOfRange(data, i, Math.min(data.length, i + 32))))
                    .append('\n');
        }
        return sb.toString();
    }

    /** 日志里只留单行摘要（多行 INFO 在部分容器日志里会被截断） */
    private static String oneLine(String text) {
        String s = text.replace("\r", "").replace("\n", " | ");
        return s.length() > 600 ? s.substring(0, 600) + " …" : s;
    }

    /** 解密为明文（不含用户字段映射），自检与排查用 */
    public String decrypt(String token) {
        byte[] cipher = Sm4Cipher.decodeBase64(token);
        byte[] plain = Sm4Cipher.decrypt(cipher, key(), mode(), iv(), padding());
        String text = Sm4Cipher.decodeText(plain, props.getSm4().getCharset());
        if (log.isDebugEnabled()) {
            log.debug("userToken 密文 {} 字节 → 明文 {} 字符", cipher.length, text.length());
        }
        return text;
    }

    /* ---------------- 内部实现 ---------------- */

    private byte[] key() {
        byte[] k = keyBytes;
        if (k == null) {
            synchronized (this) {
                if (keyBytes == null) {
                    AuthProperties.Sm4 cfg = props.getSm4();
                    byte[] parsed = Sm4Cipher.parse(cfg.getKey(), cfg.getKeyFormat(), "ok.auth.sm4.key");
                    if (parsed == null) {
                        throw new IllegalStateException("未配置 ok.auth.sm4.key");
                    }
                    String fmt = cfg.getKeyFormat() == null ? "" : cfg.getKeyFormat().trim().toLowerCase();
                    boolean asHex = "hex".equals(fmt) || ("auto".equals(fmt) && Sm4Cipher.looksLikeHex(cfg.getKey()));
                    if (asHex && Sm4Cipher.hasNonHexChars(cfg.getKey())) {
                        // 平台工具类对非十六进制字符不报错（indexOf 得到 -1），必须逐字对齐才不会解错
                        log.warn("ok.auth.sm4.key 含非十六进制字符 '{}'，已按平台 SM4Utils 的 "
                                        + "Util.hexStringToBytes 规则解析（该字符 indexOf=-1 参与位运算），实际密钥字节 = {}",
                                firstNonHex(cfg.getKey()), Sm4Cipher.toHex(parsed));
                    } else if (!asHex) {
                        log.warn("ok.auth.sm4.key 按 {} 解析为 {} 字节；若平台给的是十六进制串请把 key-format 设为 hex",
                                fmt.isEmpty() ? "auto" : fmt, parsed.length);
                    }
                    keyBytes = parsed;
                }
                k = keyBytes;
            }
        }
        return k;
    }

    /** 第一个非十六进制字符（用于日志定位密钥里的笔误） */
    private static String firstNonHex(String s) {
        if (s == null) {
            return "";
        }
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) < 0) {
                return String.valueOf(s.charAt(i));
            }
        }
        return "";
    }

    private byte[] iv() {
        byte[] v = ivBytes;
        if (v == null) {
            AuthProperties.Sm4 cfg = props.getSm4();
            byte[] parsed = Sm4Cipher.parse(cfg.getIv(), cfg.getIvFormat(), "ok.auth.sm4.iv");
            v = parsed == null ? new byte[16] : parsed;
            ivBytes = v;
        }
        return v;
    }

    private Sm4Cipher.Mode mode() {
        return Sm4Cipher.Mode.of(props.getSm4().getMode());
    }

    private Sm4Cipher.Padding padding() {
        return Sm4Cipher.Padding.of(props.getSm4().getPadding());
    }

    /** 明文 → Map：优先按 JSON，其次按 {@code k=v&k=v} 解析 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> parse(String plain) {
        String text = plain == null ? "" : plain.trim();
        if (text.isEmpty()) {
            throw new AuthException("用户凭证内容为空，请从门户重新进入");
        }
        if (text.startsWith("{") || text.startsWith("[")) {
            try {
                Object v = mapper.readValue(text, Object.class);
                if (v instanceof Map) {
                    return (Map<String, Object>) v;
                }
                throw new AuthException("用户凭证内容不是对象，请从门户重新进入");
            } catch (AuthException e) {
                throw e;
            } catch (Exception e) {
                throw new AuthException("用户凭证内容解析失败，请从门户重新进入");
            }
        }
        // 兼容 k=v&k=v 形式（部分平台只加密一个查询串）
        Map<String, Object> map = new LinkedHashMap<>();
        for (String pair : text.split("[&;]")) {
            int i = pair.indexOf('=');
            if (i > 0) {
                map.put(pair.substring(0, i).trim(), pair.substring(i + 1).trim());
            }
        }
        if (map.isEmpty()) {
            // 既不是 JSON 也没有 k=v：正常的凭证不会是这样。多半是密钥 / 模式 / IV / 填充 / 字符集
            // 与加密方不一致（解出来是随机字节），也可能是密文被截断或转义过。
            throw new AuthException("用户凭证解密后内容不可识别（不是 JSON，也不是 k=v 串）——"
                    + "请核对 ok.auth.sm4.* 的 key / mode / iv / padding / charset，"
                    + "或用 ok.auth.sm4.debug=true 查看诊断");
        }
        return map;
    }

    /** 从解析结果里取用户：先看根，再看常见的包裹层（data / user / userInfo） */
    @SuppressWarnings("unchecked")
    private LoginUser toUser(Map<String, Object> data, String plain) {
        Map<String, Object> user = new LinkedHashMap<>(data);
        for (String wrapper : new String[]{"data", "user", "userInfo", "userinfo", "result", "body"}) {
            Object inner = data.get(wrapper);
            if (inner instanceof Map) {
                user.putAll((Map<String, Object>) inner);
            }
        }
        String userId = firstString(user, USER_ID_KEYS);
        String userName = firstString(user, USER_NAME_KEYS);
        String dept = firstString(user, DEPT_KEYS);
        if (isBlank(userId)) {
            // 极少数平台只给姓名：用姓名兜底当用户标识，至少能区分会话
            userId = isBlank(userName) ? fallbackId(plain) : userName;
            log.warn("userToken 明文里没有识别到工号字段（已用 {} 兜底）。"
                    + "如字段名特殊，请在 UserTokenService.USER_ID_KEYS 里补充", userId);
        }
        // 凭证由门户签发，应用侧拿不到签发时间：issuedAt 记 0（不作展示依据）
        return new LoginUser(userId, isBlank(userName) ? userId : userName, dept, 0L, 0L);
    }

    /** 过期校验：平台带 exp 时按它判断；不带则只依赖门户自身的时效 */
    private void checkExpiry(Map<String, Object> data, LoginUser user) {
        String raw = firstString(data, EXP_KEYS);
        if (isBlank(raw)) {
            return;
        }
        long v;
        try {
            v = Long.parseLong(raw.trim());
        } catch (NumberFormatException e) {
            return;
        }
        if (v <= 0) {
            return;
        }
        // 大于 1e12 视为毫秒
        long expSeconds = v > 1_000_000_000_000L ? v / 1000L : v;
        user.setExpiresAt(expSeconds);
        if (System.currentTimeMillis() / 1000L > expSeconds) {
            throw new AuthException("用户凭证已过期，请从门户重新进入");
        }
    }

    /** 忽略大小写与 _ - 的别名匹配；值是数字/布尔时转字符串 */
    private static String firstString(Map<String, Object> map, String[] keys) {
        for (String key : keys) {
            Object v = findByLooseKey(map, key);
            if (v != null) {
                String s = String.valueOf(v).trim();
                if (!s.isEmpty() && !"null".equalsIgnoreCase(s)) {
                    return s;
                }
            }
        }
        return "";
    }

    private static Object findByLooseKey(Map<String, Object> map, String key) {
        Object direct = map.get(key);
        if (direct != null) {
            return direct;
        }
        String target = loose(key);
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (e.getKey() != null && loose(e.getKey()).equals(target)) {
                return e.getValue();
            }
        }
        return null;
    }

    private static String loose(String s) {
        return s == null ? "" : s.replace("_", "").replace("-", "").replace(" ", "")
                .toLowerCase(Locale.ROOT);
    }

    /** 兜底用户标识：明文的短哈希（稳定且不可逆，足以区分不同凭证） */
    private static String fallbackId(String plain) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(plain.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return "U" + Sm4Cipher.toHex(new byte[]{h[0], h[1], h[2], h[3]});
        } catch (Exception e) {
            return "U00000000";
        }
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
