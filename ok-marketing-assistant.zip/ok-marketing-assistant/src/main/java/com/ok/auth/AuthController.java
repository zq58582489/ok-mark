package com.ok.auth;

import com.ok.common.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 鉴权接口。
 *
 * <p>用户凭证由门户下发（URL 参数 {@code userToken}，SM4 密文），应用侧不再提供
 * 「换取令牌」的接口，因此这里只保留两个查询/收尾用的端点：
 *
 * <ul>
 *   <li>{@code GET  /api/auth/me} —— 返回当前登录用户（前端可用它探测凭证是否仍然有效）；</li>
 *   <li>{@code POST /api/auth/logout} —— 无状态凭证，服务端无副作用（前端清掉本地副本即可）。</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthProperties props;

    private final UserTokenService tokens;

    public AuthController(AuthProperties props, UserTokenService tokens) {
        this.props = props;
        this.tokens = tokens;
    }

    /** 当前登录用户（需鉴权） */
    @GetMapping("/me")
    public ApiResponse<Map<String, Object>> me() {
        LoginUser user = UserContext.get();
        if (user == null) {
            // 仅当 ok.auth.enabled=false（放行模式）时会走到这里：回落到调试用户，保证前端可用
            user = tokens.localUser();
        }
        return ApiResponse.ok(user.toMap());
    }

    /** 注销（需鉴权）：凭证为无状态密文，服务端无需额外处理 */
    @PostMapping("/logout")
    public ApiResponse<Void> logout() {
        return ApiResponse.ok();
    }

    /** 前端启动时读取的鉴权约定（参数名等），避免前后端各维护一份 */
    @GetMapping("/config")
    public ApiResponse<Map<String, Object>> config() {
        Map<String, Object> data = new java.util.LinkedHashMap<>();
        data.put("param", props.getParam());
        data.put("enabled", props.isEnabled());
        return ApiResponse.ok(data);
    }
}
