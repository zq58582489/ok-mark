package com.ok.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ok.common.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 接口鉴权拦截器：所有受保护路径（默认 {@code /api/**}）在此统一校验用户凭证。
 *
 * <p>凭证来源：<b>URL 查询参数 {@code userToken}</b>（门户打开页面时拼在地址上，
 * 前端后续每个后台请求都会带上同名参数）。
 *
 * <p>校验过程：取出 {@code userToken} → {@link UserTokenService} 用 SM4 解密 → 得到用户信息
 * （工号 / 姓名 / 部门）→ 写入 {@link UserContext} 供业务使用。
 *
 * <p>失败统一返回 {@code HTTP 401 + {"code":401,"message":"...","data":null}}，
 * 前端 {@code static/js/auth.js} 识别后走统一失败处理入口。
 *
 * <p>{@code ok.auth.enabled=false} 时不校验（仅本地排查问题用，仍装配 mock 测试用户）；
 * {@code ok.auth.mode=mock} 时不校验凭证、固定返回测试用户（本地开发用）。
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(AuthInterceptor.class);

    private final AuthProperties props;

    private final UserTokenService tokens;

    private final ObjectMapper mapper;

    public AuthInterceptor(AuthProperties props, UserTokenService tokens, ObjectMapper mapper) {
        this.props = props;
        this.tokens = tokens;
        this.mapper = mapper;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!props.isEnabled()) {
            // 鉴权关闭（仅本地排查问题）：不校验凭证，但装配一个调试用户，
            // 否则业务层（用户信息、Dify 会话归属）拿不到当前用户
            UserContext.set(tokens.localUser());
            return true;
        }
        // 跨域预检直接放行（预检请求不携带业务参数）
        if (HttpMethod.OPTIONS.matches(request.getMethod())) {
            return true;
        }
        String token = resolveToken(request);
        // 凭证在 URL 上，任何中间代理 / WebView 都不应缓存接口响应（避免跨用户串数据）
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-store");
        try {
            UserContext.set(tokens.verify(token));
            return true;
        } catch (AuthException e) {
            log.debug("鉴权失败 {} {} → {}", request.getMethod(), request.getRequestURI(), e.getMessage());
            writeUnauthorized(response, e);
            return false;
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        // 线程复用，务必清理，避免上下文串到下一个请求
        UserContext.clear();
    }

    /** 取凭证：查询参数优先（门户约定的 userToken），配置了 header 时再兼容请求头 */
    private String resolveToken(HttpServletRequest request) {
        String raw = request.getParameter(props.getParam());
        if (isBlank(raw) && !isBlank(props.getHeader())) {
            raw = request.getHeader(props.getHeader());
            if (isBlank(raw)) {
                raw = request.getHeader("X-Token");
            }
            if (!isBlank(raw)) {
                String value = raw.trim();
                String prefix = props.getPrefix();
                if (!isBlank(prefix) && value.length() >= prefix.length()
                        && value.regionMatches(true, 0, prefix, 0, prefix.length())) {
                    value = value.substring(prefix.length()).trim();
                }
                return value;
            }
        }
        return isBlank(raw) ? null : raw.trim();
    }

    private void writeUnauthorized(HttpServletResponse response, AuthException e) throws IOException {
        int code = e.getCode();
        HttpStatus status = code == 403 ? HttpStatus.FORBIDDEN : HttpStatus.UNAUTHORIZED;
        response.setStatus(status.value());
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-store");
        mapper.writeValue(response.getWriter(), new ApiResponse<>(code, e.getMessage(), null));
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
