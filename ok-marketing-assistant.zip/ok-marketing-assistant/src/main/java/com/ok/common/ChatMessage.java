package com.ok.common;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map;

/**
 * 聊天消息实体（通用消息载体）
 * msgType 决定前端渲染哪种卡片，payload 为该卡片所需数据
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatMessage {

    public static final String FROM_USER = "user";
    public static final String FROM_BOT = "bot";

    public static final String TYPE_TEXT = "TEXT";                    // 纯文本
    public static final String TYPE_COMPANY_LIST = "COMPANY_LIST";    // 企业搜索结果
    public static final String TYPE_ANALYSIS = "ANALYSIS";            // 企业四段分析
    public static final String TYPE_INDUSTRY_PROFILE = "INDUSTRY_PROFILE"; // 行业画像卡
    public static final String TYPE_BIZ_PROFILE = "BIZ_PROFILE";      // 业务画像卡
    public static final String TYPE_OPPORTUNITY = "OPPORTUNITY";      // 商机线索卡
    public static final String TYPE_SCRIPT = "SCRIPT";                // 营销话术卡
    public static final String TYPE_TASK_GROUPS = "TASK_GROUPS";      // 今日任务分组
    public static final String TYPE_TASK_FLOW = "TASK_FLOW";          // 触达任务+流程图
    public static final String TYPE_MENU_GRID = "MENU_GRID";          // 菜单查找宫格
    public static final String TYPE_REPORT_ANALYSIS = "REPORT_ANALYSIS"; // 报表分析
    public static final String TYPE_REPORT_IMAGES = "REPORT_IMAGES";  // 报表图片(用户上传)

    private String id;
    private String conversationId;
    private String from;          // user / bot
    private String msgType;       // TYPE_*
    private String extType;       // Chatflow 声明的原始 type（text / company_list …），便于排查与扩展
    private String operateType;   // 该消息所属底部菜单（菜单查找 / 今日任务 / 营销助手）
    private String content;       // 纯文本内容（TEXT 或卡片标题等）
    private Map<String, Object> payload; // 卡片结构化数据
    private List<String> chips;   // 消息下方推荐选项
    private String deepQuestion;  // “您需要对上面的哪一部分内容进行深入？”提示语
    /**
     * 卡片附加数据（通用）：Chatflow 应答里可选的 {@code extra_data} 原样透传给前端。
     * 卡片内点击（企业名称、chips、条目等）发送消息时，前端会把它随用户输入一起回传，
     * 后端再包进 query 信封带给了 Chatflow（见 {@code QueryPayload}）。
     * 类型任意（对象 / 数组 / 数字 / 布尔 / 字符串）：字符串仅在以 {@code {} 或 [} 开头时按 JSON 解析，
     * 其余一律原样透传 —— 空值（null / 空串 / 空对象 / 空集合）才视为「无附加数据」。
     */
    private Object extraData;
    /** 用户消息携带的附件（仅用户消息）：{id, name, size, kind}，kind = image / document */
    private List<Map<String, Object>> files;
    private Long createTime;

    public ChatMessage() {
    }

    public ChatMessage(String from, String msgType, String content) {
        this.from = from;
        this.msgType = msgType;
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getExtType() {
        return extType;
    }

    public void setExtType(String extType) {
        this.extType = extType;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Map<String, Object> getPayload() {
        return payload;
    }

    public void setPayload(Map<String, Object> payload) {
        this.payload = payload;
    }

    public List<String> getChips() {
        return chips;
    }

    public void setChips(List<String> chips) {
        this.chips = chips;
    }

    public String getDeepQuestion() {
        return deepQuestion;
    }

    public void setDeepQuestion(String deepQuestion) {
        this.deepQuestion = deepQuestion;
    }

    public Object getExtraData() {
        return extraData;
    }

    public void setExtraData(Object extraData) {
        this.extraData = extraData;
    }

    public List<Map<String, Object>> getFiles() {
        return files;
    }

    public void setFiles(List<Map<String, Object>> files) {
        this.files = files;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}
