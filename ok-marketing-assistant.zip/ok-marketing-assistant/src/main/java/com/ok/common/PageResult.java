package com.ok.common;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

/**
 * 通用分页结果（侧滑「最近会话」等列表型接口）。
 *
 * <p>分页语义：前端首屏只取第一页（默认 {@code ok.assistant.conversation-page-size} 条），
 * 点「更多」时带上 {@code offset = 已加载条数} 再取下一页。
 * 检索（keyword）一律由服务端完成，前端只回显结果，不再对已加载列表做本地过滤。
 *
 * @param <T> 列表元素类型
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PageResult<T> {

    /** 本页数据 */
    private List<T> list = new ArrayList<>();

    /**
     * 后端本次「扫描范围内」命中的条数。
     * 会话列表由平台侧游标翻页 + 服务端过滤得出，故这里是扫描窗口内的命中数，不是平台全量总数。
     */
    private int total;

    /** 本页起始偏移（回显请求值） */
    private int offset;

    /** 本页条数（回显请求值） */
    private int limit;

    /** 是否还有下一页（前端据此显示/隐藏「更多」） */
    private boolean hasMore;

    public PageResult() {
    }

    public PageResult(List<T> list, int total, int offset, int limit, boolean hasMore) {
        this.list = list == null ? new ArrayList<>() : list;
        this.total = total;
        this.offset = offset;
        this.limit = limit;
        this.hasMore = hasMore;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
}
