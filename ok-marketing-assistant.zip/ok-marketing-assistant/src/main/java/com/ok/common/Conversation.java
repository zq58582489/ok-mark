package com.ok.common;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 会话（侧滑菜单-最近列表）
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Conversation {

    public static final String ICON_BLUE = "blue";
    public static final String ICON_YELLOW = "yellow";
    public static final String ICON_GREEN = "green";

    private String id;
    private String title;
    private String icon = ICON_BLUE; // 蓝色/黄色/绿色会话标
    private String operateType;      // 会话所属底部菜单（菜单查找 / 今日任务 / 营销助手），前端据此默认选中菜单
    private Long createTime;
    private Long updateTime;

    public Conversation() {
    }

    public Conversation(String id, String title, String icon, Long createTime) {
        this.id = id;
        this.title = title;
        this.icon = icon;
        this.createTime = createTime;
        this.updateTime = createTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
}
