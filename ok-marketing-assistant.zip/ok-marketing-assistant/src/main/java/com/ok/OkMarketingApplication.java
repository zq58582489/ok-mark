package com.ok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * OK营销助手 —— 单体应用启动类
 *
 * <p>一个 jar 同时提供：</p>
 * <ul>
 *     <li>移动端 H5 静态前端（classpath:/static，Vue 2 本地引用，无前端构建）</li>
 *     <li>全部 REST 接口：/api/chat/**、/api/customer/**、/api/task/**</li>
 * </ul>
 *
 * <p>原 Spring Cloud 微服务（Eureka 注册中心 / Gateway 网关 / Feign 远程调用）已合并进本进程，
 * 服务间调用由 Feign HTTP 调用改为本地 Spring Bean 直调，无需再启动任何外部依赖。</p>
 *
 * <p>启动：java -jar ok-marketing-assistant.jar [--server.port=9000]</p>
 */
@SpringBootApplication
public class OkMarketingApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(OkMarketingApplication.class, args);
    }
}
