@echo off
chcp 65001 >nul
rem ============================================================
rem  OK营销助手 —— 单体应用启动脚本（一个 jar 起全部功能）
rem  用法: start.bat [端口]   默认 9000
rem  访问: http://127.0.0.1:9000/
rem ============================================================
setlocal
set PORT=%1
if "%PORT%"=="" set PORT=9000

if not exist "%~dp0target\ok-marketing-assistant.jar" (
    echo [ERROR] 未找到 target\ok-marketing-assistant.jar，请先执行: mvn clean package
    pause
    exit /b 1
)

echo Starting OK Marketing Assistant on port %PORT% ...
java -jar "%~dp0target\ok-marketing-assistant.jar" --server.port=%PORT%
endlocal
