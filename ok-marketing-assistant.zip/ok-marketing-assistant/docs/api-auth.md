# 接口鉴权（userToken + SM4）

> 约定：**门户下发凭证 → 前端每个请求都带上 → 后端 SM4 解密取用户信息 → 失败统一 401**。
> 应用不再自签令牌，也不再提供「换取 token」的接口。

---

## 1. 链路总览

```
门户 App / 浏览器                       本应用
  │ 打开页面 ?userToken=<SM4 密文>        ┌────────────────────────────┐
  ├──────────────────────────────────────▶│ index.html + js/auth.js    │ 抓取并缓存 userToken
  │                                       └────────────────────────────┘
  │ ① 每个后台请求：/api/xxx?userToken=…
  ├──────────────────────────────────────▶┌────────────────────────────┐
  │                                       │ AuthInterceptor            │
  │                                       │  ├─ UserTokenService       │ Base64 → SM4 解密 → JSON
  │                                       │  │    → 工号/姓名/部门      │ → 写入 UserContext
  │                                       │  └─ 失败 → 401 code:401    │
  │ ◀──── {"code":0,...} ─────────────────┤                            │
  │ ◀──── 401 {"code":401,"message":…} ───┤                            │
  └─ 401 时由 OKAuth.onAuthFail 统一提示（容器内可回门户重新登录）
```

- 受保护范围：`ok.auth.include-paths`（默认 `/api/**`）
- 免鉴权：`ok.auth.whitelist`（默认**空**）+ 全部静态资源（页面、js/css/图片）
- 接口响应统一加 `Cache-Control: no-store`：凭证在 URL 上，避免代理 / WebView 缓存造成串数据

---

## 2. 配置：只需要一个密钥

```yaml
ok:
  auth:
    sm4:
      key: ${OK_AUTH_SM4_KEY:56896765E334464SD5343396A7215B35}
```

其余全部写在代码默认值里，**不需要出现在 yml**：

| 配置 | 默认值 | 何时才需要改 |
|---|---|---|
| `param` | `userToken` | 门户换了参数名 |
| `enabled` | `true` | 本地排查时 `OK_AUTH_ENABLED=false`（全部放行，用户固定为「本地调试」） |
| `key-format` | `auto` | 密钥不是 hex/ascii 混写时才用（`hex` / `ascii` / `base64`） |
| `mode` | `ecb` | 门户改用 CBC 时 |
| `iv` / `iv-format` | 空 / `auto` | 仅 CBC 使用；留空 = 16 字节全 0 |
| `padding` | `pkcs7` | 等价 Java 的 PKCS5Padding；也可能是 `none` / `zero` |
| `charset` | `UTF-8` | 明文是 GBK 时（一般会自动识别，见 §2.1） |
| `debug` | `false` | 排查「解出来是乱码」时临时打开 |
| `self-test-token` | 空 | 想启动即验证时填一段真实 userToken |

> 这些都能直接用环境变量覆盖（`OK_AUTH_SM4_MODE=cbc` 等），容器里改配置不必重建镜像。

> ### 密钥必须按平台工具类的规则解析（**关键**）
>
> 平台的 `SM4Utils` 用 `Util.hexStringToBytes`，其实现是：
>
> ```java
> public static byte charToByte(char c) { return (byte) "0123456789ABCDEF".indexOf(c); }
> d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
> ```
>
> 遇到非十六进制字符时 `indexOf` 返回 **`-1`，不报错**，并直接参与位运算再截断成字节。
> 默认密钥里的 `S`（`56896765E334464` **`S`** `D5343396A7215B35`，第 8 字节）因此变成
> `(4 << 4) | -1 = -1` → **`0xFF`**，实际密钥为：
>
> ```
> 56896765 e33446ff d5343396 a7215b35
> ```
>
> 若按标准十六进制解析（遇到 `S` 报错 / 丢弃），这段密文永远解不出来 —— 加密方自己验得通，
> 本服务却只能得到随机字节。所以本服务的 hex 解析**逐字对齐**该工具类语义
> （`Sm4Cipher.hexToBytesCompat`），启动日志会打一条 WARN 说明「按工具类规则解析」并给出实际字节。
>
> 该兼容同时适用于 `key` 与 `iv`。

> **`auto` 的判断规则**：长度为偶数且 **至少 3/4 的字符**是 `0-9A-Fa-f` → 按 hex 解析；
> 否则按原文取前 16 字节。不能要求 100% 合法 —— 上面这个密钥就混着 `S`，
> 一旦判成 ascii 会把 32 字符截成前 16 字符，结果同样错。

解密后的明文按 **JSON** 解析（也兼容 `k=v&k=v`），再按别名表取用户字段（忽略大小写与 `_`/`-`）：

| 字段 | 别名（节选） |
|---|---|
| 工号 | **`psnscode`** / `psncode` / `psnNo` / `userId` / `gh` / `jobNo` / `empNo` / `account` / `工号` … |
| 姓名 | **`psnname`** / `userName` / `name` / `realName` / `xm` / `姓名` … |
| 部门 | **`deptshortname`** / `deptName` / `dept` / `orgName` / `bmmc` / `rldpcode` / `部门` … |
| 过期时间（可选） | `exp` / `expireTime` / `validTo` …（秒或毫秒都兼容） |

门户实际下发的明文形如（秦农人力口径）：

```json
{"deptshortname":"乘航支行","rldpcode":"050087","psnscode":"78011359","psnname":"褚兰星"}
```

明文可以是根对象，也可以包在 `data` / `user` / `userInfo` / `result` / `body` 里。
字段名特殊时，在 `UserTokenService` 的别名数组里补一条即可。

**真实环境校准**（不必等页面报错）：

```bash
OK_AUTH_SM4_SELFTEST_TOKEN='<一段真实 userToken>' java -jar target/ok-marketing-assistant.jar
# 日志：SM4 自检通过：userId=10086 name=李四 dept=公司金融部
# 或  ：SM4 自检失败：用户凭证内容解析失败（提示核对 key/mode/iv/padding）
```

---

## 2.1 解出来是乱码？先分清是「三种乱码」

`debug` 打开后（`OK_AUTH_SM4_DEBUG=true`），每次解析都会写
`<java.io.tmpdir>/ok-auth-last-token.txt`（UTF-8，直接双击打开），日志里同时打印密文/明文的 **hex**。
hex 是纯 ASCII，**不受 Windows 控制台编码影响**，是最可靠的判断依据。

| 现象 | 说明 | 处理 |
|---|---|---|
| 文件里中文正常，只是控制台显示成 `鐢ㄦ埛` 之类 | 纯显示问题：JVM 的 `file.encoding` 与控制台代码页不一致 | 不用改代码；看文件或 hex 即可，或 `chcp 65001` + `-Dfile.encoding=UTF-8` 保持一致 |
| 「按 UTF-8 解码」出现 `����`，但「按 GB18030 解码」是正常 JSON | 加密方用的是 GBK/GB18030（Windows 上 Java `getBytes()` 的默认字符集） | **已自动兼容**：解出替换符时会自动改用 GB18030。想固定就配 `OK_AUTH_SM4_CHARSET=GB18030` |
| 两种字符集都解不出可读文本（结论会明确写出来） | 密钥 / 模式 / IV / 填充与加密方不一致，或密文被截断/转义过 | 按 §2 逐项核对；`hex` 里的明文看起来像随机字节就是这一类 |

几个实现细节：

- **不要用 `System.out.println(plain)` 排查**：控制台编码会二次破坏显示，而且日志级别改不了；
  调试开关会把结果落到 UTF-8 文件，内容与 hex 一一对应。
- 解密结果**不是 JSON 也不是 `k=v` 串**时，直接按 401 处理并给出可读原因（不再用哈希兜底静默放行），
  避免「密钥配错 → 每个用户都变成随机工号」这种隐性故障。
- 启动自检（`OK_AUTH_SM4_SELFTEST_TOKEN`）失败时会自动打印完整诊断，不用等页面报错。

---

## 3. 后端组件

| 类 | 职责 |
|---|---|
| `com.ok.auth.sm4.Sm4` | 纯 Java SM4 分组算法（无第三方依赖，与 OpenSSL/BouncyCastle 结果一致） |
| `com.ok.auth.sm4.Sm4Cipher` | ECB/CBC、PKCS7/NONE/ZERO、hex/ascii/base64 解析 |
| `com.ok.auth.UserTokenService` | Base64 → 解密 → JSON → 用户字段映射 / 过期校验 / 启动自检 |
| `com.ok.auth.AuthInterceptor` | 取 `userToken` → 校验 → 写入 `UserContext`；失败 401 |
| `com.ok.auth.AuthWebConfig` | 注册拦截器（含白名单） |
| `com.ok.auth.AuthController` | `GET /api/auth/me`、`POST /api/auth/logout`、`GET /api/auth/config` |
| `com.ok.auth.UserContext` | 当前登录用户（ThreadLocal），业务取用户统一走这里 |

> **用户信息的唯一来源是 `userToken`**：`application.yml` 里没有任何用户信息（没有 `user-name / user-id / user-dept`，也没有 mock 用户）。
> `GET /api/chat/profile` 的 `name / userId / dept`、以及发给 Dify 的 `user` 参数，全部取自 `UserContext`。
> 唯一例外是本地排查：`OK_AUTH_ENABLED=false` 时放行并把用户固定为「本地调试」，**不要在生产这么配**。

---

## 4. 接口清单

| 方法 | 路径 | 鉴权 | 说明 |
|---|---|---|---|
| GET | `/api/auth/me` | 需 | 当前登录用户 |
| POST | `/api/auth/logout` | 需 | 无状态凭证，服务端无副作用 |
| GET | `/api/auth/config` | 需 | 返回参数名与是否启用（排查用） |

失败响应：

```json
HTTP/1.1 401
Cache-Control: no-store
{"code":401,"message":"缺少用户凭证（userToken），请从门户重新进入","data":null}
```

常见 message：
- `缺少用户凭证（userToken），请从门户重新进入`
- `用户凭证解析失败，请从门户重新进入`（Base64 / 长度 / 解密失败）
- `用户凭证内容解析失败，请从门户重新进入`（解密成功但不是 JSON）
- `用户凭证已过期，请从门户重新进入`（明文里带 exp 且已过期）

---

## 5. 前端（`static/js/auth.js`，须在 `app.js` 之前引入）

| 方法 | 说明 |
|---|---|
| `OKAuth.token()` / `hasToken()` | 当前 userToken（没有时为空串 / false） |
| `OKAuth.setToken(t)` / `clearToken()` | 运行时替换 / 清除凭证 |
| `OKAuth.request(method, url, {body})` | 统一请求封装：自动在 URL 上拼 `userToken`；`code===0` 直接返回 `data`；401 时触发统一失败入口 |
| `OKAuth.withToken(url)` | 给直链（图片预览 / 附件下载）拼 userToken；跨域地址不拼 |
| `OKAuth.onAuthFail(fn)` | 401 统一处理入口，`fn({code,message,url,handled})` |

抓取规则：
1. 优先取地址栏 `?userToken=`（含 hash 里的查询串），存入 `sessionStorage`；
2. 刷新 / 站内跳转沿用缓存；
3. 手动解析查询串（不用 `URLSearchParams`）——它会把 Base64 里的 `+` 当空格，导致密文损坏。

业务代码无需改动：`app.js` 里的 `http()` 就是 `OKAuth.request` 的薄封装。

### 5.1 附件直链

`<img src>`、`<a download>` 由浏览器直接发起，同样靠查询参数：

```
/api/chat/files/F1?cid=C1&download=1&userToken=<密文>
```

（`fileUrl()` / `loadDocPreview()` 已统一走 `OKAuth.withToken()`。）

---

## 6. 与原「自签令牌」方案的差异

| 项 | 旧 | 新 |
|---|---|---|
| 凭证来源 | 前端调 `/api/auth/token` 换取 | 门户拼在 URL 上（`?userToken=`） |
| 携带方式 | `Authorization: Bearer …` 请求头 + 直链 query | **统一 URL 查询参数**（所有请求） |
| 校验方式 | HMAC-SHA256 自签令牌 | SM4 解密取用户信息 |
| 白名单 | `/api/auth/token` | 无（所有接口都要凭证） |
| 失效处理 | 静默重取令牌 + 重试一次 | 直接 401 + 统一提示（凭证只能由门户补发） |
| 本地联调 | 默认 `mode=mock` 自签 | `OK_AUTH_ENABLED=false`（放行，用户固定为「本地调试」） |

---

## 7. 验证

| 脚本 | 覆盖 |
|---|---|
| `D:\tmp\probe\auth-sm4-jsbridge-verify.js` | 26 项：URL 抓取、所有 `/api` 请求带 userToken、不再发 Authorization、解密用户信息进页面、附件直链带凭证、openNativePage 参数结构、无凭证 401 提示、桌面降级 |
| 手工（curl） | 无凭证 401 / 正确凭证 200 / 篡改末位 401 / 静态资源 200；`hex + cbc + iv`（环境变量覆盖）与默认配置各验一次 |

**2026-10-20 真样例实测**（平台 `SM4Utils` 加密的那段密文，112 字节 / 7 块）：

```
启动日志：ok.auth.sm4.key 含非十六进制字符 'S'，已按平台 SM4Utils 规则解析，实际密钥 = 56896765e33446ffd5343396a7215b35
         SM4 自检通过：userId=78011359 name=褚兰星 dept=乘航支行

GET /api/chat/profile?userToken=<密文>            → 200 {"name":"褚兰星","userId":"78011359","dept":"乘航支行"}
GET /api/chat/profile                             → 401 缺少用户凭证
GET /api/chat/profile?userToken=<首 4 字符改掉>   → 401 解密后内容不可识别
GET /api/chat/profile?userToken=<原样未编码>      → 200（`+` 被解成空格后自动还原）
```

复现方式（不把凭证写进配置文件）：

```bash
OK_AUTH_SM4_SELFTEST_TOKEN='<一段真实 userToken>' java -jar target/ok-marketing-assistant.jar --server.port=9201
```
