# 前端调试面板（真机排查用）

门户 App 的 WebView 里没有控制台，看不到 `console` 输出、JS 异常和容器能力。
应用内置一个悬浮「调试」入口，用来在**真机 / 内嵌容器**里看环境、凭证和日志。

---

## 1. 开关：两级控制，缺一不可见

| 层级 | 位置 | 默认 | 作用 |
|---|---|---|---|
| 后端总开关 | `ok.assistant.debug-enabled`（环境变量 `OK_DEBUG_ENABLED`） | **`false`** | 关闭时前端 `js/debug.js` 直接返回：不建 DOM、不拦截 `console`，页面与生产完全一致 |
| 单设备开关 | 面板标题栏「隐藏入口」→ `localStorage.ok_debug_hidden` | 未设置（=显示） | 总开关打开后，各设备可自行隐藏；地址带 `?debug=1` 可强制呼出（并清掉该标记） |

后端值经 `GET /api/chat/profile` 的 `debug.enabled` 下发：

```json
{ "debug": { "enabled": true } }
```

- **配置拿不到一律当关闭**（接口 401 / 加载失败 / `OK_DEBUG_ENABLED` 未设置），
  生产环境不会因为一次异常而把调试入口暴露给最终用户；
- `?debug=1` **不能**绕过后端总开关，它只解决「本机点过隐藏」这一种情况。

打开方式（任选其一）：

```bash
# 本地：启动参数 / 环境变量
java -jar ok-marketing-assistant.jar --server.port=9000 --ok.assistant.debug-enabled=true
OK_DEBUG_ENABLED=true java -jar ok-marketing-assistant.jar

# Docker：.env 里加一行后重启容器
OK_DEBUG_ENABLED=true
```

---

## 2. 面板里能看什么

| 区块 | 内容 |
|---|---|
| 环境 | 当前地址、视口与 DPR、容器判定（`iOS / Android`）、`$JSBridge.canInvoke('selectPicture')`、`canInvoke('openNativePage')`、完整 UA |
| 凭证 | 当前 `userToken`（脱敏显示首 12 位 + 末 6 位 + 总长度），「复制凭证」拿全量，用于在 PC 上复现真机问题 |
| 日志 | 拦截 `console.log/info/warn/error` + 未捕获异常（`error` / `unhandledrejection`），最多保留 200 条，带时间与级别 |
| 操作 | 复制日志、清空、刷新、复制凭证 |

典型用法：

1. 真机上打开页面 → 点「调试」；
2. 若 `selectPicture` 显示 **不可用**，说明外层容器没注册这个方法（或页面不在门户容器里打开），
   此时拍照 / 相册上传会退化成浏览器 `input[type=file]`；
3. 上传失败 → 看日志区里的接口返回，并把「复制凭证」拿到的 `userToken` 交给后端在 PC 上复现；
4. 排查完点标题栏「隐藏入口」，这台设备之后就不再出现入口（不影响其他人）。

---

## 3. 实现要点

- `js/debug.js` 是独立 IIFE，与 Vue 无耦合；`app.js` 拿到 `/api/chat/profile` 后
  把配置发布到 `window.OK_DEBUG_CFG` 并派发 `ok:profile` 事件，两条路径保证先加载 / 后加载都能拿到；
- 面板与悬浮球样式都在 `css/app.css` 的 `.okdbg-*` 段，`z-index` 9998/9999，高于页面弹层；
- 日志只存在内存里，刷新即清空 —— 不落 `localStorage`，避免占空间和残留敏感信息；
- 复制优先用 `navigator.clipboard`，`http` 页面或老 WebView 自动退回临时 `textarea` + `execCommand`。

---

## 4. 注意

- **生产保持 `OK_DEBUG_ENABLED=false`**：面板会显示 `userToken`（脱敏）并能导出日志，
  属于内部排障工具；
- 面板里的「刷新」是整页重载，未发送的附件草稿会丢失。
