# OK营销助手 · Chatflow 应答协议与模板清单

> 适用版本：`ok-marketing-assistant` 单体应用 + Dify 1.17.1 Chatflow
> 约定：Chatflow 的 `answer` 字段输出一个 **JSON 对象**，应用侧解析后决定「用哪个模板渲染 + 展示什么文案」。
> 对应实现：`com.ok.chat.service.DifyAnswerResolver`（协议解析）、`static/index.html`（渲染模板）

---

## 一、协议总则

### 1.1 输出形态

`answer` 必须是**一个 JSON 对象**（字符串形式），例如：

```json
{"operatetype":"菜单查找","type":"text","content":"正在查找菜单"}
```

### 1.2 三个核心字段

| 字段 | 必填 | 说明 |
|---|---|---|
| `type` | 是 | **渲染模板标识**，决定前端用哪种卡片渲染。约定小写下划线风格（`text` / `company_list` / `task_flow` …）。前端未实现该模板时，退化为只显示 `content` 文本，不会报错 |
| `content` | 是 | 直接展示给用户的文本。**所有模板都会先渲染这段文本**，卡片叠加在它下方 |
| `operatetype` | 否 | 该轮所属底部菜单：`菜单查找` / `今日任务` / `营销助手`。历史会话回看时据此自动选中对应菜单；建议始终回填 |

### 1.3 payload 规则（关键）

**除保留字段外，其余字段会被整体收集成 `payload` 交给模板使用。**
也就是说：模板要用的数据**平铺在 JSON 顶层**，不要自己再包一层 `payload`。

- 保留字段（不进入 payload，有专门用途）：`type`、`content`、`operatetype`、`chips`、`deepQuestion`（兼容写法 `deep_question`）、`extra_data`（兼容写法 `extraData`，见 §1.7）
- 其余字段 → `payload`，前端通过 `msg.payload.xxx` 取用

> 平铺规则只作用于**顶层**：`sections` / `list` / `groups` 这类数组字段整体进 payload，其**元素内部的字段原样保留**（例如 `sections[].linkText` 会原封不动传到前端）。

### 1.4 两个通用可选字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `chips` | string[] | 消息下方的**底部选项**。可写成数组，也兼容逗号分隔的字符串 |
| `deepQuestion` | string | 选项上方的提示语。单独出现时不渲染；与 `chips` 搭配呈现为「提示语 + 选项行」。仅有 `chips` 时渲染为「无提示语的选项行」 |

> **`chips` 的定位（重要）**：只用于**互斥 / 单选类**的后续动作——例如触达任务卡片的「1、营销话术 / 2、规划出行路线」，用户点一个、走一条路。
> **不要再用 `chips` 承载「分段图文里每一段的详情入口」**：那类需求请改用**小节标题右侧的链接**（`sections[].linkText`，见 §3.3），视觉上贴在该段标题后，语义上就是这个段落的「全部」入口。

```json
{
  "type": "analysis",
  "content": "我对江苏国泰国际集团进行搜索得到信息如下：",
  "sections": [
    {"title": "1. 行业类型", "body": "江苏国泰是**“供应链服务 + 化工新能源” 双主业**模式",
     "linkText": "全部", "linkQuery": "1. 行业类型"}
  ]
}
```

### 1.5 容错行为

| 情况 | 处理 |
|---|---|
| `answer` 不是 JSON | 整段按纯文本消息展示 |
| 是 JSON，但既无 `type` 也无 `content` | 整段按纯文本展示（避免把无关 JSON 当协议） |
| `type` 是前端未实现的模板 | 只展示 `content`，不渲染卡片 |
| 某模板必填字段缺失 | 对应区块渲染为空，不报错（建议按本文样例给全） |

### 1.6 文本内支持的轻量标记

`content` 与 `analysis` / `report_analysis` 的 `body` 支持：

- `**文字**` → 加粗
- `\n` → 换行

### 1.7 `extra_data` · 卡片附加数据（通用，任意模板可用）

**场景**：卡片里给用户看的是「企业名称」，但后台检索需要「统一社会信用代码」这类**不该直接展示、也不适合当用户输入**的参数。

**做法**：在卡片的应答 JSON 里加一个可选的 `extra_data`（任意 JSON：对象 / 数组 / 字符串），应用侧不解析它的内容、原样保存。用户点击卡片元素（企业名称、`chips`、条目…）时：

```
用户消息气泡显示  →  content      （用户可见的输入，如「国泰航空有限公司」）
传给 Chatflow 的 query →  {"userinput":"国泰航空有限公司","extra_data":{"creditCode":"91320100MA1X2K3P7L"}}
```

即 query 是一个 **JSON 字符串信封**，两个键固定为：

| 键 | 说明 |
|---|---|
| `userinput` | 用户可见的输入文本。会话标题、历史回看的气泡都用它（不会被 JSON 污染） |
| `extra_data` | 卡片附加数据，原样带回；**始终存在** —— 没有附加数据时为空对象 `{}`，Chatflow 侧无需判空、一套 JSON 解析通吃 |

**所有类型的对话都走这个信封**（默认 `query-format=always`）：文本输入、快捷菜单、卡片点击、带附件的消息，`query` 一律是上面的 JSON 字符串：

```json
{"userinput":"国泰航空有限公司","extra_data":{"creditCode":"91320100MA1X2K3P7L"}}   ← 卡片点击（带附加数据）
{"userinput":"菜单在哪","extra_data":{}}                                        ← 普通输入（无附加数据）
```

Chatflow 侧在开始节点/代码节点按 `userinput`（展示与意图）与 `extra_data`（精确检索参数）取值即可。走 `query` 而不是单独的输入变量，是因为 **Dify 会持久化 `query`**：附加数据因此能随会话历史一起回看，历史里再点一次卡片仍然带得上。

> 会话标题由应用侧按 `userinput` 调用 Dify 的 rename 设置，所以标题里不会出现 JSON 片段。

**会话列表标题（同样拆包，兜住历史数据）**

「最近会话」列表的标题来自 Dify 的会话名（`/v1/conversations` 的 `name`）—— 而 Dify 自动命名会
**直接取首轮 query 的前若干字符**，query 是信封 JSON 时标题就成了 JSON 原文（应用 rename 之前的
老会话、rename 失败的会话都会这样）。因此应用在列表接口统一拆包：

| 环节 | 行为 |
|---|---|
| 列表标题 | 取 `name` 后过一遍 `QueryPayload.userInput()`：信封 → 只显示 `userinput`；**信封被截断**（如 `{"userinput":"江苏国泰","extra_`）→ 正则兜底抠出 `userinput`；普通文本 → 原样 |
| 抽屉内检索 | 关键词匹配基于**拆包后**的标题（避免用 JSON 里的附加数据误命中） |
| 新建会话 | rename 与响应里的 `conversation.title` 都用 `userinput`（截断到 12 字）|

> 只是**展示层**拆包，Dify 侧存的 `name` 原文不动 —— 应用不会去回写历史会话名。

**三个层级（都支持，逐层覆盖）**

| 层级 | 写法 | 用途 |
|---|---|---|
| 卡片级 | 顶层 `extra_data` | 该卡片所有点击共用的上下文 |
| 条目级 | `list[].extra_data` 等数组元素内 | 该条目专属的数据（如每家企业的信用代码），**覆盖**卡片级同名字段 |
| 调用点 | 前端事件里显式传入 | 特殊场景兜底，优先级最高 |

> 条目级与卡片级是**浅合并**（同名字段条目胜出），因此「卡片带租户、条目带信用代码」可以叠加；
> 若某个来源不是对象（字符串 / 数字 / 布尔 / 数组），则以**最后出现的那个来源**原样为准（后者覆盖前者）。

**取值规则（应用只做透传，不假设内容类型）**

`extra_data` 可以是**任意 JSON**，应用取到什么就传什么（前端 `parseExtra` 与后端 `QueryPayload.normalize` 两侧规则一致）：

| Chatflow 写的值 | 传给 Chatflow 的 `extra_data` |
|---|---|
| `{"creditCode":"9132…"}`（对象） | 原样对象 |
| `"{\"creditCode\":\"9132…\"}"`（以 `{` / `[` 开头的字符串） | 按 JSON 解开后的对象 |
| `"1"` / `"abc"`（普通字符串、不以 `{` 开头） | 原样字符串 `"1"` / `"abc"` |
| `1` / `true`（数字 / 布尔） | 原样标量 |
| `null` / `""` / `{}` / `[]`（空值） | 视为「无附加数据」→ 信封里是 `{}` |

> ⚠️ 要在 Chatflow 侧用 `extra_data.creditCode` 取值，请**直接写成对象**。写成字符串标量（如 `"1"`）应用也会原样传下去，
> 但下游拿到的是字符串，取不到键 —— 应用不会替你猜结构，也不会把它悄悄丢掉。

**配置项**（`application.yml` → `ok.assistant.dify`）

| 配置 | 默认 | 说明 |
|---|---|---|
| `query-format` | `always` | `always`=**所有类型的对话都包信封**（默认，Chatflow 侧一套 JSON 解析）；`auto`=本轮带 `extra_data` 才包，其余纯文本；`plain`=始终纯文本 |
| `input-extra-data` | 空 | 附加数据**另外**作为开始节点变量的变量名（留空 = 不传）。仅作兼容通道，主通道是 query 信封 |

**示例（企业搜索结果卡）**

```json
{
  "operatetype": "营销助手",
  "type": "company_list",
  "content": "帮您匹配到 10 条包含国泰的数据，您可以点击企业名称继续操作",
  "total": 10,
  "list": [
    {"index": 1, "name": "国泰航空有限公司", "city": "江苏南京", "status": "存续", "legalRep": "王*云",
     "extra_data": {"creditCode": "91320100MA1X2K3P7L"}},
    {"index": 2, "name": "江苏国泰国际集团", "city": "江苏张家港", "status": "存续", "legalRep": "王*云",
     "extra_data": {"creditCode": "91320582MA1XR4T58N"}}
  ]
}
```

点击第 2 条时，应用发出的是：

```json
{"conversation_id":"…","query":"{\"userinput\":\"江苏国泰国际集团\",\"extra_data\":{\"creditCode\":\"91320582MA1XR4T58N\"}}","inputs":{"operatetype":"营销助手"}}
```

> **后续卡片要接着用**：如果下一轮卡片上的点击还需要这份附加数据（如四段分析卡里的 `chips`），
> 请在那一轮的应答里**再带上** `extra_data`（可原样回抄）。应用只负责「卡片给什么就传什么」，
> 不做跨轮记忆——避免把 A 企业的信用代码带到 B 企业的查询上。


---

## 二、模板总览

| # | type | 渲染形态 | 引导线 | 点赞/复制 | 典型场景 |
|---|---|---|---|---|---|
| 1 | `text` | 纯文本气泡 | — | — | 普通对话、查询进行中提示 |
| 2 | `company_list` | 企业搜索结果列表 | ✅ | ✅ | 企业检索智能体 |
| 3 | `analysis` | 分段图文（段落标题带「全部」详情链接） | ✅ | ✅ | 企业四段分析、业务问答（固定资产贷款怎么做） |
| 4 | `report_analysis` | 分段图文（多段长文） | ✅ | ✅ | 报表交叉分析 |
| 5 | `industry_profile` | 行业画像卡（含 5 灯评级） | ✅ | ✅ | 企业检索 · 行业类型 |
| 6 | `biz_profile` | 业务画像卡（长卡片） | ✅ | ✅ | 企业检索 · 业务信息 |
| 7 | `opportunity` | 商机线索卡（分类页签） | ✅ | ✅（无复制） | 企业检索 · 商机线索 |
| 8 | `script` | 营销话术卡（场景页签） | ✅ | ✅ | 企业检索 · 营销话术 |
| 9 | `task_groups` | **待办检索结果**（任务分组折叠列表） | — | — | 今日任务 |
| 10 | `task_flow` | 业务流程图 + 生成结果 | ✅ | — | 分配触达任务 |
| 11 | `menu_grid` | **菜单检索结果**（功能宫格） | — | — | 菜单查找 |

> 「引导线」= 消息左侧的竖向蓝色引导条；「点赞/复制」= 消息下方反馈按钮行。

---

## 三、各模板字段与样例

### 1. `text` · 纯文本

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 展示文本 |

```json
{"operatetype":"菜单查找","type":"text","content":"正在查找菜单"}
```

```json
{"operatetype":"今日任务","type":"text","content":"正在查找今日任务"}
```

```json
{"operatetype":"营销助手","type":"text","content":"我是营销助手"}
```

---

### 2. `company_list` · 企业搜索结果

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 标题，如「帮您匹配到 10 条包含国泰的数据，您可以点击企业名称继续操作」 |
| `list[].index` | number | 是 | 卡片序号（1 开始） |
| `list[].name` | string | 是 | 企业名称 |
| `list[].city` | string | 是 | 所在地 |
| `list[].status` | string | 是 | 经营状态，如「存续」 |
| `list[].legalRep` | string | 是 | 法定代表人（脱敏），如「王*云」 |
| `more` | boolean | 否 | `true` 时在卡片下方提示「结果多于5条，未展示完全…」 |
| `total` | number | 否 | 命中总数（当前不渲染，建议回填便于后续扩展） |
| `list[].extra_data` | 任意 JSON | 否 | **该企业的附加数据**（通用字段，见 §1.7）。点击企业名称时随用户输入回传后台 —— 用户看到的仍是企业名称。推荐写成对象 `{"creditCode":"统一社会信用代码"}`；写成字符串标量也能原样传下去 |

```json
{
  "operatetype": "营销助手",
  "type": "company_list",
  "content": "帮您匹配到 10 条包含国泰的数据，您可以点击企业名称继续操作",
  "total": 10,
  "keyword": "国泰",
  "more": true,
  "list": [
    {"index": 1, "name": "国泰航空有限公司", "city": "江苏南京", "status": "存续", "legalRep": "王*云",
     "extra_data": {"creditCode": "91320100MA1X2K3P7L"}},
    {"index": 2, "name": "江苏国泰国际集团", "city": "江苏张家港", "status": "存续", "legalRep": "王*云",
     "extra_data": {"creditCode": "91320582MA1XR4T58N"}},
    {"index": 3, "name": "国泰海通证券股份有限公司", "city": "江苏张家港", "status": "存续", "legalRep": "王*云",
     "extra_data": {"creditCode": "91320582MA1X9B6W2F"}}
  ]
}
```

> 点击第 1 条时：用户气泡显示「国泰航空有限公司」，后台收到
> `query = {"userinput":"国泰航空有限公司","extra_data":{"creditCode":"91320100MA1X2K3P7L"}}`（见 §1.7）。
>
> **排查「点了企业但 `extra_data` 是 `{}`」**：① 该条（或卡片顶层）确实写了 `extra_data` 吗？
> ② 值是不是空值（`""`/`{}`/`[]`/`null`）？③ 值是不是**字符串标量**（如 `"1"`）—— 这类值现在会原样传下去
> （信封里是 `"extra_data":"1"`），若下游要 `extra_data.xxx` 取值，请改写成对象。字段要写在 `list[]` 元素内，
> 而不是 `list` 外面的卡片顶层（那就是卡片级，仅在条目级缺省时生效）。

---

### 3. `analysis` · 分段图文（企业四段分析 / 业务问答）

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 引言，如「我对江苏国泰国际集团进行搜索得到信息如下：」 |
| `sections[].title` | string | 是 | 小节标题 |
| `sections[].body` | string | 否 | 小节正文（支持 `**加粗**` / `\n`）；含附加列表的小节可置空 |
| `sections[].linkText` | string | 否 | **小节标题右侧的详情链接文案**（如 `全部`，前端渲染成「全部 ›」，始终与标题同行）。**不传则不渲染链接** |
| `sections[].linkQuery` | string | 否 | **预留字段**：接入真实跳转页面后作为该段的定位参数；缺省取 `title`。当前点击为本地占位跳转，不回传消息 |
| `opportunityTotal` | number | 否 | 当某小节标题**含「商机线索」**时渲染：「共检索到该企业存在 X 条商机线索」 |
| `opportunities` | string[] | 否 | 同上，商机名称列表 |
| `scopeItems` | string[] | 否 | 当某小节标题**含「适用范围」**时渲染为列表 |
| `scriptItems[].title` | string | 否 | 当某小节标题**含「营销话术」**时渲染其标题 |
| `scriptItems[].body` | string | 否 | 同上，正文 |

> **段落详情入口 = 标题右侧链接，不是底部选项**。四个小节各自代表「一段的详情」，入口用 `sections[].linkText` 贴在该段标题后（同行、蓝色小字、带 `›` 箭头，与标题样式明显区分）。**当前点击为本地「跳转」占位效果**（页面右侧滑入占位详情页，可返回），**不发送消息**；接入真实页面后由 `linkQuery` 定位目标。
> `chips` 在本模板**不再使用**（保留给互斥选择，见 §1.4）。`report_analysis` 段落是完整长文、没有详情跳转，因此**不给** `linkText`。

#### 3.1 企业四段分析（点击企业名称后返回）

```json
{
  "operatetype": "营销助手",
  "type": "analysis",
  "content": "我对江苏国泰国际集团进行搜索得到信息如下：",
  "opportunityTotal": 5,
  "opportunities": ["存量存款到期转化", "企业主个人财资管理", "待发工资资金留存", "外汇收汇资金留存", "专项资金承接营销"],
  "scriptItems": [
    {"title": "(1)、营销话术场景1", "body": "营销话术营销话术营销话术营销话术营销话术"},
    {"title": "(2)、营销话术场景2", "body": "营销话术营销话术营销话术营销话术营销话术"}
  ],
  "sections": [
    {"title": "1. 行业类型", "body": "江苏国泰是**“供应链服务 + 化工新能源” 双主业**模式",
     "linkText": "全部", "linkQuery": "1. 行业类型"},
    {"title": "2. 业务信息", "body": "江苏国泰是我行的存量客户，业务已经有对应的客户经理在维护",
     "linkText": "全部", "linkQuery": "2. 业务信息"},
    {"title": "3. 商机线索", "body": null,
     "linkText": "全部", "linkQuery": "3. 商机线索"},
    {"title": "4. 营销话术", "body": null,
     "linkText": "全部", "linkQuery": "4. 营销话术"}
  ]
}
```

#### 3.2 业务知识问答（问业务：固定资产贷款怎么做）

```json
{
  "operatetype": "营销助手",
  "type": "analysis",
  "content": "针对您的问题我将从①定义、②准入条件、③适用范围、④营销话术这几块给您介绍",
  "question": "固定资产贷款怎么做",
  "scopeItems": ["（1）业务适用的范围1", "（2）业务适用的范围2", "（3）业务适用的范围3", "（4）业务适用的范围4", "（5）业务适用的范围5"],
  "scriptItems": [
    {"title": "(1)、营销话术场景1", "body": "营销话术营销话术营销话术营销话术营销话术"},
    {"title": "(2)、营销话术场景2", "body": "营销话术营销话术营销话术营销话术营销话术"}
  ],
  "sections": [
    {"title": "1. 固定资产贷款的定义", "body": "固定资产贷款是向企（事）业法人发放的，用于新建、扩建、改造、购置固定资产投资项目 的本外币贷款",
     "linkText": "全部", "linkQuery": "1. 固定资产贷款的定义"},
    {"title": "2. 准入条件", "body": "固定资产贷款的准入条件固定资产贷款的准入条件固定资产贷款的准入条件",
     "linkText": "全部", "linkQuery": "2. 准入条件"},
    {"title": "3. 适用范围", "body": null,
     "linkText": "全部", "linkQuery": "3. 适用范围"},
    {"title": "4. 营销话术", "body": null,
     "linkText": "全部", "linkQuery": "4. 营销话术"}
  ]
}
```

> 两种场景**同一个模板**：企业四段分析靠 `opportunities` 补第 3 段列表，业务问答靠 `scopeItems` 补第 3 段列表；`scriptItems` 供第 4 段使用。段落标题里出现「适用范围」才会渲染 `scopeItems`。

---

### 4. `report_analysis` · 报表交叉分析

结构同 `analysis`，只是段落更长（经营报表 → 财务报表 → 交叉分析 → 综合结论）。

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 引言 |
| `sections[].title` | string | 是 | 小节标题 |
| `sections[].body` | string | 是 | 小节正文，可含多行（`\n`） |
| `chips` | string[] | 否 | 后续动作选项，如「1、营销话术」「2、规划出行路线」 |

```json
{
  "operatetype": "营销助手",
  "type": "report_analysis",
  "content": "我将对江苏韵瑞新能源汽车配件公司从公司信息、业务信息、商机等方面进行分析",
  "chips": ["1、营销话术", "2、规划出行路线"],
  "sections": [
    {"title": "1. 经营报表数据", "body": "(1). 近 3 年营业收入：7600 万→8230 万→9150 万，逐年稳步增长，本年营收同比 +11.2%\n(2). 主营业务：工业配套设备生产销售，行业景气度稳定"},
    {"title": "2、财务报表数据（本年）", "body": "– 资产总额：11800 万元，负债总额：5428 万元，资产负债率 46.0%\n– 流动比率：1.91，速动比率：1.36"},
    {"title": "3、交叉分析（经营 + 财务联动校验）", "body": "(1). **营收与现金流交叉验证**\n经营报表显示营收持续增长、订单稳定；财务报表经营性现金流净额 > 净利润…"},
    {"title": "4、综合结论", "body": "通过经营报表与财务报表交叉比对，整体风险可控，符合我行固定资产抵押贷款准入要求。是否给您安排走访任务？"}
  ]
}
```

---

### 5. `industry_profile` · 行业画像卡

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「根据查询内容我为您生成了XX行业画像卡」 |
| `cardTitle` | string | 是 | 卡片标题 |
| `lights` | number | 是 | 点亮灯数（1~5，共 5 盏） |
| `industry` | string | 是 | 所属行业 |
| `industryDesc` | string | 是 | 行业描述（支持 `**加粗**`） |
| `honors` | string[] | 是 | 荣誉标签 |
| `features[].label` | string | 是 | 产业特征项名 |
| `features[].value` | string | 是 | 产业特征值 |

```json
{
  "operatetype": "营销助手",
  "type": "industry_profile",
  "content": "根据查询内容我为您生成了江苏国泰国际集团行业画像卡",
  "cardTitle": "江苏国泰集团",
  "lights": 2,
  "industry": "服务行业",
  "industryDesc": "江苏国泰是**“供应链服务 + 化工新能源” 双主业**模式",
  "honors": ["专精特新“小巨人“", "高新技术企业", "省级名优企业", "绿色工厂认证", "优秀企业"],
  "features": [
    {"label": "产业链位置", "value": "新能源汽车产业链上游.核心零部件供应"},
    {"label": "所属产业集群", "value": "长三角新能源汽车零部件产业集群"},
    {"label": "区域产业带", "value": "江苏张家港. 动力电池产业带"},
    {"label": "行业景气度", "value": "新能源行业景气上行. 扩产预期明显"}
  ]
}
```

---

### 6. `biz_profile` · 业务画像卡

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「根据查询内容我为您生成了XX业务画像图」 |
| `cardTitle` | string | 是 | 卡片标题 |
| `lights` | number | 是 | 点亮灯数（1~5） |
| `openBranch` | string | 是 | 开户机构 |
| `years` | string | 是 | 成立年限 |
| `capital` | string | 是 | 注册资本区间 |
| `tags` | string[] | 是 | 客户标签，**前端固定取前 3 个**，请按序给全 |
| `holdings[].type` | string | 是 | 如「存款余额 / 贷款余额 / 理财」，含「存款」走黄色底、「贷款」走蓝色底，其余走绿色底 |
| `holdings[].amount` | string | 是 | 金额（保留千分位格式，直接展示） |
| `holdings[].dailyLabel` | string | 是 | 日均标签，如「存款日均」 |
| `holdings[].daily` | string | 是 | 日均值 |
| `holdings[].tip` | string | 否 | 警示提示，如「最近有一笔 600,000.00 存款 2026.9.30 到期」 |
| `accounts[].name` | string | 是 | 账户名，如「结算户」 |
| `accounts[].count` | number | 是 | 数量 |
| `accounts[].unit` | string | 是 | 单位，如「户」 |
| `accounts[].extra` | string | 否 | 补充说明，如「月均流水：88,888.88」 |
| `holdProducts` | string[] | 是 | 持有产品标签 |
| `signProducts` | string[] | 是 | 签约产品标签 |
| `channels[].name` | string | 是 | 渠道名 |
| `channels[].signed` | boolean | 是 | 是否已签约（`true` 高亮并显示「已签约」） |
| `channelStatus` | string | 是 | 使用状态 |
| `yearAmount` | string | 是 | 年累计交易金额 |
| `yearCount` | string | 是 | 年累计交易笔数 |
| `creditLoanCustomer` | string | 是 | 是否贷款客户 |
| `creditCardCustomer` | string | 是 | 是否信用卡客户 |
| `debtTypes` | string | 是 | 负债类型 |

```json
{
  "operatetype": "营销助手",
  "type": "biz_profile",
  "content": "根据查询内容我为您生成了江苏国泰国际集团业务画像图",
  "cardTitle": "江苏国泰集团",
  "lights": 2,
  "openBranch": "总行营业厅",
  "years": "5年以上",
  "capital": "200-500万",
  "tags": ["合作客户", "风险五级客户", "标签"],
  "holdings": [
    {"type": "存款余额", "amount": "88,888.88", "dailyLabel": "存款日均", "daily": "8888.88", "tip": "最近有一笔 600,000.00存款 2026.9.30 到期"},
    {"type": "贷款余额", "amount": "88,888.88", "dailyLabel": "贷款日均", "daily": "8888.88", "tip": null},
    {"type": "理财", "amount": "88,888.88", "dailyLabel": "理财日均", "daily": "8888.88", "tip": null}
  ],
  "accounts": [
    {"name": "结算户", "count": 1, "unit": "户", "extra": "月均流水：88,888.88"},
    {"name": "一般户", "count": 2, "unit": "户", "extra": null}
  ],
  "holdProducts": ["自营理财", "代销理财", "存款"],
  "signProducts": ["待发工资", "结售汇"],
  "channels": [
    {"name": "手机银行", "signed": true},
    {"name": "网上银行", "signed": true},
    {"name": "柜面", "signed": false}
  ],
  "channelStatus": "正常",
  "yearAmount": "100,000,000.00",
  "yearCount": "999",
  "creditLoanCustomer": "是",
  "creditCardCustomer": "是",
  "debtTypes": "消费贷、XX贷、XXXXXX贷"
}
```

---

### 7. `opportunity` · 商机线索卡

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「针对XX存在 5 条商机线索。」 |
| `tabs` | string[] | 是 | 分类页签，如 `["存款","贷款","供应链"]` |
| `current` | string | 是 | 当前选中的页签（需在 `tabs` 内） |
| `list[].category` | string | 是 | 分类：`存款` → 橙色图标，其余 → 蓝色图标 |
| `list[].name` | string | 是 | 商机名称 |
| `list[].goal` | string | 是 | 直接业务目标 |
| `list[].tip` | string | 是 | 提示信息 |
| `list[].action` | string | 是 | 营销动作提示 |

```json
{
  "operatetype": "营销助手",
  "type": "opportunity",
  "content": "针对江苏国泰国际集团存在 5 条商机线索。",
  "tabs": ["存款", "贷款", "供应链"],
  "current": "存款",
  "list": [
    {"category": "存款", "name": "存量存款到期转化", "goal": "防止存款流失，争取续存或转化", "tip": "有存款到期，请及时续期", "action": "客户经理提前联系，提供 \"自动续存\" 或推荐当期收益更高的存款 / 理财方案。"},
    {"category": "存款", "name": "待发工资资金留存", "goal": "提升代发工资留存率", "tip": "企业员工代发工资日均留存偏低", "action": "推荐 \"薪理财\" 产品，引导员工工资卡资金留存我行。"}
  ]
}
```

---

### 8. `script` · 营销话术卡

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「针对XX为您推荐下列话术。」 |
| `tabs` | string[] | 是 | 场景页签，如 `["办公室场景","生产车间","仓库场景","初次拜访"]` |
| `current` | string | 是 | 当前场景 |
| `list[].title` | string | 是 | 话术标题 |
| `list[].content` | string | 是 | 话术正文 |
| `deepQuestion` | string | 否 | 如「您也可以描述您需要运用的场景，我将为您匹配合适的话术」 |

> 每张话术卡固定显示「合规词库已校验」与「一键复制」，无需传参。

```json
{
  "operatetype": "营销助手",
  "type": "script",
  "content": "针对江苏国泰国际集团为您推荐下列话术。",
  "deepQuestion": "您也可以描述您需要运用的场景，我将为您匹配合适的话术",
  "tabs": ["办公室场景", "生产车间", "仓库场景", "初次拜访"],
  "current": "办公室场景",
  "list": [
    {"title": "办公室场景.开场白", "content": "您好，我是XX银行客户经理小李。了解到贵公司近期在园区新投产生产基地。我们在结算与代发工资上有针对性优惠方案，方便用3分钟给您介绍一下吗?"},
    {"title": "办公室场景.需求挖掘", "content": "您好，我是XX银行客户经理小李。了解到贵公司近期在园区新投产生产基地…"}
  ]
}
```

---

### 9. `task_groups` · 待办检索结果（任务分组折叠列表）

> 即「待办检索智能体」的应答模板（切图 `index.html#s4`）。用户问「今日任务 / 我的待办 / 待办检索」等时输出。

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「我查询到您今日有 49 条任务」 |
| `groups[].name` | string | 是 | 分组名 |
| `groups[].count` | number | 是 | 条数（右上角显示「X条」） |
| `groups[].open` | boolean | 否 | 是否默认展开 |
| `groups[].items[].title` | string | 是 | 任务名 |
| `groups[].items[].path` | string | 是 | 任务路径 |

```json
{
  "operatetype": "今日任务",
  "type": "task_groups",
  "content": "我查询到您今日有 49 条任务",
  "total": 49,
  "groups": [
    {
      "name": "客户经理工作",
      "count": 3,
      "open": true,
      "items": [
        {"title": "开户尽调", "path": "营销工作台-客户洽谈-尽职调查"},
        {"title": "客户信息维护后尽调", "path": "营销工作台-客户洽谈-尽职调查"},
        {"title": "转介", "path": "转介中心-转介管理"}
      ]
    },
    {
      "name": "客户信息提示任务",
      "count": 23,
      "open": false,
      "items": [
        {"title": "客户信息提示任务1", "path": "客户信息提示-待处理"}
      ]
    }
  ]
}
```

---

### 10. `task_flow` · 业务流程图 + 任务生成

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「我将为您分配对XX开展固定资产贷款的触达任务」 |
| `sections` | string[] | 是 | **固定 2 个元素**：`[0]` 流程图上方标题、`[1]` 下方标题 |
| `main` | string[] | 是 | 主流程节点（自上而下串联，可用 `\n` 换行） |
| `sideGroups[].anchor` | string | 否 | 支线锚点（当前不渲染） |
| `sideGroups[].nodes` | string[] | 是 | 右侧支线节点 |
| `chips` | string[] | 否 | 如「1、营销话术」「2、规划出行路线」 |
| `deepQuestion` | string | 否 | 后续准备提示语 |

> 主流程中「创建临时客户 / 资前准备 / 对公客户开户预约 / 授信」等节点会被自动高亮。

```json
{
  "operatetype": "今日任务",
  "type": "task_flow",
  "content": "我将为您分配对江苏韵瑞新能源汽车配件公司开展固定资产贷款的触达任务",
  "deepQuestion": "针对您即将开展的针对江苏韵瑞新能源汽车配件公司的触达任务，您是否需要我为您做一下准备？",
  "chips": ["1、营销话术", "2、规划出行路线"],
  "sections": ["1. 固定资产贷款业务流程", "2. 已经为您生成触达任务"],
  "main": ["创建临时客户", "临时客户", "(开户后)临时客户\n转正", "正式客户", "资前准备", "对公客户开户预约", "客户经理尽调", "柜面开户", "一体化PAD上门开户", "(开户后)临时客户\n转正", "授信", "合同申请", "合同签订", "合同影像审核(贸易融资、贴现)", "出账"],
  "sideGroups": [
    {"anchor": "资前准备", "nodes": ["征信查询", "融资申请", "贷前尽调(双录、现场拍照)", "不动产估值(如需)"]},
    {"anchor": "授信", "nodes": ["资前准备", "授信方案确定", "撰写调查报告", "利率定价", "其他事项申请(如需)"]},
    {"anchor": "合同影像审核(贸易融 资、贴现)", "nodes": ["国结、票据系统出账"]},
    {"anchor": "出账", "nodes": ["线上签订模式：客户渠道确认", "线下纸质签订模式：纸质线下审批"]}
  ],
  "task": {"taskId": "RT20261015A1B2C3", "company": "江苏韵瑞新能源汽车配件公司", "business": "固定资产贷款", "status": "已生成"}
}
```

---

### 11. `menu_grid` · 菜单检索结果（功能宫格）

> 即「菜单检索智能体」的应答模板（切图 `index.html#s2`）。用户问「菜单查找 / 菜单检索 / 网格 / XX功能在哪」等时输出。

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `content` | string | 是 | 如「我共为您找到 3 个网格相关的功能，您可以点击图标直接跳转到对应功能！」 |
| `items[].icon` | string | 是 | **资源文件名**（不含 `@2x.png` 后缀），前端按 `assets/{icon}@2x.png` 取图。可用值见 `static/assets/`，如 `我的网格`、`网格名单落点`、`网格名单` |
| `items[].label` | string | 是 | 功能名 |
| `items[].url` | string | 否 | **点击后打开的子页面地址**（也可写 `path` / `link`）。可以是完整 `https://…`，也可以是相对路径（如 `/mobs4.0-TMF-SIT/integrationcustomer/WDKB/NWDKB0002.html`，前端会拼上 `ok.assistant.native-base-url`）。**不填则点击只弹提示** |
| `items[].param` | object | 否 | 传给子页面的业务参数，原样放进 `openNativePage` 的 `param`（Android 侧会再 `JSON.stringify` 一次） |
| `items[].title` | string | 否 | 子页面标题；缺省用 `label` |
| `items[].bids` | string | 否 | 业务路由标识，拼成 `?_bids=…`（如 `integrationcustomer static`） |
| `total` | number | 否 | 命中总数（建议与 `items.length` 一致；文案里的数量请自行按实际条数书写） |

> **点击行为**：前端调用门户 JSBridge 的 `openNativePage`，参数与门户示例一致
> （`url` / `containerId` / `param` / `title` / `isVertical:false` / `showTitleBar:"true"` / `is_screens_watermark_type:"-1"`），
> 并自动在 `url` 上补 `userToken`（子页面同样需要鉴权）。桌面浏览器或不在容器内时降级为 `window.open`。

> **布局约定**：宫格固定 **一行 3 个**，`items` 的数组顺序即展示顺序；**超过 3 个自动换行**（第 4、5、6 个落到第二行，以此类推），图标与文字在各自单元格内水平居中，行间距由样式统一控制。因此 `items` 数量不限，但建议按 3 的倍数递增，避免末行只剩一格显得稀疏。

```json
{
  "operatetype": "菜单查找",
  "type": "menu_grid",
  "content": "我共为您找到 3 个网格相关的功能，您可以点击图标直接跳转到对应功能！",
  "total": 3,
  "items": [
    {"icon": "我的网格", "label": "我的网格",
     "url": "/mobs4.0-TMF-SIT/integrationcustomer/WDKB/NWDKB0002.html",
     "bids": "integrationcustomer static",
     "param": {"gridId": "G001"}},
    {"icon": "网格名单落点", "label": "网格名单落点", "url": "/mobs4.0-TMF-SIT/integrationcustomer/WDKB/NWDKB0003.html"},
    {"icon": "网格名单", "label": "网格名单"}
  ]
}
```

> 第三个条目没给 `url` → 点击只提示「跳转功能：网格名单」，用于占位 / 未上线功能。

---

## 四、跨模板的隐式约定（容易踩坑）

1. **`content` 永远会被渲染**。卡片消息的 `content` 是卡片上方的说明文字，不要留空（除非确实不需要说明）。
2. **`analysis` / `report_analysis` 的附加列表靠「小节标题关键词」触发**：
   - 标题含「商机线索」→ 渲染 `opportunityTotal` + `opportunities`
   - 标题含「适用范围」→ 渲染 `scopeItems`
   - 标题含「营销话术」→ 渲染 `scriptItems`
   也就是说：想让某个列表出现，对应小节的标题必须带上这些词，且该小节 `body` 通常留空。
3. **`task_flow` 的 `sections` 必须正好 2 个元素**（按 `[0]` / `[1]` 取值），顺序不能乱。
4. **`biz_profile` 的 `tags` 固定取前 3 个**，多给不显示。
5. **`menu_grid` 的 `icon` 是文件名**，必须能在 `static/assets/` 找到同名 `@2x.png`，否则图片裂开。宫格一行 3 个，`items` 超过 3 个会自动换行（无需前端改动，直接多给即可）。`items[].url` 缺省时点击只提示「跳转功能：xxx」，不会报错。
6. **`current` 必须出现在 `tabs` 里**，否则页签没有高亮项。
7. **`chips` 只用于互斥 / 单选类选项**（如触达任务的「1、营销话术 / 2、规划出行路线」）：它的取值是「用户点击后回传的文本」，同时承担界面选项 + 下一轮 query 两件事，需保证在 Dify 侧能被正确识别（建议与子意图识别用词一致）。**不要用它承载「分段图文里每一段的详情入口」**。
8. **段落详情入口用 `sections[].linkText`**（仅 `analysis` 模板）：每个小节标题右侧按其渲染「`linkText` >」链接，点击回传 `linkQuery`（缺省取该段 `title`）。想让哪一段有入口就给哪一段加这两个字段；**`report_analysis` 段落是完整长文、没有跳转语义，不要加**（不加就不渲染链接）。
9. **`operatetype` 建议每轮回填**，它是历史会话「打开后自动选中对应菜单」的唯一依据（缺失时应用会退而取会话内首条消息的值）。
10. **菜单查找 / 今日任务两个场景当前 Chatflow 只返回占位文案**（`正在查找菜单` / `正在查找今日任务`），客户端因此只能显示纯文本——这两个场景的卡片模板（`menu_grid` / `task_groups`）客户端早已实现，**Chatflow 侧在对应意图分支直接输出上面的 JSON 即可出卡片**，无需客户端改动。

---

## 四（附）、文件上传与下载（字节单一来源 = Dify，应用侧零副本）

前端有**两个入口，都走同一条链路**：右下角「+」按钮（选择文档 / 图片）、左下角相机（唤起系统相机拍照，照片按图片附件上传）。完整链路：

```
选择文件  → POST /api/chat/files (multipart) → Dify POST /v1/files/upload → 平台文件 id
发送消息  → POST /api/chat/messages body.files=[{id,name,size,kind}]
            → chat-messages 顶层 files（= userinput.files，给流程用）
            → chat-messages inputs.files（= 持久化通道，让 Dify 记住这条消息带了哪些文件）
读取附件  → GET /api/chat/files/{id}?cid=<会话>
            → 立刻读一次该会话历史，拿 Dify「刚签发」的下载地址 → 服务端拉字节 → 转发
（刚上传还没发送的附件没有会话上下文：服务端不提供读取，由前端用浏览器本地副本即时预览）
```

**核心结论（2026-10 实测，api.dify.ai / Dify 1.17.1 Chatflow）**：

| 事实 | 实测结果 |
|---|---|
| 服务 API 有无「按文件 id 取文件」接口 | **没有** —— `GET /v1/files/{id}/preview` 返回 `file_not_found`，`/v1/files/{id}`、`/file-preview`、`/download` 均 404 |
| 上传响应给不给可下载地址 | **给**：`source_url` = `/files/{id}/file-preview?timestamp&nonce&sign`，**免令牌可直连**得到原始字节 |
| 该地址有效期 | = 平台 `FILES_ACCESS_TIMEOUT`（默认 **300 秒**）；篡改 `timestamp` / `sign` 一律 404 |
| 历史消息能否回带附件 | 取决于传入方式，见下表 |
| 回带地址是否过期 | **每次读取历史都重新签名**（同一文件连续两次拉取，`timestamp`、`nonce`、`sign` 全不同）→ 等价于「随取随新」 |

**两条下发通道（内容相同、作用不同）**：

| 通道 | 位置 | 作用 |
|---|---|---|
| 顶层 `files` | `chat-messages.files` = 预设变量 `userinput.files` | **流程用**：Chatflow 里 `{{#userinput.files#}}` 取本轮文件 |
| `inputs.files` | `chat-messages.inputs.<input-files>`（默认变量名 `files`） | **存档用**：Dify 把文件对象持久化在该条消息上，历史接口据此回带附件 |

为什么必须两条都发（实测对照）：

| 传入方式 | `/v1/messages` 的 `message_files` | 历史 `inputs` 里的文件 | 历史能否看到附件 |
|---|---|---|---|
| 只发顶层 `files` | 空数组 | 该变量回带 `null` | ❌ 附件在历史里彻底消失 |
| 顶层 `files` + `inputs.files` | 空数组 | **完整回带** `filename` / `size` / `mime_type` / `type` / `related_id` / `url`（新签名） | ✅ |

因此**无需**任何应用侧「消息 ↔ 附件」映射：历史附件就是该条消息 `inputs.files` 的原样还原，
`DifyChatService.messages` 把它映射为前端的 `{id, name, size, kind}`（`id` 取 `related_id`，
`kind` 由 `type` / `mime_type` 判定）。

**下载路径**：前端固定走 `GET /api/chat/files/{id}?cid=<会话>`，`FileTransferService`
**每次都实时读一次该会话历史** → 拿到 Dify 刚签发的地址（Dify 每次读历史都重新签名，故永不过期）
→ 服务端拉字节 → **转发给前端**（而不是 302 跳转）—— 这样能保留附件下载的文件名与 `Content-Disposition`，
也不要求浏览器能直连 Dify 文件域名。

**应用侧无状态（可集群部署）**：不落盘、不写本地索引、进程内也不留任何快照，每次读取都现取现用。
因此上传落在实例 A、下载打到实例 B 也照样成功，实例随时重启 / 扩缩容都不影响请求，
不需要粘性会话、共享存储或跨实例同步。代价是每次附件读取多一次 `/v1/messages` 调用
（平台侧按会话返回，通常几十~几百毫秒）；若日后要压这次调用，只能靠**跨实例共享的只读缓存**，
不能退回实例内缓存。

| 配置 | 说明 |
|---|---|
| `ok.assistant.dify.input-files` | 携带附件的 inputs 变量名（默认 `files`）；留空 = 不写存档通道，历史将不再回带附件 |

**Dify 侧文件参数**：

| 项 | 配置 |
|---|---|
| 变量 | `userinput.files`（Dify 预设，默认就有） |
| 字段类型 | 文件列表 `array[file]` |
| 支持类型 | 文档（TXT/MD/MDX/MARKDOWN/PDF/HTML/XLSX/XLS/DOC/DOCX/CSV/EML/MSG/PPT/PPTX/XML/EPUB）+ 图片（JPG/JPEG/PNG/GIF/WEBP/SVG），由 Dify 侧「文件上传」功能勾选 |
| 上传方式 | 本地上传 |
| 最大上传数 | 10 |
| 大小限制 | 文档 < 15MB，图片 < 10MB（与 yml 的 `ok.assistant.upload-*` 保持一致） |

文件项格式有两种，按前端给的数据决定：

| 来源 | 格式 | 说明 |
|---|---|---|
| H5 上传到 `/api/chat/files`（`<input type=file>`、桌面浏览器） | `{type, transfer_method: local_file, upload_file_id}` | 字节先传到 Dify，拿到平台 file id |
| 原生容器 `selectPicture`（`Camera` / `Photo`） | `{type, transfer_method: remote_url, url}` | 图片由原生传到门户文件服务器，H5 取不回字节时把地址交给 Dify 拉取 |

`type` 由扩展名判定（图片扩展名 → `image`，其余 → `document`）。
上传 `/v1/files/upload` 的 `user` 必须与 `chat-messages` 的 `user` 一致（应用统一取当前登录工号），否则报「文件不存在」。

> `remote_url` 要求 **Dify 服务能访问该地址**。如果门户文件服务器只在用户终端的内网可达、Dify 访问不到，
> 就要让原生回调改回 base64（前端会自动转成文件走 `local_file`），或者把文件服务器出口放开。

### 原生容器图片上传（`selectPicture`）

| 项 | 约定 |
|---|---|
| 唤起 | Android：`window.androidNative.selectPicture(JSON.stringify({type, photosNum:1}))`；iOS：`window.webkit.messageHandlers.selectPicture.postMessage(JSON.stringify({type, photosNum:1}))`（由 `js/jsBridge.js` 统一封装） |
| `type` | `Camera` 拍照 / `Photo` 从相册选择 |
| 回调 | 全局函数 `window.receiveSelectPicture(msg, data)`，`msg === 'success'` 且 `data.uploadInfo.errcode === '0000'` 才算成功 |
| 回调数据 | `data` 为 JSON 串；文件地址按 `fileUrl / fileURL / filePath / downloadUrl / url` 依次取，文件名按 `fileName / name`，大小按 `fileSize / size`，base64 按 `base64 / content` |
| 失败 | `errcode` 非 `0000` 时提示「上传失败：`errmsg`」；取消同理 |

前端处理顺序：**有 base64 → 转文件走 `/api/chat/files`（最稳）；只有地址 → 先尝试下载再上传，跨域失败则退化为 `remote_url`**。
原生不可用（桌面浏览器 / 普通微信）时自动退回 `<input type=file accept=image/* capture=environment>`。

**应用侧零副本**：

| 内容 | 位置 | 说明 |
|---|---|---|
| 文件字节 | **Dify** | 应用不落盘、不缓存；每次读取都按会话现取签名地址后转发 |
| 消息 ↔ 附件关系 | **Dify**（消息 `inputs.files`） | 应用不留档、不建索引 |
| 刚选中 / 刚发送附件的即时预览 | 浏览器本地副本（`blob:`） | 前端 `fileUrl()` 优先用本地副本，省一次往返；刷新页面即失效，之后自动回落到服务端地址 |

> 遗留的 `ok.assistant.upload-dir`、`ok.assistant.dify.attachment-variable`（`attach_history` 会话变量）、
> `ok.assistant.dify.file-url-reuse-seconds`、本地 `index.json` 均已随本次改造移除，
> 仓库与运行目录都不再产生任何附件文件；`docs/dify/营销助手.yml` 里的 `conversation_variables` 也已清空。

### 文档在线预览（Word / Excel / PPT → 服务端转 PDF）

图片与 PDF 浏览器原生就能显示，**Word / Excel / PPT 不能**，因此由服务端用 LibreOffice（headless）
转成 PDF 后内联返回，前端统一用**本地化的 pdf.js** 画出来。

> 为什么不用 `<iframe>` 把 PDF 交给浏览器自带的阅读器：移动端不可靠 —— iOS Safari 只显示第一页，
> Android Chrome 干脆不渲染 iframe 里的 PDF。pdf.js（`static/js/vendor/`，随项目分发、不连外网、
> 首次打开预览时才按需加载）才能让手机与桌面表现一致，也不依赖浏览器插件。

| 类型 | 预览方式 | 额外依赖 |
|---|---|---|
| 图片 | `<img>` 直接显示 | 无 |
| PDF | 原件直通 → pdf.js 渲染 | 无 |
| Word / Excel / PPT / CSV | 服务端 LibreOffice 转 PDF → pdf.js 渲染 | 目标机器需安装 LibreOffice |
| 其他（txt / md / zip…） | 弹层只给文件信息 + 下载入口 | 无 |

接口约定（`GET /api/chat/files/{id}`）：

| 查询参数 | 行为 | 响应 |
|---|---|---|
| `inline=1&cid=<会话>` | 内联预览：PDF 原件直通，Office 转 PDF | `200` + `application/pdf` + `Content-Disposition: inline` + `Cache-Control: no-store` |
| `download=1&cid=<会话>` | 下载**原件**（不做转换） | `200` + 原始类型 + `attachment` |
| 仅 `cid`（图片） | 图片内联，其余按附件下载 | 同原有行为 |
| `inline=1` 但缺 `cid` | 还没随消息发送的附件在平台上没有会话可定位 | `400` + `{"message":"附件尚未随消息发送，发送后即可预览"}` |
| `inline=1` 但转换不可用 | 未装 LibreOffice / 超时 / 转换失败 / 超过大小上限 | `503` + 可直接展示给用户的 `message` |

配置（`ok.assistant.preview.*`）：

| 配置 | 默认 | 说明 |
|---|---|---|
| `enabled` | `true` | 关闭后 Word/Excel/PPT 一律只能下载 |
| `soffice` | 空 | soffice 可执行文件路径；留空自动探测（PATH → 常见安装目录）。Windows 建议指向控制台版 `soffice.com`（会等待转换结束） |
| `timeout-seconds` | `60` | 单次转换超时 |
| `concurrency` | `2` | 并发转换数。LibreOffice 不能多进程共用同一用户配置目录，服务按此值准备等量「独立配置目录」槽位，多余的请求排队等待 |
| `max-size-mb` | `20` | 超过该大小不转换，直接提示下载 |

`/api/chat/profile` 额外下发预览能力，前端据此在打开弹层前就能给出准确提示：

| 字段 | 含义 |
|---|---|
| `preview.enabled` | 配置开关 |
| `preview.available` | 是否真的可用（开关打开 + 探测到 soffice） |
| `preview.maxSizeMb` | 与后端一致的大小上限 |

**无状态依然成立**：转换在实例本地临时目录（`<java.io.tmpdir>/ok-preview/p<端口>/job-*`）里进行，
结束（含失败）立即整体删除，只保留按槽位复用的 LibreOffice 配置目录；按端口隔离是为了同机多实例互不干扰。
因此集群下「上传落在 A、预览打到 B」也能工作 —— B 自己转一遍即可，不需要共享缓存或粘性会话。

**部署前提**：目标机器安装 LibreOffice（Windows 常见位置 `C:\Program Files\LibreOffice\program\soffice.com`）。
没装也不会出错：探测失败后 `/api/chat/profile` 的 `preview.available=false` 会让前端直接显示
「服务端未启用文档在线预览，请下载后查看」，上传、下载与其他附件能力完全不受影响。

**相机拍照**：左下角相机按钮通过 `input[type=file][accept=image/*][capture=environment]` 唤起系统相机（移动端直接进后置摄像头，桌面浏览器退化为「选择图片」，行为一致）；拍到的照片走同一上传链路，Chatflow 侧拿到的就是普通的 `image` 文件，**无需额外配置**。真机相机返回的文件可能不带扩展名，前端会按 MIME 补成 `照片_YYYYMMDD_HHMMSS.jpg` 再上传，保证服务端与 Dify 都按图片类型处理。

**边界与依赖**：

- 附件能力**依赖 Dify 可用**：Dify 不可达时，历史里的附件条目仍在（元数据来自消息 `inputs.files`），但字节取不回来；
- **缺会话上下文（`cid`）的读取一律 404** —— 刚上传未发送、以及离线演示模式下的附件，由前端本地副本承担，服务端不保存；
- 地址可能在拉取瞬间失效（平台签名 TTL = `FILES_ACCESS_TIMEOUT`，默认 300 秒）：此时自动重取一次新签名再试；
  Dify 每次读历史都重签，所以重取必然拿到可用地址；
- 自部署时文件服务地址由平台 `FILES_URL` 决定，**须保证应用服务器能访问**（服务端转发，浏览器不需要）；
- 平台侧对「未被引用的文件」有清理任务；被消息 `inputs.files` 引用的文件属于已引用，不受影响；
- mock 模式（`ok.assistant.dify.enabled=false`）下不连 Dify：上传只返回一个临时 id、不保存字节，
  服务端读取一律 404（预览 / 下载靠浏览器本地副本，刷新页面后失效），历史里仍能看到附件条目（元数据来自本地会话存储）。

---

## 五、扩展新模板

新增一个 type（例如 `bar_chart`）只需两步：

1. **Chatflow 侧**：`type` 写成 `bar_chart`，业务数据平铺在 JSON 顶层；
2. **前端侧**：在 `static/index.html` 的 `.bot-content` 内增加一个 `v-if="msg.msgType === 'BAR_CHART'"` 模板块，用 `msg.payload.*` 取数据。

**应用侧无需任何改动**：`DifyAnswerResolver` 会把 `type` 规范化为 msgType 透传，未实现模板的 type 会自动退化为纯文本展示（只显示 `content`），不会白屏或报错。
