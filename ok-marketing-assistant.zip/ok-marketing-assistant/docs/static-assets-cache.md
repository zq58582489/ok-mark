# 静态资源缓存：前端文件动态版本参数

## 一、要解决的问题

前端是无构建的 Vue2 静态页（`classpath:/static`），js / css / 图片都是固定地址直接引用：

```html
<link rel="stylesheet" href="css/app.css">
<script src="js/app.js"></script>
```

发版后地址没变，浏览器、中间代理、CDN 会继续用旧缓存 → 「明明改了前端，页面还是老样子」，只能靠人工 Ctrl+F5 强刷。

现在由服务端在返回 HTML 入口时，给这些引用统一追加**内容哈希**版本参数：

```
改造前  <script src="js/app.js"></script>
改造后  <script src="js/app.js?v=62081167"></script>
        <script>window.OK_ASSET_VERSION='70bcfc22';window.okAsset=function(u){…}</script>
```

版本号 = 资源内容 MD5 前 8 位。**内容不变版本不变（继续命中缓存），内容变了版本必变（强制拉新）**，不需要人工改版本号、也不需要强刷。

| 组件 | 职责 |
|---|---|
| `com.ok.web.asset.AssetVersionFilter` | 拦截 HTML 入口（`/`、`/index.html`）：重写响应体引用、注入全局版本号、设置缓存头 |
| `com.ok.web.asset.AssetVersionResolver` | 算单个资源的内容哈希（按最后修改时间缓存）；算全局指纹 |
| `com.ok.web.asset.AssetProperties` | 配置项（`ok.web.assets.*`） |

## 二、缓存策略（HTML 与静态资源分开）

| 请求 | 响应头 | 效果 |
|---|---|---|
| HTML 入口 `/`、`/index.html` | `Cache-Control: no-cache, must-revalidate` + `ETag`（**重写后内容**的哈希） | 每次都会校验；没改 → 304（几十字节）；改了 → 立刻拿到带新版本号的 HTML |
| 带版本参数的静态资源 `js/app.js?v=…` | `Cache-Control: public, max-age=31536000, immutable` | 地址随内容变，可放心长缓存（1 年） |
| 不带版本参数的静态资源 | 不加额外头（维持原有的协商缓存） | 保持改造前行为，避免误伤其它调用方 |

> ETag 必须用「重写后的内容」计算。若沿用静态文件自身的 ETag，浏览器会拿上次缓存的 HTML 比对命中 304，于是继续复用里面的旧版本号 —— 缓存问题会原样重现。

## 三、前端约定：动态拼接的地址用 `okAsset()`

HTML 里**字面量**写的引用（`src="assets/头像@2x.png"`）服务端会自动改写；但用表达式拼出来的地址服务端展开不了，需要前端自己包一层：

```html
<!-- 服务端改写不到这种（Vue 表达式） -->
<img :src="'assets/' + it.icon + '@2x.png'">

<!-- 改成这样：走全局指纹版本 -->
<img :src="okAsset('assets/' + it.icon + '@2x.png')">
```

```js
// js 里同理
localImages: [okAsset('assets/截屏 2026-09-16 14.26.41@2x.png')]
```

- `okAsset` 由服务端注入到 HTML（`app.js` 顶部另有兜底实现，直接打开文件、或关掉本功能时也不会报错）。
- 它只处理本地相对地址：外部 http(s)、`data:`、`blob:`、已带 `?`/`#` 的地址原样返回。
- 这类地址共用一个**全局指纹**版本：`js/css 的内容哈希 + assets 图片的名字/大小/修改时间`。因此哪怕只换了一张图、js 没动，指纹也会变，相关地址随之刷新。
- 新增前端代码时，**动态拼接静态资源地址请一律用 `okAsset()` 包一层**（现在 `index.html` 的 8 处动态 `:src` 与 `app.js` 的示例图片都已处理）。

## 四、配置（application.yml）

```yaml
ok:
  web:
    assets:
      enabled: true                                # 关闭后行为退回改造前
      param: v                                     # 版本参数名
      html-cache-control: no-cache, must-revalidate
      max-age-seconds: 31536000                    # 带版本参数的静态资源强缓存秒数；0 = 不加缓存头
      immutable: true
      # extensions: js,css,json,png,jpg,jpeg,gif,webp,svg,ico,woff,woff2,ttf,eot
```

## 五、排查

| 现象 | 处理 |
|---|---|
| 改了前端还是没生效 | F12 看 `js/app.js?v=…` 的 query 是否变了：变了说明服务端正常，问题在更外层（网关/CDN 对 HTML 做了强缓存）；没变说明文件没进包（重新 `mvn package`） |
| 临时想关掉 | 启动加 `--ok.web.assets.enabled=false` 或改 yml（无需改代码） |
| 部署在 nginx/CDN 之后 | 应用只能保证自己这一层。前置代理需放行带 query 的静态请求，并对 HTML 禁用强缓存 |
| 新增的图片没刷新 | 检查是不是动态拼接且忘了 `okAsset()`（这类地址不带版本时走协商缓存，通常仍会更新，但不保证） |

## 六、验证方式

| 脚本 | 覆盖 |
|---|---|
| `/d/tmp/probe/asset-version-live.sh`（43 项） | HTML 引用改写、哈希与源文件一致、注入内容、缓存头、304、接口不受影响、幂等、指纹覆盖范围 |
| `/d/tmp/probe/asset-version-verify.js`（16 项，连真实 jar） | 浏览器实际加载的资源都带版本、动态 `:src` 与中文名图片真实加载成功（非 404）、页面交互与 JS 报错 |
